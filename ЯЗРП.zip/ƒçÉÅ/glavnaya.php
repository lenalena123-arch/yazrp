<?php
session_start();
?>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЯЗРП - Аренда и ремонт погрузчиков</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #253482;
            --secondary-color: #FF6B00;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
        }
        .header-info {
            background-color: #ffffff;
            padding: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-nav {
    margin: 0 auto;
}
        .navbar-nav .nav-link.active {
            color: var(--secondary-color) !important;
            font-weight: bold;
            position: relative;
        }
        .navbar-nav .nav-link.active:after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--secondary-color);
        }
        .logo-and-text {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .header-info img {
            height: 60px;
            transition: transform 0.3s;
        }
        .header-info img:hover {
            transform: scale(1.05);
        }
        .header-text .title {
            font-weight: bold;
            font-size: 1.2rem;
            color: #000;
        }
        .header-text .location {
            font-size: 1rem;
            color: #333;
        }
        .divider {
            border-left: 1px solid #ccc;
            height: 50px;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-size: 1.10rem;
            padding: 0.50rem 1.5rem;
            border-radius: 0.5rem;
            transition: all 0.3s;
            font-weight: 500;
        }
        .btn-primary:hover {
            background-color: #1a285f;
            border-color: #1a285f;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .btn-orange {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
            color: white;
        }
        .btn-orange:hover {
            background-color: #e05d00;
            border-color: #e05d00;
        }
        .carousel-caption {
            top: 50%;
            transform: translateY(-50%);
            bottom: auto;
            background-color: rgba(37, 52, 130, 0.85);
            padding: 30px;
            border-radius: 15px;
            width: 80%;
            max-width: 800px;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }
        .carousel-caption h3 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        .carousel-caption p {
            font-size: 1.2rem;
            margin-bottom: 25px;
        }
        .carousel-indicators button {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin: 0 5px;
            background-color: rgba(255, 255, 255, 0.5);
            border: none;
            transition: background-color 0.3s ease;
        }
        .carousel-indicators .active {
            background-color: white;
        }
        .navbar-custom { 
            background-color: var(--primary-color) !important; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .navbar-custom .nav-link { 
            color: white !important; 
            padding: 10px 15px;
            transition: all 0.3s;
        }
        .navbar-custom .nav-link:hover {
            color: var(--secondary-color) !important;
        }
        .carousel-item {
            height: 600px;
        }
        .carousel-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }
        .section-padding { 
            padding: 80px 15px; 
        }
        .section-title {
            position: relative;
            margin-bottom: 50px;
        }
        .section-title h2 {
            font-weight: 700;
            color: var(--primary-color);
            position: relative;
            display: inline-block;
            padding-bottom: 15px;
        }
        .section-title h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--secondary-color);
        }
        .feature-box {
            text-align: center;
            padding: 30px 20px;
            margin-bottom: 30px;
            transition: all 0.3s;
            border-radius: 10px;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .feature-box-content {
            flex: 1;
        }
        .feature-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .feature-icon {
            width: 100px;
            height: 100px;
            background: var(--secondary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
            transition: all 0.3s;
        }
        .feature-box:hover .feature-icon {
            background: var(--primary-color);
            transform: rotateY(180deg);
        }
        .feature-box h4 {
            font-weight: 600;
            margin: 15px 0 10px;
            color: var(--primary-color);
        }
        .feature-box p {
            margin-bottom: 15px;
            min-height: 60px;
        }
        .bg-light {
            background-color: #f9f9f9 !important;
        }
        .footer { 
            background: #222; 
            color: #fff; 
            padding: 40px 15px; 
        }
        .footer p {
            margin-bottom: 0;
        }
        .page-title {
            background: linear-gradient(to right, var(--primary-color), #3a4ba8);
            color: white;
            padding: 20px 0;
            margin-bottom: 40px;
        }
        .page-title h3 {
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        .work-steps {
            counter-reset: step-counter;
        }
        .work-step {
            position: relative;
            padding-left: 80px;
            margin-bottom: 20px;
        }
        .work-step h4 {
            margin-top: 0;
            margin-bottom: 10px;
        }
        .work-step p {
            margin-bottom: 0;
        }
        .work-step:before {
            counter-increment: step-counter;
            content: counter(step-counter);
            position: absolute;
            left: 0;
            top: 0;
            width: 60px;
            height: 60px;
            background: var(--secondary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
        }
        .stats-box {
            background: var(--primary-color);
            color: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
            height: 100%;
        }
        .stats-number {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .stats-label {
            font-size: 1.2rem;
        }
        
        /* Стили для навигации на мобильных */
        .navbar-custom .navbar-toggler {
            border-color: white;
        }
        
        .navbar-custom .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='white' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        
        /* Адаптивные стили */
        @media (max-width: 992px) {
            .navbar-custom .user-actions {
                order: 1;
                margin-left: 0;
                width: 100%;
                justify-content: flex-end;
                padding: 10px 0;
            }
            
            .carousel-item {
                height: 400px;
            }
            
            .carousel-caption {
                width: 90%;
                padding: 15px;
            }
            
            .carousel-caption h3 {
                font-size: 1.5rem;
                margin-bottom: 10px;
            }
            
            .carousel-caption p {
                font-size: 1rem;
                margin-bottom: 15px;
            }
            
            .work-step {
                padding-left: 60px;
                margin-bottom: 25px;
            }
            
            .work-step:before {
                width: 40px;
                height: 40px;
                font-size: 18px;
            }
            
            .header-info {
                flex-direction: column !important;
                align-items: flex-start;
            }
            
            .search-login {
                width: 100%;
                margin-top: 15px !important;
            }
            
            .logo-and-text {
                width: 100%;
            }
            
            /* Фикс для карточек на мобильных */
            .feature-box {
                padding: 20px 15px;
            }
            
            .feature-icon {
                width: 80px;
                height: 80px;
                font-size: 30px;
            }
            
            .feature-box p {
                min-height: auto;
            }
        }
        
        @media (max-width: 768px) {
            .header-text .title, 
            .header-text .location {
                font-size: 0.9rem;
            }
            
            .divider {
                height: 40px;
            }
            
            /* Фикс для наложения текста */
            .section-padding {
                padding: 50px 15px;
            }
            
            .section-title h2 {
                font-size: 1.8rem;
                padding-bottom: 10px;
            }
            
            .section-title h2:after {
                width: 60px;
                height: 2px;
            }
        }
        
        /* Фикс для карточек одинаковой высоты */
        .row-equal-height {
            display: flex;
            flex-wrap: wrap;
        }
        
        .row-equal-height > [class*='col-'] {
            display: flex;
            flex-direction: column;
        }
    </style>
</head>
<body>
        <div class="top-bar w-100" style="background-color: var(--primary-color); height: 20px;"></div>
    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="logo-and-text">
            <a href="glavnaya.php">
                <img src="logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="search-login d-flex align-items-center">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <!-- Навигация -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
                    <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
                    <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
                    <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
                    <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
                    <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
                    <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
                    <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
                </ul>
                
                <div class="user-actions">
                    <?php if (isset($_SESSION['user'])): ?>
                        <div class="d-flex gap-3 align-items-center">
                            <?php if ($_SESSION['user']['id_role'] == 1): ?>
                                <a class="nav-link" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                            <?php endif; ?>
                            <a class="nav-link" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                            <?php if ($_SESSION['user']['id_role'] != 1): ?>
                                <a class="nav-link" href="cart.php" style="color: white;"><i class="fas fa-shopping-cart"></i></a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <a class="btn btn-outline-light" href="login.php">Войти</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Остальной код остается без изменений -->
    <!-- Слайдер -->
    <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="slider1.png" class="d-block w-100" alt="Аренда погрузчиков">
                <div class="carousel-caption">
                    <h3>Профессиональный ремонт погрузчиков</h3>
                    <p>Быстрое восстановление работоспособности любой техники с гарантией качества</p>
                    <a href="remont.php" class="btn btn-orange btn-lg">Подробнее</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder2.png" class="d-block w-100" alt="Ремонт техники">
                <div class="carousel-caption">
                    <h3>Аренда погрузчиков по выгодным ценам</h3>
                    <p>Гибкие условия для вашего бизнеса - от часа до нескольких лет</p>
                    <a href="arenda.php" class="btn btn-orange btn-lg">Выбрать технику</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder3.png" class="d-block w-100" alt="Запчасти">
                <div class="carousel-caption">
                    <h3>Оригинальные запчасти в наличии</h3>
                    <p>Быстрая поставка комплектующих для всех популярных марок погрузчиков</p>
                    <a href="zapchasti.php" class="btn btn-orange btn-lg">Каталог запчастей</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slider4.png" class="d-block w-100" alt="Техобслуживание">
                <div class="carousel-caption">
                    <h3>Регулярное техническое обслуживание</h3>
                    <p>Продлите срок службы вашей техники с нашими сервисными программами</p>
                    <a href="TO.php" class="btn btn-orange btn-lg">Записаться на ТО</a>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Полоса с названием страницы -->
    <section class="page-title">
        <div class="container text-center">
            <h3 class="mb-0">Главная</h3>
        </div>
    </section>

    <!-- О нас -->
    <section class="section-padding" id="about">
        <div class="container">
            <div class="section-title text-center">
                <h2>О нас</h2>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <p class="lead">Предприятие является одним из крупнейших в Нечерноземной и Северо-Западной зоне России по поставке фронтальных, дизельных и электрических погрузчиков, электротележек, строительно-дорожной техники отечественного и импортного производства, а также полного спектра запасных частей, узлов и агрегатов к ним. Кроме того, мы поставляем тяговые аккумуляторные батареи, шинокомплекты и пр.</p>
                    <p>В настоящее время группа предприятий располагает собственным ремонтно-производственным комплексом общей площадью более 2500 кв. метров и численностью штата более 100 высококвалифицированных специалистов.</p>
                </div>
            </div>
            
            <div class="row mt-5 row-equal-height">
                <div class="col-md-4">
                    <div class="stats-box">
                        <div class="stats-number">15+</div>
                        <div class="stats-label">Лет на рынке</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-box">
                        <div class="stats-number">2500+</div>
                        <div class="stats-label">Кв.м производственных площадей</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-box">
                        <div class="stats-number">100+</div>
                        <div class="stats-label">Специалистов в команде</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Как мы работаем -->
    <section class="section-padding bg-light" id="process">
        <div class="container">
            <div class="section-title text-center">
                <h2>Как мы работаем</h2>
            </div>
            <div class="row">
                <div class="col-lg-8 mx-auto work-steps">
                    <div class="work-step">
                        <h4>Заявка</h4>
                        <p>Оставьте заявку по телефону или через форму на сайте. Наш менеджер свяжется с вами в течение 15 минут.</p>
                    </div>
                    <div class="work-step">
                        <h4>Консультация</h4>
                        <p>Мы анализируем вашу задачу и подбираем оптимальное решение - аренда, ремонт или техническое обслуживание.</p>
                    </div>
                    <div class="work-step">
                        <h4>Согласование</h4>
                        <p>Утверждаем сроки, стоимость и условия работы. Заключаем договор с четкими гарантиями.</p>
                    </div>
                    <div class="work-step">
                        <h4>Выполнение</h4>
                        <p>Наши специалисты оперативно выполняют работы с соблюдением всех технологических стандартов.</p>
                    </div>
                    <div class="work-step">
                        <h4>Гарантийная поддержка</h4>
                        <p>Обеспечиваем сопровождение и гарантийное обслуживание выполненных работ.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Наши услуги -->
    <section class="section-padding" id="services">
        <div class="container">
            <div class="section-title text-center">
                <h2>Наши услуги</h2>
            </div>
            <div class="row row-equal-height">
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-box-content">
                            <div class="feature-icon">
                                <i class="fas fa-truck"></i>
                            </div>
                            <h4>Аренда погрузчиков</h4>
                            <p>Гибкие условия аренды для любых задач вашего бизнеса</p>
                        </div>
                        <a href="arenda.php" class="btn btn-primary mt-2">Подробнее</a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-box-content">
                            <div class="feature-icon">
                                <i class="fas fa-tools"></i>
                            </div>
                            <h4>Ремонт техники</h4>
                            <p>Качественный ремонт любой сложности с гарантией</p>
                        </div>
                        <a href="remont.php" class="btn btn-primary mt-2">Подробнее</a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-box-content">
                            <div class="feature-icon">
                                <i class="fas fa-cogs"></i>
                            </div>
                            <h4>Техобслуживание</h4>
                            <p>Регулярное ТО для бесперебойной работы техники</p>
                        </div>
                        <a href="TO.php" class="btn btn-primary mt-2">Подробнее</a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-box-content">
                            <div class="feature-icon">
                                <i class="fas fa-box-open"></i>
                            </div>
                            <h4>Запчасти</h4>
                            <p>Оригинальные и качественные аналоги в наличии</p>
                        </div>
                        <a href="zapchasti.php" class="btn btn-primary mt-2">Подробнее</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Наши преимущества -->
    <section class="section-padding bg-light" id="advantages">
        <div class="container">
            <div class="section-title text-center">
                <h2>Наши преимущества</h2>
            </div>
            <div class="row row-equal-height">
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-check"></i>
                        </div>
                        <h4>Надежность</h4>
                        <p>Работаем с 2008 года. Гарантируем качество и соблюдение сроков.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <h4>Оперативность</h4>
                        <p>Выезд специалистов в день обращения. Срочный ремонт и доставка.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-user-tie"></i>
                        </div>
                        <h4>Профессионализм</h4>
                        <p>Опытные мастера с сертификатами. Современное оборудование.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <h4>Гибкие условия</h4>
                        <p>Индивидуальный подход к каждому клиенту. Разные варианты оплаты.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Почему аренда -->
    <section class="section-padding" id="rent">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="section-title">
                        <h2>Почему лучше арендовать погрузчик?</h2>
                    </div>
                    <p class="lead">Современные погрузчики - это высокоэффективное и надежное решение для любых задач по перемещению грузов.</p>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Экономия на капитальных затратах</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Гибкость в использовании</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Отсутствие затрат на обслуживание</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Возможность обновления техники</li>
                    </ul>
                    <div class="text-center mt-4">
                        <a href="arenda.php" class="btn btn-primary btn-lg">Арендовать</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="arendaglv.png" alt="Аренда" class="img-fluid rounded shadow">
                </div>
            </div>
        </div>
    </section>

    <!-- Модели -->
    <section class="section-padding bg-light" id="models">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <img src="modeli.png" alt="Бренды" class="img-fluid rounded shadow">
                </div>
                <div class="col-md-6">
                    <div class="section-title">
                        <h2>Какие модели предлагаем</h2>
                    </div>
                    <p class="lead">В наличии и под заказ - качественные запчасти для техники всех популярных марок.</p>
                    <p>Мы работаем с такими брендами как Komatsu, YALE, Toyota, Hyster, Heli, Still, Combilift, Terex. Оригинальные и проверенные аналоги: фильтры, двигатели, гидравлика, электроника, шины и многое другое.</p>
                    <div class="text-center mt-4">
                        <a href="zapchasti.php" class="btn btn-primary btn-lg">Заказать</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Подвал -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>ЯЗРП</h5>
                    <p>Ярославский завод по ремонту погрузчиков - профессиональные услуги по аренде, ремонту и обслуживанию складской техники.</p>
                </div>
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>Меню</h5>
                    <ul class="list-unstyled">
                        <li><a href="glavnaya.php" class="text-white">О компании</a></li>
                        <li><a href="arenda.php" class="text-white">Аренда</a></li>
                        <li><a href="remont.php" class="text-white">Ремонт</a></li>
                        <li><a href="TO.php" class="text-white">Техобслуживание</a></li>
                        <li><a href="zapchasti.php" class="text-white">Запчасти</a></li>
                        <li><a href="kontakti.php" class="text-white">Контакты</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Контакты</h5>
                    <address>
                        <p><i class="fas fa-map-marker-alt me-2"></i> 150008, г. Ярославль, пр-т. Машиностроителей, д. 83, стр.14</p>
                    </address>
                    <div class="mt-3">
                        <h6>Отдел продажи зап.частей:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-30, +7 (903) 638-49-22</p>
                        <p><i class="fas fa-envelope me-2"></i> 67yzrp@mail.ru</p>
                    </div>
                    <div class="mt-3">
                        <h6>Отдел аренды:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-32, +7 (903) 692-36-36, +7 (903) 828-57-58</p>
                        <p><i class="fas fa-envelope me-2"></i> arenda3636@bk.ru, yzrp@inbox.ru</p>
                    </div>
                </div>
            </div>
            <hr class="my-4 bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const currentUrl = window.location.pathname.split("/").pop();
        const navLinks = document.querySelectorAll('.navbar-nav .nav-link');

        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentUrl || (href === '#' && window.location.hash)) {
                link.classList.add('active');
            }
        });
        
        // Плавная прокрутка для всех ссылок
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    window.scrollTo({
                        top: target.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
    });
    </script>
</body>
</html>