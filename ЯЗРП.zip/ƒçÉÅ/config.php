<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'localhost';
$user = 'root';
$pass = '';
$name = 'yazrp'; // имя бд
$link = mysqli_connect($host, $user, $pass, $name);

if (!$link) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

function isAuthorized() {
    return isset($_SESSION['user']['id_user']);
}

function isAdmin($link) {
    if (!isAuthorized()) return false;

    $userId = $_SESSION['user']['id_user'];

    $query = "SELECT r.nazv_role 
              FROM users u
              JOIN role r ON u.id_role = r.id_role
              WHERE u.id_user = ?";
    
    $stmt = mysqli_prepare($link, $query);
    if (!$stmt) return false;

    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $roleName);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    return $roleName === 'Администратор';
}
?>