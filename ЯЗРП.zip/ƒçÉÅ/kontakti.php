<?php
session_start();
?>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЯЗРП - Аренда и ремонт погрузчиков</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #253482;
            --secondary-color: #FF6B00;
        }
                .contact-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            border-top: 5px solid var(--primary-color);
            height: 700px;
        }
        .contact-title {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 15px;
        }
        .contact-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 80px;
            height: 3px;
            background: var(--secondary-color);
        }
        .contact-info {
            margin-bottom: 25px;
        }
        .contact-info i {
            color: var(--secondary-color);
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        .map-container {
            height: 400px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        .map-container iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
        .page-title {
            background: linear-gradient(to right, var(--primary-color), #3a4ba8);
            color: white;
            padding: 20px 0;
            margin-bottom: 40px;
        }
        .page-title h3 {
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
        }
        .top-bar {
            background-color: var(--primary-color);
            height: 20px;
        }
        .header-info {
            background-color: #ffffff;
            padding: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-nav .nav-link.active {
            color: var(--secondary-color) !important;
            font-weight: bold;
            position: relative;
        }
        .navbar-nav .nav-link.active:after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--secondary-color);
        }
        .logo-and-text {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .header-info img {
            height: 60px;
            transition: transform 0.3s;
        }
        .header-info img:hover {
            transform: scale(1.05);
        }
        .header-text .title {
            font-weight: bold;
            font-size: 1.2rem;
            color: #000;
        }
        .header-text .location {
            font-size: 1rem;
            color: #333;
        }
        .divider {
            border-left: 1px solid #ccc;
            height: 50px;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-size: 1.10rem;
            padding: 0.50rem 1.5rem;
            border-radius: 0.5rem;
            transition: all 0.3s;
            font-weight: 500;
        }
        .btn-primary:hover {
            background-color: #1a285f;
            border-color: #1a285f;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .btn-orange {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
            color: white;
        }
        .btn-orange:hover {
            background-color: #e05d00;
            border-color: #e05d00;
        }
        .carousel-caption {
            top: 50%;
            transform: translateY(-50%);
            bottom: auto;
            background-color: rgba(37, 52, 130, 0.85);
            padding: 30px;
            border-radius: 15px;
            width: 80%;
            max-width: 800px;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }
        .carousel-caption h3 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        .carousel-caption p {
            font-size: 1.2rem;
            margin-bottom: 25px;
        }
        .carousel-indicators button {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin: 0 5px;
            background-color: rgba(255, 255, 255, 0.5);
            border: none;
            transition: background-color 0.3s ease;
        }
        .carousel-indicators .active {
            background-color: white;
        }
        .navbar-custom { 
            background-color: var(--primary-color) !important; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .navbar-custom .nav-link { 
            color: white !important; 
            padding: 10px 15px;
            transition: all 0.3s;
        }
        .navbar-custom .nav-link:hover {
            color: var(--secondary-color) !important;
        }
        .carousel-item {
            height: 600px;
        }
        .carousel-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }
        .section-padding { 
            padding: 80px 15px; 
        }
        .section-title {
            position: relative;
            margin-bottom: 50px;
        }
        .section-title h2 {
            font-weight: 700;
            color: var(--primary-color);
            position: relative;
            display: inline-block;
            padding-bottom: 15px;
        }
        .section-title h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--secondary-color);
        }
        .feature-box {
            text-align: center;
            padding: 30px 20px;
            margin-bottom: 30px;
            transition: all 0.3s;
            border-radius: 10px;
        }
        .feature-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .feature-icon {
            width: 100px;
            height: 100px;
            background: var(--secondary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
            transition: all 0.3s;
        }
        .feature-box:hover .feature-icon {
            background: var(--primary-color);
            transform: rotateY(180deg);
        }
        .feature-box h4 {
            font-weight: 600;
            margin: 15px 0;
            color: var(--primary-color);
        }
        .bg-light {
            background-color: #f9f9f9 !important;
        }
        .footer { 
            background: #222; 
            color: #fff; 
            padding: 40px 15px; 
        }
        .footer p {
            margin-bottom: 0;
        }
        .page-title {
            background: linear-gradient(to right, var(--primary-color), #3a4ba8);
            color: white;
            padding: 20px 0;
            margin-bottom: 40px;
        }
        .page-title h3 {
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        .work-steps {
            counter-reset: step-counter;
        }
        .work-step {
            position: relative;
            padding-left: 80px;
            margin-bottom: 30px;
        }
        .work-step:before {
            counter-increment: step-counter;
            content: counter(step-counter);
            position: absolute;
            left: 0;
            top: 0;
            width: 60px;
            height: 60px;
            background: var(--secondary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
        }
        .stats-box {
            background: var(--primary-color);
            color: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
        }
        .stats-number {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .stats-label {
            font-size: 1.2rem;
        }
        
        /* Изменения для адаптивности */
        .navbar-custom .navbar-toggler {
            order: -1;
        }
        
        .navbar-custom .navbar-collapse {
            order: 1;
        }
        
        .navbar-custom .user-actions {
            order: 2;
            margin-left: auto;
            display: flex;
            align-items: center;
        }
        
        @media (max-width: 992px) {
            .navbar-custom .user-actions {
                order: 1;
                margin-left: 0;
                width: 100%;
                justify-content: flex-end;
                padding: 10px 0;
            }
            
            .carousel-item {
                height: 400px;
            }
            
            .carousel-caption {
                width: 90%;
                padding: 15px;
            }
            
            .carousel-caption h3 {
                font-size: 1.5rem;
            }
            
            .carousel-caption p {
                font-size: 1rem;
            }
            
            .work-step {
                padding-left: 60px;
            }
            
            .work-step:before {
                width: 40px;
                height: 40px;
                font-size: 18px;
            }
        }
        
        .header-info {
            flex-direction: row !important;
        }
        
        .search-login {
            margin-top: 0 !important;
        }
    </style>
</head>
<body>
    <!-- Верхняя синяя полоса -->
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="d-flex align-items-center">
            <a href="glavnaya.php">
                <img src="logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3" style="border-left: 1px solid #ccc; height: 50px;"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <!-- Навигация -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
                    <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
                    <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
                    <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
                    <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
                    <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
                    <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
                    <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
                </ul>
            </div>
                
                <div class="user-actions">
                    <?php if (isset($_SESSION['user'])): ?>
                        <div class="d-flex gap-3 align-items-center">
                            <?php if ($_SESSION['user']['id_role'] == 1): ?>
                                <a class="nav-link" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                            <?php endif; ?>
                            <a class="nav-link" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                            <?php if ($_SESSION['user']['id_role'] != 1): ?>
                                <a class="nav-link" href="cart.php" style="color: white;"><i class="fas fa-shopping-cart"></i></a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <a class="btn btn-outline-light" href="login.php">Войти</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Остальной код остается без изменений -->
    <!-- Слайдер -->
    <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="slider1.png" class="d-block w-100" alt="Аренда погрузчиков">
                <div class="carousel-caption">
                    <h3>Профессиональный ремонт погрузчиков</h3>
                    <p>Быстрое восстановление работоспособности любой техники с гарантией качества</p>
                    <a href="remont.php" class="btn btn-orange btn-lg">Подробнее</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder2.png" class="d-block w-100" alt="Ремонт техники">
                <div class="carousel-caption">
                    <h3>Аренда погрузчиков по выгодным ценам</h3>
                    <p>Гибкие условия для вашего бизнеса - от часа до нескольких лет</p>
                    <a href="arenda.php" class="btn btn-orange btn-lg">Выбрать технику</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder3.png" class="d-block w-100" alt="Запчасти">
                <div class="carousel-caption">
                    <h3>Оригинальные запчасти в наличии</h3>
                    <p>Быстрая поставка комплектующих для всех популярных марок погрузчиков</p>
                    <a href="zapchasti.php" class="btn btn-orange btn-lg">Каталог запчастей</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slider4.png" class="d-block w-100" alt="Техобслуживание">
                <div class="carousel-caption">
                    <h3>Регулярное техническое обслуживание</h3>
                    <p>Продлите срок службы вашей техники с нашими сервисными программами</p>
                    <a href="TO.php" class="btn btn-orange btn-lg">Записаться на ТО</a>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Полоса с названием страницы -->
    <section class="page-title">
        <div class="container text-center">
            <h3 class="mb-0">Контакты</h3>
        </div>
    </section>

    <!-- Основной контент -->
    <section class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="contact-card">
                        <h3 class="contact-title">Наш адрес</h3>
                        <div class="contact-info">
                            <p><i class="fas fa-map-marker-alt"></i> 150008, г. Ярославль, пр-т. Машиностроителей, д. 83</p>
                        </div>
                        
                        <h3 class="contact-title">Отдел продажи зап.частей</h3>
                        <div class="contact-info">
                            <p><i class="fas fa-phone"></i> (4852) 49-04-30</p>
                            <p><i class="fas fa-mobile-alt"></i> +7 (903) 638 4922</p>
                            <p><i class="fas fa-envelope"></i> 67yzrp@mail.ru</p>
                        </div>
                        
                        <h3 class="contact-title">Отдел аренды</h3>
                        <div class="contact-info">
                            <p><i class="fas fa-phone"></i> (4852) 49-04-32</p>
                            <p><i class="fas fa-mobile-alt"></i> +7 (903) 692 3636</p>
                            <p><i class="fas fa-mobile-alt"></i> +7 (903) 828 5758</p>
                            <p><i class="fas fa-envelope"></i> arenda3636@bk.ru</p>
                            <p><i class="fas fa-envelope"></i> yzrp@inbox.ru</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="contact-card">
                        <h3 class="contact-title">Отдел сервисного обслуживания</h3>
                        <div class="contact-info">
                            <p><i class="fas fa-phone"></i> (4852) 49-04-32</p>
                            <p><i class="fas fa-mobile-alt"></i> +7 (903) 638 8278</p>
                            <p><i class="fas fa-envelope"></i> alex8278@mail.ru</p>
                        </div>
                        
                        <h3 class="contact-title">Отдел ремонта</h3>
                        <div class="contact-info">
                            <p><i class="fas fa-phone"></i> (4852) 49-04-30</p>
                            <p><i class="fas fa-mobile-alt"></i> +7 (903) 828 5758</p>
                            <p><i class="fas fa-envelope"></i> tyatanayzrp@mail.ru</p>
                            <p><i class="fas fa-envelope"></i> yzrp@inbox.ru</p>
                        </div>
                        
                        <h3 class="contact-title">Режим работы</h3>
                        <div class="contact-info">
                            <p><i class="fas fa-clock"></i> Понедельник - Пятница: 9:00 - 18:00</p>
                            <p><i class="fas fa-clock"></i> Суббота: выходной</p>
                            <p><i class="fas fa-clock"></i> Воскресенье: выходной</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-12">
                    <h3 class="text-center mb-4" style="color: var(--primary-color);">Мы на карте</h3>
                    <div class="map-container">
                        <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A4e7f9a0c2b7c0d6e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3b3e0e3"></iframe>
                        </div>
                        </div>
    <!-- Подвал -->
        <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const currentUrl = window.location.pathname.split("/").pop();
        const navLinks = document.querySelectorAll('.navbar-nav .nav-link');

        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentUrl || (href === '#' && window.location.hash)) {
                link.classList.add('active');
            }
        });
        
        // Плавная прокрутка для всех ссылок
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    window.scrollTo({
                        top: target.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
    });
    </script>
</body>
</html>