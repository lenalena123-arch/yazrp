<?php
session_start();
require __DIR__ . '/../config.php';

// Проверка прав администратора
if (!isset($_SESSION['user']['id'])) {
    header("Location: ../login.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Получение всех типов запчастей и погрузчиков для выпадающих списков
$tipy_result = mysqli_query($link, "SELECT id_tip_zapch, nazv_tip_zapch FROM tip_zapchasti");
$pogruzchiki_result = mysqli_query($link, "SELECT id_pogr, nazv_pogr FROM pogryzchik");

// Если редактирование — загружаем данные
$zapchast = null;
if ($id > 0) {
    $res = mysqli_query($link, "SELECT * FROM zapchasti WHERE id_zapch = $id");
    $zapchast = mysqli_fetch_assoc($res);
}

// Если форма отправлена
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nazv_zapchasti = mysqli_real_escape_string($link, $_POST['nazv_zapchasti']);
    $id_tip_zapch = (int)$_POST['id_tip_zapch'];
    $tsena = (float)$_POST['tsena'];
    $kolvo_sklad = (int)$_POST['kolvo_sklad'];
    $id_pogr = (int)$_POST['id_pogr'];

    // Обработка изображения
    $imagePath = $zapchast['image'] ?? 'uploads/default.png';
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = '../uploads/';
        $allowedExtensions = ['jpg', 'jpeg', 'png'];
        $fileExtension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        
        if (in_array($fileExtension, $allowedExtensions)) {
            $fileName = uniqid() . '.' . $fileExtension;
            $uploadPath = $uploadDir . $fileName;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
                $imagePath = 'uploads/' . $fileName;
                
                // Удаляем старое изображение, если оно не дефолтное
                if (!empty($zapchast['image']) && $zapchast['image'] != 'uploads/default.png' && file_exists('../' . $zapchast['image'])) {
                    unlink('../' . $zapchast['image']);
                }
            }
        }
    }

    if ($id > 0) {
        $stmt = mysqli_prepare($link, "UPDATE zapchasti SET nazv_zapch=?, id_tip_zapch=?, tsena=?, kolvo_sklad=?, id_pogr=?, image=? WHERE id_zapch=?");
        mysqli_stmt_bind_param($stmt, "sidiisi", $nazv_zapchasti, $id_tip_zapch, $tsena, $kolvo_sklad, $id_pogr, $imagePath, $id);
    } else {
        $stmt = mysqli_prepare($link, "INSERT INTO zapchasti (nazv_zapch, id_tip_zapch, tsena, kolvo_sklad, id_pogr, image) VALUES (?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sidiss", $nazv_zapchasti, $id_tip_zapch, $tsena, $kolvo_sklad, $id_pogr, $imagePath);
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("Location: admin_zapchasti.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $id ? 'Редактировать' : 'Добавить' ?> запчасть - ЯЗРП</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #253482;
      --secondary-color: #FF6B00;
    }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex; 
      flex-direction: column; 
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .top-bar {
      background-color: var(--primary-color);
      height: 20px;
    }
    .header-info {
      background-color: #ffffff;
      padding: 15px;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .logo-and-text {
      display: flex;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    .header-info img {
      height: 60px;
      transition: transform 0.3s;
    }
    .header-info img:hover {
      transform: scale(1.05);
    }
    .header-text .title {
      font-weight: bold;
      font-size: 1.2rem;
      color: #000;
    }
    .header-text .location {
      font-size: 1rem;
      color: #333;
    }
    .divider {
      border-left: 1px solid #ccc;
      height: 50px;
    }
    .navbar-custom { 
      background-color: var(--primary-color) !important; 
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    }
    .navbar-custom .nav-link { 
      color: white !important; 
      padding: 10px 15px;
      transition: all 0.3s;
    }
    .navbar-custom .nav-link:hover {
      color: var(--secondary-color) !important;
    }
    .navbar-nav .nav-link.active {
      color: var(--secondary-color) !important;
      font-weight: bold;
      position: relative;
    }
    .navbar-nav .nav-link.active:after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 100%;
      height: 3px;
      background: var(--secondary-color);
    }

    .form-section {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      padding: 40px 15px;
      background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('../background-pattern.png');
      background-size: cover;
    }

    .form-card {
      width: 100%;
      max-width: 800px;
      padding: 30px;
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      border-top: 5px solid var(--primary-color);
    }

    .form-card h2 {
      margin-bottom: 25px;
      color: var(--primary-color);
      font-weight: 700;
      text-align: center;
      position: relative;
      padding-bottom: 15px;
    }

    .form-card h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: var(--secondary-color);
    }

    .form-control {
      border-radius: 8px;
      padding: 12px 15px;
      border: 1px solid #ddd;
      transition: all 0.3s;
      margin-bottom: 15px;
    }

    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      font-size: 1rem;
      padding: 0.6rem 1.2rem;
      border-radius: 8px;
      transition: all 0.3s;
      font-weight: 500;
    }

    .btn-primary:hover {
      background-color: #1a285f;
      border-color: #1a285f;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .btn-secondary {
      background-color: #6c757d;
      border-color: #6c757d;
    }

    .btn-secondary:hover {
      background-color: #5a6268;
      border-color: #5a6268;
    }

    .image-preview {
      width: 200px;
      height: 200px;
      object-fit: contain;
      border: 1px solid #ddd;
      border-radius: 8px;
      margin-bottom: 15px;
    }

    .footer {
      background: #222;
      color: #fff;
      padding: 30px 15px;
      text-align: center;
    }

    @media (max-width: 768px) {
      .header-info {
        flex-direction: column;
        align-items: flex-start;
      }
      .header-text {
        flex-direction: column;
        align-items: flex-start;
      }
      .divider {
        display: none;
      }
      .form-card {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="d-flex align-items-center">
            <a href="../glavnaya.php">
                <img src="../logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
      <div class="container-fluid d-flex justify-content-between align-items-center">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="../glavnaya.php">О компании</a></li>
            <li class="nav-item"><a class="nav-link" href="../arenda.php">Аренда</a></li>
            <li class="nav-item"><a class="nav-link" href="../remont.php">Ремонт</a></li>
            <li class="nav-item"><a class="nav-link" href="../TO.php">Техобслуживание</a></li>
            <li class="nav-item"><a class="nav-link" href="../zapchasti.php">Запчасти</a></li>
            <li class="nav-item"><a class="nav-link" href="../pogryzchiki.php">Погрузчики</a></li>
            <li class="nav-item"><a class="nav-link" href="../otzivi.php">Отзывы</a></li>
            <li class="nav-item"><a class="nav-link" href="../kontakti.php">Контакты</a></li>
          </ul>
        </div>
        <div class="d-none d-lg-block">
            <?php if (isset($_SESSION['user'])): ?>
                <div class="d-flex gap-3 align-items-center">
                    <a class="nav-link" href="../admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                    <a class="nav-link" href="../profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                </div>
            <?php else: ?>
                <a class="btn btn-outline-light" href="../login.php">Войти</a>
            <?php endif; ?>
        </div>
      </div>
    </nav>

    <section class="form-section">
      <div class="form-card">
        <h2><?= $id ? 'Редактирование' : 'Добавление' ?> запчасти</h2>
        
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $id ?>">

            <div class="mb-3">
                <label class="form-label">Название запчасти</label>
                <input type="text" name="nazv_zapchasti" class="form-control" 
                       value="<?= htmlspecialchars($zapchast['nazv_zapch'] ?? '') ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Тип запчасти</label>
                <select name="id_tip_zapch" class="form-select" required>
                    <option value="">Выберите тип</option>
                    <?php while ($row = mysqli_fetch_assoc($tipy_result)): ?>
                        <option value="<?= $row['id_tip_zapch'] ?>" 
                            <?= ($zapchast['id_tip_zapch'] ?? '') == $row['id_tip_zapch'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($row['nazv_tip_zapch']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Цена</label>
                <input type="number" name="tsena" class="form-control" step="0.01"
                       value="<?= htmlspecialchars($zapchast['tsena'] ?? '') ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Количество на складе</label>
                <input type="number" name="kolvo_sklad" class="form-control" 
                       value="<?= htmlspecialchars($zapchast['kolvo_sklad'] ?? '') ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Погрузчик</label>
                <select name="id_pogr" class="form-select" required>
                    <option value="">Выберите погрузчик</option>
                    <?php while ($row = mysqli_fetch_assoc($pogruzchiki_result)): ?>
                        <option value="<?= $row['id_pogr'] ?>" 
                            <?= ($zapchast['id_pogr'] ?? '') == $row['id_pogr'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($row['nazv_pogr']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Изображение</label>
                <?php if (!empty($zapchast['image'])): ?>
                    <div class="mb-3">
                        <img src="../<?= htmlspecialchars($zapchast['image']) ?>" class="image-preview" id="imagePreview">
                    </div>
                <?php endif; ?>
                <input type="file" name="image" class="form-control" accept="image/jpeg, image/png" onchange="previewImage(this)">
                <small class="text-muted">Допустимые форматы: JPG, PNG</small>
                <input type="hidden" name="current_image" value="<?= htmlspecialchars($zapchast['image'] ?? '') ?>">
            </div>

            <div class="d-flex justify-content-between mt-4">
                <button type="submit" class="btn btn-primary"><?= $id ? 'Обновить' : 'Добавить' ?></button>
                <a href="admin_zapchasti.php" class="btn btn-secondary">Назад</a>
            </div>
        </form>
      </div>
    </section>

    <footer class="footer">
      <div class="container">
        <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function previewImage(input) {
            const preview = document.getElementById('imagePreview');
            if (!preview) {
                const previewContainer = document.createElement('div');
                previewContainer.className = 'mb-3';
                const newPreview = document.createElement('img');
                newPreview.id = 'imagePreview';
                newPreview.className = 'image-preview';
                previewContainer.appendChild(newPreview);
                input.parentNode.insertBefore(previewContainer, input);
            }
            
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>