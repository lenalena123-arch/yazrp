<?php
session_start();
require __DIR__ . '/../config.php';

// Проверка прав администратора
if (!isset($_SESSION['user']['id']) || $_SESSION['user']['id_role'] != 1) {
    header("Location: ../login.php");
    exit();
}

function getEnumValues($link, $table, $column) {
    $result = mysqli_query($link, "SHOW COLUMNS FROM `$table` LIKE '$column'");
    $row = mysqli_fetch_assoc($result);
    preg_match("/^enum\((.*)\)$/", $row['Type'], $matches);
    $vals = explode(",", $matches[1]);
    return array_map(function ($val) {
        return trim($val, "'");
    }, $vals);
}

$models = getEnumValues($link, 'pogryzchik', 'model');
$tip_texniki_values = getEnumValues($link, 'pogryzchik', 'tip_texniki');
$tip_gryza_values = getEnumValues($link, 'pogryzchik', 'tip_gryza');
$id = $_GET['id'] ?? null;
$pogr = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $nazv = $_POST['nazv_pogr'];
    $model = $_POST['model'];
    $tip = $_POST['tip_texniki'];
    $visota = $_POST['visota_podema_gryza'];
    $ves = $_POST['maks_ves_gryza'];
    $tip_gryza = $_POST['tip_gryza'];
    $sposob = $_POST['sposob_obrabotki_gryza'];
    $chastota = $_POST['chastota_ispolzovaniya'];
    $v_nalichii = $_POST['v_nalichii']; // Добавлено получение значения наличия
    
    // Обработка загрузки изображения
    $image = $pogr['image'] ?? 'uploads/default.png'; // Значение по умолчанию
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = '../uploads/';
        $allowedExtensions = ['jpg', 'jpeg', 'png'];
        $fileExtension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        
        if (in_array($fileExtension, $allowedExtensions)) {
            $fileName = uniqid() . '.' . $fileExtension;
            $uploadPath = $uploadDir . $fileName;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
                $image = 'uploads/' . $fileName;
                
                // Удаляем старое изображение, если оно не дефолтное
                if (!empty($pogr['image']) && $pogr['image'] != 'uploads/default.png' && file_exists('../' . $pogr['image'])) {
                    unlink('../' . $pogr['image']);
                }
            }
        }
    }

    if ($id) {
        $stmt = mysqli_prepare($link, "UPDATE pogryzchik SET nazv_pogr=?, model=?, tip_texniki=?, visota_podema_gryza=?, maks_ves_gryza=?, tip_gryza=?, sposob_obrabotki_gryza=?, chastota_ispolzovaniya=?, image=?, v_nalichii=? WHERE id_pogr=?");
        mysqli_stmt_bind_param($stmt, "ssssssssssi", $nazv, $model, $tip, $visota, $ves, $tip_gryza, $sposob, $chastota, $image, $v_nalichii, $id);
    } else {
        $stmt = mysqli_prepare($link, "INSERT INTO pogryzchik (nazv_pogr, model, tip_texniki, visota_podema_gryza, maks_ves_gryza, tip_gryza, sposob_obrabotki_gryza, chastota_ispolzovaniya, image, v_nalichii) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssssssssss", $nazv, $model, $tip, $visota, $ves, $tip_gryza, $sposob, $chastota, $image, $v_nalichii);
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("Location: admin_pogryzchiki.php");
    exit();
}

if ($id) {
    $stmt = mysqli_prepare($link, "SELECT * FROM pogryzchik WHERE id_pogr = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $pogr = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $id ? 'Редактировать' : 'Добавить' ?> погрузчик - ЯЗРП</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #253482;
      --secondary-color: #FF6B00;
    }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex; 
      flex-direction: column; 
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .top-bar {
      background-color: var(--primary-color);
      height: 20px;
    }
    .header-info {
      background-color: #ffffff;
      padding: 15px;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .logo-and-text {
      display: flex;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    .header-info img {
      height: 60px;
      transition: transform 0.3s;
    }
    .header-info img:hover {
      transform: scale(1.05);
    }
    .header-text .title {
      font-weight: bold;
      font-size: 1.2rem;
      color: #000;
    }
    .header-text .location {
      font-size: 1rem;
      color: #333;
    }
    .divider {
      border-left: 1px solid #ccc;
      height: 50px;
    }
    .navbar-custom { 
      background-color: var(--primary-color) !important; 
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    }
    .navbar-custom .nav-link { 
      color: white !important; 
      padding: 10px 15px;
      transition: all 0.3s;
    }
    .navbar-custom .nav-link:hover {
      color: var(--secondary-color) !important;
    }
    .navbar-nav .nav-link.active {
      color: var(--secondary-color) !important;
      font-weight: bold;
      position: relative;
    }
    .navbar-nav .nav-link.active:after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 100%;
      height: 3px;
      background: var(--secondary-color);
    }

    .form-section {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      padding: 40px 15px;
      background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('../background-pattern.png');
      background-size: cover;
    }

    .form-card {
      width: 100%;
      max-width: 800px;
      padding: 30px;
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      border-top: 5px solid var(--primary-color);
    }

    .form-card h2 {
      margin-bottom: 25px;
      color: var(--primary-color);
      font-weight: 700;
      text-align: center;
      position: relative;
      padding-bottom: 15px;
    }

    .form-card h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: var(--secondary-color);
    }

    .form-control {
      border-radius: 8px;
      padding: 12px 15px;
      border: 1px solid #ddd;
      transition: all 0.3s;
      margin-bottom: 15px;
    }

    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      font-size: 1rem;
      padding: 0.6rem 1.2rem;
      border-radius: 8px;
      transition: all 0.3s;
      font-weight: 500;
    }

    .btn-primary:hover {
      background-color: #1a285f;
      border-color: #1a285f;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .btn-secondary {
      background-color: #6c757d;
      border-color: #6c757d;
    }

    .btn-secondary:hover {
      background-color: #5a6268;
      border-color: #5a6268;
    }

    .image-preview {
      width: 200px;
      height: 200px;
      object-fit: contain;
      border: 1px solid #ddd;
      border-radius: 8px;
      margin-bottom: 15px;
    }

    .footer {
      background: #222;
      color: #fff;
      padding: 30px 15px;
      text-align: center;
    }

    @media (max-width: 768px) {
      .header-info {
        flex-direction: column;
        align-items: flex-start;
      }
      .header-text {
        flex-direction: column;
        align-items: flex-start;
      }
      .divider {
        display: none;
      }
      .form-card {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="d-flex align-items-center">
            <a href="../glavnaya.php">
                <img src="../logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
      <div class="container-fluid d-flex justify-content-between align-items-center">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="../glavnaya.php">О компании</a></li>
            <li class="nav-item"><a class="nav-link" href="../arenda.php">Аренда</a></li>
            <li class="nav-item"><a class="nav-link" href="../remont.php">Ремонт</a></li>
            <li class="nav-item"><a class="nav-link" href="../TO.php">Техобслуживание</a></li>
            <li class="nav-item"><a class="nav-link" href="../zapchasti.php">Запчасти</a></li>
            <li class="nav-item"><a class="nav-link" href="../pogryzchiki.php">Погрузчики</a></li>
            <li class="nav-item"><a class="nav-link" href="../otzivi.php">Отзывы</a></li>
            <li class="nav-item"><a class="nav-link" href="../kontakti.php">Контакты</a></li>
          </ul>
        </div>
        <div class="d-none d-lg-block">
            <?php if (isset($_SESSION['user'])): ?>
                <div class="d-flex gap-3 align-items-center">
                    <a class="nav-link" href="../admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                    <a class="nav-link" href="../profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                </div>
            <?php else: ?>
                <a class="btn btn-outline-light" href="../login.php">Войти</a>
            <?php endif; ?>
        </div>
      </div>
    </nav>

    <section class="form-section">
      <div class="form-card">
        <h2><?= $id ? 'Редактирование' : 'Добавление' ?> погрузчика</h2>
        
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $pogr['id_pogr'] ?? '' ?>">

            <div class="mb-3">
                <label class="form-label">Название</label>
                <input type="text" name="nazv_pogr" class="form-control" value="<?= htmlspecialchars($pogr['nazv_pogr'] ?? '') ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Модель</label>
                <select name="model" class="form-select" required>
                    <?php foreach ($models as $val): ?>
                        <option value="<?= htmlspecialchars($val) ?>" <?= ($pogr['model'] ?? '') === $val ? 'selected' : '' ?>>
                            <?= htmlspecialchars($val) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Тип техники</label>
                <select name="tip_texniki" class="form-select">
                    <?php foreach ($tip_texniki_values as $val): ?>
                        <option value="<?= htmlspecialchars($val) ?>" <?= ($pogr['tip_texniki'] ?? '') === $val ? 'selected' : '' ?>>
                            <?= htmlspecialchars($val) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Высота подъема груза</label>
                <input type="text" name="visota_podema_gryza" class="form-control" value="<?= htmlspecialchars($pogr['visota_podema_gryza'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Максимальный вес груза</label>
                <input type="text" name="maks_ves_gryza" class="form-control" value="<?= htmlspecialchars($pogr['maks_ves_gryza'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Тип груза</label>
                <select name="tip_gryza" class="form-select">
                    <?php foreach ($tip_gryza_values as $val): ?>
                        <option value="<?= htmlspecialchars($val) ?>" <?= ($pogr['tip_gryza'] ?? '') === $val ? 'selected' : '' ?>>
                            <?= htmlspecialchars($val) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Способ обработки груза</label>
                <input type="text" name="sposob_obrabotki_gryza" class="form-control" value="<?= htmlspecialchars($pogr['sposob_obrabotki_gryza'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Частота использования</label>
                <input type="text" name="chastota_ispolzovaniya" class="form-control" value="<?= htmlspecialchars($pogr['chastota_ispolzovaniya'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">В наличии</label>
                <div class="d-flex gap-3">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="v_nalichii" id="v_nalichii_yes" value="Да" <?= ($pogr['v_nalichii'] ?? '') === 'Да' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="v_nalichii_yes">Да</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="v_nalichii" id="v_nalichii_no" value="НеТ" <?= ($pogr['v_nalichii'] ?? '') === 'НеТ' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="v_nalichii_no">Нет</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="v_nalichii" id="v_nalichii_customer" value="У заказчика" <?= ($pogr['v_nalichii'] ?? '') === 'У заказчика' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="v_nalichii_customer">У заказчика</label>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Изображение</label>
                <?php if (!empty($pogr['image'])): ?>
                    <div class="mb-3">
                        <img src="../<?= htmlspecialchars($pogr['image']) ?>" class="image-preview" id="imagePreview">
                    </div>
                <?php endif; ?>
                <input type="file" name="image" class="form-control" accept="image/jpeg, image/png" onchange="previewImage(this)">
                <small class="text-muted">Допустимые форматы: JPG, PNG</small>
                <input type="hidden" name="current_image" value="<?= htmlspecialchars($pogr['image'] ?? '') ?>">
            </div>

            <div class="d-flex justify-content-between mt-4">
                <button type="submit" class="btn btn-primary"><?= $id ? 'Обновить' : 'Добавить' ?></button>
                <a href="admin_pogryzchiki.php" class="btn btn-secondary">Назад</a>
            </div>
        </form>
      </div>
    </section>

    <footer class="footer">
      <div class="container">
        <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function previewImage(input) {
            const preview = document.getElementById('imagePreview');
            if (!preview) {
                const previewContainer = document.createElement('div');
                previewContainer.className = 'mb-3';
                const newPreview = document.createElement('img');
                newPreview.id = 'imagePreview';
                newPreview.className = 'image-preview';
                previewContainer.appendChild(newPreview);
                input.parentNode.insertBefore(previewContainer, input);
            }
            
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>