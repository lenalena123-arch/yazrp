<?php
session_start();
require __DIR__ . '/../config.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($link, "DELETE FROM korzina WHERE id_user = $id");
        mysqli_query($link, "DELETE FROM otzivi WHERE id_user = $id");
                mysqli_query($link, "DELETE FROM zayavki WHERE id_user = $id");
    mysqli_query($link, "DELETE FROM users WHERE id_user = $id");
    header("Location: admin_users.php");
    exit;
}

$sql = "SELECT users.*, role.nazv_role FROM users 
        LEFT JOIN role ON users.id_role = role.id_role";
$result = mysqli_query($link, $sql);
?>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЯЗРП - Аренда и ремонт погрузчиков</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial, sans-serif; }
        .top-bar {
            background-color: #253482;
            height: 20px;
        }
        .header-info {
            background-color: #ffffff;
            padding: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
        }
        .navbar-nav .nav-link.active {
    color: orange !important;
    font-weight: bold;
}
        .logo-and-text {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .header-info img {
            height: 60px;
        }
        .header-text {
            display: flex;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        .header-text .title {
            font-weight: bold;
            font-size: 1.2rem;
            color: #000;
        }
        .header-text .location {
            font-size: 1rem;
            color: #333;
        }
        .divider {
            border-left: 1px solid #ccc;
            height: 50px;
        }
        .btn-primary {
    background-color: #253482;
    border-color: #253482;
    font-size: 1.10rem; /* Увеличенный текст */
    padding: 0.50rem 1rem; /* Увеличенные отступы */
    border-radius: 0.5rem; /* Чуть более округлые */
    transition: background-color 0.3s, transform 0.2s;
}

.btn-primary:hover {
    background-color: #1a285f; /* Чуть темнее при наведении */
    border-color: #1a285f;
    transform: scale(1.05); /* Лёгкое увеличение */
}
        .navbar-custom { background-color: #253482 !important; }
        .navbar-custom .nav-link { color: white !important; }
        .carousel-item {
    height: 500px; /* Увеличенная высота слайдера */
}
        .hero { display: none; }
        .section-padding { padding: 60px 15px; }
        .footer {
    background: #333;
    color: #fff;
    padding: 20px 15px;
    text-align: center;
    margin-top: auto;
}
        .search-login {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        @media (max-width: 768px) {
            .header-info {
                flex-direction: column;
                align-items: flex-start;
            }
            .header-text {
                flex-direction: column;
                align-items: flex-start;
            }
            .divider {
                display: none;
            }
            .search-login {
                width: 100%;
                justify-content: flex-start;
                margin-top: 10px;
            }
        }
        thead.table-dark th {
    background-color: #253482 !important;
    color: #fff;
}

.btn-add {
    background-color: #253482;
    border-color: #253482;
    font-size: 1.2rem;
    padding: 0.7rem 1.5rem;
    border-radius: 0.6rem;
    color: #fff;
    transition: background-color 0.3s, transform 0.2s;
}

.btn-add:hover {
    background-color: #1a285f;
    border-color: #1a285f;
    transform: scale(1.05);
    color: #fff;
}
.btn-back {
    min-width: 120px;
    font-size: 1.2rem;
    padding: 0.7rem 1.5rem;
    border-radius: 0.6rem;
    text-align: center;
}
.btn-back:hover {
    background-color: #898989;
    transform: scale(1.05);
    color: #fff;
}
.action-buttons a {
    min-width: 90px;
    margin: 5px;
}
    </style>
</head>
<body>
<div class="wrapper d-flex flex-column min-vh-100">
    <!-- Верхняя синяя полоса -->
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <div class="logo-and-text">
            <img src="../logo.png" alt="Логотип">
            <div class="header-text">
                <div class="title">
                    Ярославский завод по<br>ремонту погрузчиков
                </div>
                <div class="divider"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>
        <div class="search-login">
            <input type="text" class="form-control" placeholder="Поиск">
            <button class="btn btn-outline-primary">Поиск</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container-fluid d-flex justify-content-between align-items-center">
        <!-- Кнопка-бургер -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Центрированное меню -->
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="../glavnaya.php">Главная</a></li>
                <li class="nav-item"><a class="nav-link" href="../company.php">О компании</a></li>
                <li class="nav-item"><a class="nav-link" href="../arenda.php">Аренда</a></li>
                <li class="nav-item"><a class="nav-link" href="../remont.php">Ремонт</a></li>
                <li class="nav-item"><a class="nav-link" href="../TO.php">Техобслуживание</a></li>
                <li class="nav-item"><a class="nav-link" href="../zapchasti.php">Запчасти</a></li>
                <li class="nav-item"><a class="nav-link" href="../pogryzchiki.php">Погрузчики</a></li>
                <li class="nav-item"><a class="nav-link" href="../otzivi.php">Отзывы</a></li>
                <li class="nav-item"><a class="nav-link" href="../kontakti.php">Контакты</a></li>
            </ul>
        </div>

        <div class="d-none d-lg-block">
<?php if (isset($_SESSION['user'])): ?>
    <div class="d-flex gap-3 align-items-center">
        <?php if ($_SESSION['user']['id_role'] == 1): ?>
            <a class="nav-link" href="admin.php" style="color: white;">⚙️</a>
        <?php endif; ?>
        <a class="nav-link" href="profile.php" style="color: white;">🙎🏻‍♂️</a>
        <?php if ($_SESSION['user']['id_role'] != 1): ?>
            <a class="nav-link" href="cart.php" style="color: white;">🛒</a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <a class="nav-item" href="login.php" style="color: white;">Войти</a>
<?php endif; ?>
</div>
    </div>
</nav>
<div class="container mt-5">
    <h2 class="text-center mb-4">Список пользователей</h2>
    <table class="table table-bordered table-striped align-middle">
        <thead>
            <tr>
                <th>ФИО</th>
                <th>Организация</th>
                <th>Адрес</th>
                <th>Телефон</th>
                <th>Email</th>
                <th>Логин</th>
                <th>Роль</th>
                <th>Изображение</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= htmlspecialchars($row['familia'] . ' ' . $row['imya'] . ' ' . $row['otchestvo']) ?></td>
                <td><?= htmlspecialchars($row['nazv_ofisa']) ?></td>
                <td><?= htmlspecialchars($row['adres_ofisa']) ?></td>
                <td><?= htmlspecialchars($row['telefon']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['login']) ?></td>
                <td><?= htmlspecialchars($row['nazv_role']) ?></td>
                <td>
                    <?php if (!empty($row['image'])): ?>
                        <img src="<?= htmlspecialchars($row['image']) ?>" width="100" class="img-thumbnail">
                    <?php else: ?>
                        <span>Нет фото</span>
                    <?php endif; ?>
                </td>
                <td class="action-buttons">
                    <a href="AddEditUsers.php?id=<?= $row['id_user'] ?>" class="btn btn-warning btn-sm">Изменить</a>
                    <a href="admin_users.php?delete=<?= $row['id_user'] ?>" class="btn btn-danger btn-sm"
                       onclick="return confirm('Удалить пользователя?')">Удалить</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-center gap-3 mt-4">
        <a href="AddEditUsers.php" class="btn btn-primary">Добавить пользователя</a>
        <a href="../admin.php" class="btn btn-secondary">Назад</a>
    </div>
</div>
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
        </div>
    </footer>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>