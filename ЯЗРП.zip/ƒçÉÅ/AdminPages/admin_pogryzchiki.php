<?php
session_start();

require __DIR__ . '/../config.php';
if (!isset($_SESSION['user']['id'])) {
    header("Location: ../login.php");
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // Сначала получаем информацию о изображении для удаления
    $result = mysqli_query($link, "SELECT image FROM pogryzchik WHERE id_pogr = $id");
    $row = mysqli_fetch_assoc($result);
    
    // Удаляем запись из БД
    mysqli_query($link, "DELETE FROM pogryzchik WHERE id_pogr = $id");
    
    // Удаляем файл изображения, если он не дефолтный
    if (!empty($row['image']) && $row['image'] != 'uploads/default.png' && file_exists('../' . $row['image'])) {
        unlink('../' . $row['image']);
    }
    
    header("Location: admin_pogryzchiki.php");
    exit;
}

$sql = "SELECT * FROM pogryzchik";
$result = mysqli_query($link, $sql);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель - Погрузчики</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #253482;
            --secondary-color: #FF6B00;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex; 
            flex-direction: column; 
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .top-bar {
            background-color: var(--primary-color);
            height: 20px;
        }
        .header-info {
            background-color: #ffffff;
            padding: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
        }
        .logo-and-text {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .header-info img {
            height: 60px;
            transition: transform 0.3s;
        }
        .header-info img:hover {
            transform: scale(1.05);
        }
        .header-text .title {
            font-weight: bold;
            font-size: 1.2rem;
            color: #000;
        }
        .header-text .location {
            font-size: 1rem;
            color: #333;
        }
        .divider {
            border-left: 1px solid #ccc;
            height: 50px;
        }
        .navbar-custom { 
            background-color: var(--primary-color) !important; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .navbar-custom .nav-link { 
            color: white !important; 
            padding: 10px 15px;
            transition: all 0.3s;
        }
        .navbar-custom .nav-link:hover {
            color: var(--secondary-color) !important;
        }
        .navbar-nav .nav-link.active {
            color: var(--secondary-color) !important;
            font-weight: bold;
            position: relative;
        }
        .navbar-nav .nav-link.active:after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--secondary-color);
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-size: 1rem;
            padding: 0.6rem 1.2rem;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
        }
        .btn-primary:hover {
            background-color: #1a285f;
            border-color: #1a285f;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
        .footer {
            background: #222;
            color: #fff;
            padding: 30px 15px;
            text-align: center;
        }
        .table-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            padding: 20px;
            margin-top: 20px;
        }
        .table-title {
            color: var(--primary-color);
            font-weight: 700;
            text-align: center;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 15px;
        }
        .table-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--secondary-color);
        }
        thead.table-dark th {
            background-color: var(--primary-color) !important;
            color: #fff;
        }
        .btn-add {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-size: 1.2rem;
            padding: 0.7rem 1.5rem;
            border-radius: 0.6rem;
            color: #fff;
            transition: all 0.3s;
        }
        .btn-add:hover {
            background-color: #1a285f;
            border-color: #1a285f;
            transform: scale(1.05);
            color: #fff;
        }
        .btn-back {
            min-width: 120px;
            font-size: 1.2rem;
            padding: 0.7rem 1.5rem;
            border-radius: 0.6rem;
            text-align: center;
        }
        .btn-back:hover {
            background-color: #898989;
            transform: scale(1.05);
            color: #fff;
        }
        .action-buttons a {
            min-width: 90px;
            margin: 2px;
        }
        .img-thumbnail {
            max-width: 150px;
            height: auto;
            object-fit: contain;
        }
        @media (max-width: 768px) {
            .header-info {
                flex-direction: column;
                align-items: flex-start;
            }
            .header-text {
                flex-direction: column;
                align-items: flex-start;
            }
            .divider {
                display: none;
            }
            .search-login {
                width: 100%;
                justify-content: flex-start;
                margin-top: 10px;
            }
            .action-buttons {
                display: flex;
                flex-direction: column;
            }
            .action-buttons a {
                width: 100%;
                margin: 2px 0;
            }
        }
    </style>
</head>
<body>
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="d-flex align-items-center">
            <a href="../glavnaya.php">
                <img src="../logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск погрузчиков...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="../glavnaya.php">О компании</a></li>
                    <li class="nav-item"><a class="nav-link" href="../arenda.php">Аренда</a></li>
                    <li class="nav-item"><a class="nav-link" href="../remont.php">Ремонт</a></li>
                    <li class="nav-item"><a class="nav-link" href="../TO.php">Техобслуживание</a></li>
                    <li class="nav-item"><a class="nav-link" href="../zapchasti.php">Запчасти</a></li>
                    <li class="nav-item"><a class="nav-link" href="../pogryzchiki.php">Погрузчики</a></li>
                    <li class="nav-item"><a class="nav-link" href="../otzivi.php">Отзывы</a></li>
                    <li class="nav-item"><a class="nav-link" href="../kontakti.php">Контакты</a></li>
                </ul>
            </div>
            <div class="d-none d-lg-block">
                <?php if (isset($_SESSION['user'])): ?>
                    <div class="d-flex gap-3 align-items-center">
                        <a class="nav-link" href="../admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                        <a class="nav-link" href="../profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                    </div>
                <?php else: ?>
                    <a class="btn btn-outline-light" href="../login.php">Войти</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <div class="table-container">
            <h2 class="table-title">Список погрузчиков</h2>
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Название</th>
                        <th>Модель</th>
                        <th>Тип техники</th>
                        <th>Высота подъема груза</th>
                        <th>Макс. вес груза</th>
                        <th>Тип груза</th>
                        <th>Изображение</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['nazv_pogr']) ?></td>
                            <td><?= htmlspecialchars($row['model']) ?></td>
                            <td><?= htmlspecialchars($row['tip_texniki']) ?></td>
                            <td><?= htmlspecialchars($row['visota_podema_gryza']) ?></td>
                            <td><?= htmlspecialchars($row['maks_ves_gryza']) ?></td>
                            <td><?= htmlspecialchars($row['tip_gryza']) ?></td>
                            <td>
                                <?php if (!empty($row['image'])): ?>
                                    <img src="../<?= htmlspecialchars($row['image']) ?>" alt="Фото погрузчика" class="img-thumbnail">
                                <?php else: ?>
                                    <span class="text-muted">Нет фото</span>
                                <?php endif; ?>
                            </td>
                            <td class="action-buttons">
                                <a href="AddEditPogryzchiki.php?id=<?= $row['id_pogr'] ?>" class="btn btn-sm btn-warning">Изменить</a>
                                <a href="admin_pogryzchiki.php?delete=<?= $row['id_pogr'] ?>" class="btn btn-sm btn-danger"
                                   onclick="return confirm('Вы уверены, что хотите удалить этот погрузчик?')">Удалить</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            
            <div class="d-flex justify-content-center gap-3 my-4">
                <a href="AddEditPogryzchiki.php" class="btn btn-add">Добавить погрузчик</a>
                <a href="../admin.php" class="btn btn-secondary btn-back">Назад</a>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>
