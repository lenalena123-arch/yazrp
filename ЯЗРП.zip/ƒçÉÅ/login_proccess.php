<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

$login = $_POST['login'] ?? '';
$password = $_POST['parol'] ?? '';

// Проверка на пустые поля
if (empty($login)) {
    echo json_encode(['success' => false, 'message' => 'Введите логин']);
    exit;
}

if (empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Введите пароль']);
    exit;
}

// Подготовленный запрос для защиты от SQL-инъекций
$sql = "SELECT u.*, r.nazv_role FROM users u JOIN role r ON u.id_role = r.id_role WHERE u.login = ?";
$stmt = $link->prepare($sql);
$stmt->bind_param("s", $login);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    
    if (password_verify($password, $user['parol'])) {
        // Сохраняем данные в сессии
        $_SESSION['user'] = [
            'id' => $user['id_user'],
            'login' => $user['login'],
            'fullname' => $user['familia'] . " " . $user['imya'],
            'id_role' => $user['id_role'],
            'nazv_role' => $user['nazv_role'],
        ];

        // Возвращаем успешный ответ
        echo json_encode([
            'success' => true,
            'redirect' => 'glavnaya.php'
        ]);
        exit();
    } else {
        echo json_encode(['success' => false, 'message' => 'Неверный пароль']);
        exit();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Пользователь не найден']);
    exit();
}
?>