<?php
require_once 'config.php';

$roles = [];
$result = $link->query("SELECT id_role, nazv_role FROM role");
while ($row = $result->fetch_assoc()) {
    $roles[] = $row;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Регистрация - ЯЗРП</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #253482;
      --secondary-color: #FF6B00;
    }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex; 
      flex-direction: column; 
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .top-bar {
      background-color: var(--primary-color);
      height: 20px;
    }
    .header-info {
      background-color: #ffffff;
      padding: 15px;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .logo-and-text {
      display: flex;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    .header-info img {
      height: 60px;
      transition: transform 0.3s;
    }
    .header-info img:hover {
      transform: scale(1.05);
    }
    .header-text .title {
      font-weight: bold;
      font-size: 1.2rem;
      color: #000;
    }
    .header-text .location {
      font-size: 1rem;
      color: #333;
    }
    .divider {
      border-left: 1px solid #ccc;
      height: 50px;
    }
    .navbar-custom { 
      background-color: var(--primary-color) !important; 
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    }
    .navbar-custom .nav-link { 
      color: white !important; 
      padding: 10px 15px;
      transition: all 0.3s;
    }
    .navbar-custom .nav-link:hover {
      color: var(--secondary-color) !important;
    }
    .navbar-nav .nav-link.active {
      color: var(--secondary-color) !important;
      font-weight: bold;
      position: relative;
    }
    .navbar-nav .nav-link.active:after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 100%;
      height: 3px;
      background: var(--secondary-color);
    }

    .auth-section {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 15px;
      background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('background-pattern.png');
      background-size: cover;
    }

    .auth-card {
      width: 100%;
      max-width: 500px;
      padding: 30px;
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      border-top: 5px solid var(--primary-color);
    }

    .auth-card h2 {
      margin-bottom: 25px;
      color: var(--primary-color);
      font-weight: 700;
      text-align: center;
      position: relative;
      padding-bottom: 15px;
    }

    .auth-card h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: var(--secondary-color);
    }

    .form-control {
      border-radius: 8px;
      padding: 12px 15px;
      border: 1px solid #ddd;
      transition: all 0.3s;
      height: 40px
    }

    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      font-size: 1.10rem;
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      transition: all 0.3s;
      font-weight: 500;
      width: 100%;
    }

    .btn-primary:hover {
      background-color: #1a285f;
      border-color: #1a285f;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .auth-card a {
      color: var(--primary-color);
      text-decoration: none;
      font-weight: 500;
    }

    .auth-card a:hover {
      color: var(--secondary-color);
      text-decoration: underline;
    }

    .avatar-upload {
      text-align: center;
      margin: 20px 0;
    }

    .avatar-preview {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      border: 3px solid var(--primary-color);
      object-fit: cover;
      margin-bottom: 15px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .avatar-preview:hover {
      transform: scale(1.05);
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }

    .avatar-upload label {
      display: block;
      margin-bottom: 10px;
      font-weight: 500;
      color: var(--primary-color);
    }

    .form-floating label {
      color: #666;
    }

    .footer {
      background: #222;
      color: #fff;
      padding: 30px 15px;
      text-align: center;
    }

    .form-title {
      font-size: 1.1rem;
      color: var(--primary-color);
      font-weight: 600;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }

    @media (max-width: 768px) {
      .header-info {
        flex-direction: column;
        align-items: flex-start;
      }
      .header-text {
        flex-direction: column;
        align-items: flex-start;
      }
      .divider {
        display: none;
      }
      .auth-card {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
<div class="container-fluid header-info">
    <!-- Логотип и текст -->
    <div class="d-flex align-items-center">
        <a href="glavnaya.php">
            <img src="logo.png" alt="Логотип" class="me-3">
        </a>
        <div class="d-flex align-items-center">
            <div class="header-text me-3">
                <div class="title">
                    Ярославский завод<br>по ремонту погрузчиков
                </div>
            </div>
            <div class="divider me-3" style="border-left: 1px solid #ccc; height: 50px;"></div>
            <div class="location">
                г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
            </div>
        </div>
    </div>

    <!-- Поисковая строка и кнопка -->
    <div class="d-flex align-items-center ms-auto">
        <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
        <button class="btn btn-outline-primary">Найти</button>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
        <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
        <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
        <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
        <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
        <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
        <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
        <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="auth-section">
  <div class="auth-card">
    <h2>Регистрация</h2>
    
    <form action="registr_hand.php" method="POST" enctype="multipart/form-data">
      <div class="form-title">Личные данные</div>
      <div class="row">
        <div class="col-md-4 mb-3">
          <label class="form-label">Фамилия</label>
          <input type="text" class="form-control" name="familia" required>
        </div>
        <div class="col-md-4 mb-3">
          <label class="form-label">Имя</label>
          <input type="text" class="form-control" name="imya" required>
        </div>
        <div class="col-md-4 mb-3">
          <label class="form-label">Отчество</label>
          <input type="text" class="form-control" name="otchestvo">
        </div>
      </div>

      <div class="form-title">Контактная информация</div>
      <div class="mb-3">
        <label class="form-label">Название организации</label>
        <input type="text" class="form-control" name="nazv_ofisa">
      </div>
      <div class="mb-3">
        <label class="form-label">Адрес офиса</label>
        <input type="text" class="form-control" name="adres_ofisa">
      </div>
      <div class="mb-3">
        <label class="form-label">Телефон</label>
        <input type="text" class="form-control" name="telefon">
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" required>
      </div>

      <div class="form-title">Данные для входа</div>
      <div class="mb-3">
        <label class="form-label">Логин</label>
        <input type="text" class="form-control" name="login" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Пароль</label>
        <input type="password" class="form-control" name="parol" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Подтвердите пароль</label>
        <input type="password" class="form-control" name="confirm_password" required>
      </div>

      <div class="avatar-upload">
        <label>Аватар (необязательно)</label>
        <div>
          <img id="avatarPreview" src="defaultAva.png" alt="Превью аватара" class="avatar-preview">
        </div>
        <input type="file" class="form-control d-none" name="avatar" id="avatarInput" accept="image/*" onchange="previewAvatar(this)">
        <button type="button" class="btn btn-outline-primary mt-2" onclick="document.getElementById('avatarInput').click()">Выбрать изображение</button>
      </div>

      <button type="submit" class="btn btn-primary mt-4">Зарегистрироваться</button>
    </form>
    
    <div class="text-center mt-4">
      Уже есть аккаунт? <a href="login.php">Войти</a>
    </div>
  </div>
</section>

   <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>ЯЗРП</h5>
                    <p>Ярославский завод по ремонту погрузчиков - профессиональные услуги по аренде, ремонту и обслуживанию складской техники.</p>
                </div>
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>Меню</h5>
                    <ul class="list-unstyled">
                        <li><a href="glavnaya.php" class="text-white">О компании</a></li>
                        <li><a href="arenda.php" class="text-white">Аренда</a></li>
                        <li><a href="remont.php" class="text-white">Ремонт</a></li>
                        <li><a href="TO.php" class="text-white">Техобслуживание</a></li>
                        <li><a href="zapchasti.php" class="text-white">Запчасти</a></li>
                        <li><a href="kontakti.php" class="text-white">Контакты</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Контакты</h5>
                    <address>
                        <p><i class="fas fa-map-marker-alt me-2"></i> 150008, г. Ярославль, пр-т. Машиностроителей, д. 83, стр.14</p>
                    </address>
                    <div class="mt-3">
                        <h6>Отдел продажи зап.частей:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-30, +7 (903) 638-49-22</p>
                        <p><i class="fas fa-envelope me-2"></i> 67yzrp@mail.ru</p>
                    </div>
                    <div class="mt-3">
                        <h6>Отдел аренды:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-32, +7 (903) 692-36-36, +7 (903) 828-57-58</p>
                        <p><i class="fas fa-envelope me-2"></i> arenda3636@bk.ru, yzrp@inbox.ru</p>
                    </div>
                </div>
            </div>
            <hr class="my-4 bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
            </div>
        </div>
    </footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function previewAvatar(input) {
  const preview = document.getElementById('avatarPreview');
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => preview.src = e.target.result;
    reader.readAsDataURL(input.files[0]);
  }
}
</script>
</body>
</html>