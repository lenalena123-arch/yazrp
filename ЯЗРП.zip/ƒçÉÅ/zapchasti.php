<?php
session_start();
require_once 'config.php';

// Получаем типы запчастей
$tip_query = $link->query("SELECT * FROM tip_zapchasti");
$tip_options = $tip_query->fetch_all(MYSQLI_ASSOC);

// Получаем названия погрузчиков
$pogr_query = $link->query("SELECT * FROM pogryzchik");
$pogr_options = $pogr_query->fetch_all(MYSQLI_ASSOC);

// модели погрузчиков
$modeli_query = $link->query("SELECT DISTINCT model FROM pogryzchik");
$modeli_options = $modeli_query->fetch_all(MYSQLI_ASSOC);
$selected_modeli = $_GET['modeli'] ?? '';

// Получаем данные фильтра
$selected_tip = $_GET['tip'] ?? '';
$selected_pogr = $_GET['pogr'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';

// Формируем условие запроса
$conditions = [];
$params = [];
$types = '';

if ($selected_tip !== '') {
    $conditions[] = "z.id_tip_zapch = ?";
    $params[] = $selected_tip;
    $types .= 'i';
}

if ($selected_modeli !== '') {
    $conditions[] = "p.model = ?";
    $params[] = $selected_modeli;
    $types .= 's';
}

if ($selected_pogr !== '') {
    $conditions[] = "z.id_pogr = ?";
    $params[] = $selected_pogr;
    $types .= 'i';
}

if ($price_min !== '' && $price_max !== '') {
    $conditions[] = "z.tsena BETWEEN ? AND ?";
    $params[] = $price_min;
    $params[] = $price_max;
    $types .= 'dd';
}

$where_sql = $conditions ? "WHERE " . implode(" AND ", $conditions) : "";

// Запрос
$sql = "SELECT z.*, t.nazv_tip_zapch, p.model, p.nazv_pogr 
        FROM zapchasti z 
        JOIN tip_zapchasti t ON z.id_tip_zapch = t.id_tip_zapch 
        JOIN pogryzchik p ON z.id_pogr = p.id_pogr 
        $where_sql";
$stmt = $link->prepare($sql);
if ($types) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$zapchasti = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Запчасти | ЯЗРП</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #253482;
            --secondary-color: #FF6B00;
        }
                .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            display: none;
        }
        .spinner-border {
            width: 3rem;
            height: 3rem;
        }
        .fade-in {
            animation: fadeIn 0.5s;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex; 
            flex-direction: column; 
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .top-bar {
            background-color: var(--primary-color);
            height: 20px;
        }
        .header-info {
            background-color: #ffffff;
            padding: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .logo-and-text {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .header-info img {
            height: 60px;
            transition: transform 0.3s;
        }
        .header-info img:hover {
            transform: scale(1.05);
        }
        .header-text .title {
            font-weight: bold;
            font-size: 1.2rem;
            color: #000;
        }
        .header-text .location {
            font-size: 1rem;
            color: #333;
        }
        .divider {
            border-left: 1px solid #ccc;
            height: 50px;
        }
        .navbar-custom { 
            background-color: var(--primary-color) !important; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .navbar-custom .nav-link { 
            color: white !important; 
            padding: 10px 15px;
            transition: all 0.3s;
        }
        .navbar-custom .nav-link:hover {
            color: var(--secondary-color) !important;
        }
        .navbar-nav .nav-link.active {
            color: var(--secondary-color) !important;
            font-weight: bold;
            position: relative;
        }
        .navbar-nav .nav-link.active:after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--secondary-color);
        }
        
        /* Стили для слайдера */
        .carousel-item {
            height: 600px;
        }
        .carousel-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }
        .carousel-caption {
            top: 50%;
            transform: translateY(-50%);
            bottom: auto;
            background-color: rgba(37, 52, 130, 0.85);
            padding: 30px;
            border-radius: 15px;
            width: 80%;
            max-width: 800px;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }
        .carousel-caption h3 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        .carousel-caption p {
            font-size: 1.2rem;
            margin-bottom: 25px;
        }
        .carousel-indicators [data-bs-target] {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin: 0 5px;
            background-color: rgba(255,255,255,0.5);
        }
        .carousel-indicators .active {
            background-color: white;
        }
        .btn-orange {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
            color: white;
        }
        .btn-orange:hover {
            background-color: #e05d00;
            border-color: #e05d00;
        }
        
        .page-title {
            background: linear-gradient(to right, var(--primary-color), #3a4ba8);
            color: white;
            padding: 20px 0;
            margin-bottom: 40px;
        }
        
        .page-title h3 {
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        
        .filter-section {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            overflow: hidden;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            height: 100%;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .card-img-top {
            height: 200px;
            object-fit: contain;
            padding: 20px;
            background-color: #f8f9fa;
        }
        
        .card-body {
            padding: 20px;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        
        .card-title {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 15px;
        }
        
        .specs {
            margin-bottom: 15px;
        }
        
        .specs div {
            margin-bottom: 8px;
        }
        
        .price {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--secondary-color);
            margin: 15px 0 10px;
        }
        
        .stock {
            font-size: 0.9rem;
            color: #666;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-weight: 500;
            border-radius: 8px;
            padding: 10px;
            transition: all 0.3s;
            margin-top: auto;
        }
        
        .btn-primary:hover {
            background-color: #1a285f;
            border-color: #1a285f;
            transform: translateY(-2px);
        }
        
        .btn-outline-secondary {
            border-radius: 8px;
            padding: 10px;
        }
        
        .no-results {
            text-align: center;
            padding: 50px;
            color: #666;
        }
        
        .footer {
            background: #222;
            color: #fff;
            padding: 30px 15px;
            text-align: center;
            margin-top: auto;
        }
        
        .form-control {
            border-radius: 8px;
            padding: 10px 15px;
            border: 1px solid #ddd;
            height: 40px;
        }
    
        .badge {
            font-weight: 500;
            font-size: 0.8rem;
        }
        
        .badge.bg-success {
            background-color: var(--secondary-color) !important;
        }
        
        @media (max-width: 768px) {
            .header-info {
                flex-direction: column;
                align-items: flex-start;
            }
            .header-text {
                flex-direction: column;
                align-items: flex-start;
            }
            .divider {
                display: none;
            }
            .search-login {
                width: 100%;
                justify-content: flex-start;
                margin-top: 10px;
            }
            .card-img-top {
                height: 150px;
            }
            .carousel-item {
                height: 400px;
            }
            .carousel-caption {
                width: 90%;
                padding: 15px;
            }
            .carousel-caption h3 {
                font-size: 1.5rem;
            }
            .carousel-caption p {
                font-size: 1rem;
            }
        }
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            display: none;
        }
        .spinner-border {
            width: 3rem;
            height: 3rem;
        }
    </style>
</head>
<body>
    <div class="loading-overlay">
    <div class="spinner-border text-light" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<div class="loading-overlay">
    <div class="spinner-border text-light" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<div class="wrapper d-flex flex-column min-vh-100">
    <!-- Верхняя синяя полоса -->
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
<div class="container-fluid header-info">
    <!-- Логотип и текст -->
    <div class="d-flex align-items-center">
        <a href="glavnaya.php">
            <img src="logo.png" alt="Логотип" class="me-3">
        </a>
        <div class="d-flex align-items-center">
            <div class="header-text me-3">
                <div class="title">
                    Ярославский завод<br>по ремонту погрузчиков
                </div>
            </div>
            <div class="divider me-3" style="border-left: 1px solid #ccc; height: 50px;"></div>
            <div class="location">
                г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
            </div>
        </div>
    </div>

    <!-- Поисковая строка и кнопка -->
    <div class="d-flex align-items-center ms-auto">
        <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
        <button class="btn btn-outline-primary">Найти</button>
    </div>
</div>

    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
                    <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
                    <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
                    <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
                    <li class="nav-item"><a class="nav-link active" href="zapchasti.php">Запчасти</a></li>
                    <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
                    <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
                    <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
                </ul>
            </div>
            <div class="d-none d-lg-block">
                <?php if (isset($_SESSION['user'])): ?>
                    <div class="d-flex gap-3 align-items-center">
                        <?php if ($_SESSION['user']['id_role'] == 1): ?>
                            <a class="nav-link" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                        <?php endif; ?>
                        <a class="nav-link" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                        <?php if ($_SESSION['user']['id_role'] != 1): ?>
                            <a class="nav-link" href="cart.php" style="color: white;"><i class="fas fa-shopping-cart"></i></a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <a class="btn btn-outline-light" href="login.php">Войти</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Слайдер -->
    <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="slider1.png" class="d-block w-100" alt="Аренда погрузчиков">
                <div class="carousel-caption">
                    <h3>Профессиональный ремонт погрузчиков</h3>
                    <p>Быстрое восстановление работоспособности любой техники с гарантией качества</p>
                    <a href="remont.php" class="btn btn-orange btn-lg">Подробнее</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder2.png" class="d-block w-100" alt="Ремонт техники">
                <div class="carousel-caption">
                    <h3>Аренда погрузчиков по выгодным ценам</h3>
                    <p>Гибкие условия для вашего бизнеса - от часа до нескольких лет</p>
                    <a href="arenda.php" class="btn btn-orange btn-lg">Выбрать технику</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder3.png" class="d-block w-100" alt="Запчасти">
                <div class="carousel-caption">
                    <h3>Оригинальные запчасти в наличии</h3>
                    <p>Быстрая поставка комплектующих для всех популярных марок погрузчиков</p>
                    <a href="zapchasti.php" class="btn btn-orange btn-lg">Каталог запчастей</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slider4.png" class="d-block w-100" alt="Техобслуживание">
                <div class="carousel-caption">
                    <h3>Регулярное техническое обслуживание</h3>
                    <p>Продлите срок службы вашей техники с нашими сервисными программы</p>
                    <a href="TO.php" class="btn btn-orange btn-lg">Записаться на ТО</a>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Полоса с названием страницы -->
    <section class="page-title">
        <div class="container text-center">
            <h3 class="mb-0">Запчасти</h3>
        </div>
    </section>

    <div class="container mb-5">
        <!-- Фильтры -->
        <div class="filter-section">
            <form id="filterForm" class="row g-3" method="GET">
                <div class="col-md-4">
                    <label class="form-label">Тип запчасти</label>
                    <select name="tip" class="form-select filter-select">
                        <option value="">Все типы</option>
                        <?php foreach ($tip_options as $tip): ?>
                            <option value="<?= $tip['id_tip_zapch'] ?>" <?= $tip['id_tip_zapch'] == $selected_tip ? 'selected' : '' ?>>
                                <?= htmlspecialchars($tip['nazv_tip_zapch']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Модель погрузчика</label>
                    <select name="modeli" class="form-select filter-select">
                        <option value="">Все модели</option>
                        <?php foreach ($modeli_options as $m): ?>
                            <option value="<?= htmlspecialchars($m['model']) ?>" <?= $m['model'] == $selected_modeli ? 'selected' : '' ?>>
                                <?= htmlspecialchars($m['model']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Название погрузчика</label>
                    <select name="pogr" class="form-select filter-select">
                        <option value="">Все погрузчики</option>
                        <?php foreach ($pogr_options as $pogr): ?>
                            <option value="<?= $pogr['id_pogr'] ?>" <?= $pogr['id_pogr'] == $selected_pogr ? 'selected' : '' ?>>
                                <?= htmlspecialchars($pogr['nazv_pogr']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Цена от</label>
                    <div class="input-group">
                        <input type="number" name="price_min" class="form-control filter-input" value="<?= htmlspecialchars($price_min) ?>" placeholder="0">
                        <span class="input-group-text">₽</span>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Цена до</label>
                    <div class="input-group">
                        <input type="number" name="price_max" class="form-control filter-input" value="<?= htmlspecialchars($price_max) ?>" placeholder="999999">
                        <span class="input-group-text">₽</span>
                    </div>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i>Применить фильтры
                    </button>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <a href="zapchasti.php" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-times me-2"></i>Сбросить
                    </a>
                </div>
            </form>
        </div>

        <!-- Список запчастей -->
        <div class="row" id="zapchastiContainer">
            <?php if (!empty($zapchasti)): ?>
                <?php foreach ($zapchasti as $z): ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="position-relative">
                                <img src="<?= htmlspecialchars($z['image']) ?>" class="card-img-top p-3" alt="<?= htmlspecialchars($z['nazv_zapch']) ?>">
                                <?php if ($z['kolvo_sklad'] > 0): ?>
                                    <span class="badge bg-success position-absolute top-0 end-0 m-2">В наличии</span>
                                <?php else: ?>
                                    <span class="badge bg-danger position-absolute top-0 end-0 m-2">Нет в наличии</span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($z['nazv_zapch']) ?></h5>
                                
                                <div class="specs mb-3">
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-tag text-muted me-2"></i>
                                        <span><strong>Тип:</strong> <?= htmlspecialchars($z['nazv_tip_zapch']) ?></span>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-truck-monster text-muted me-2"></i>
                                        <span><strong>Модель:</strong> <?= htmlspecialchars($z['model']) ?></span>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-cogs text-muted me-2"></i>
                                        <span><strong>Для:</strong> <?= htmlspecialchars($z['nazv_pogr']) ?></span>
                                    </div>
                                </div>
                                
                                <div class="mt-auto">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <div class="price"><?= htmlspecialchars($z['tsena']) ?> ₽</div>
                                        <div class="stock">
                                            <i class="fas fa-box-open me-1"></i>
                                            <?= htmlspecialchars($z['kolvo_sklad']) ?> шт.
                                        </div>
                                    </div>
                                    
                                    <?php if ($z['kolvo_sklad'] > 0): ?>
                                        <div class="cart-controls" data-id="<?= $z['id_zapch'] ?>" data-price="<?= $z['tsena'] ?>">
                                            <?php 
                                            // Проверяем, есть ли эта запчасть в корзине пользователя
                                            $in_cart = false;
                                            $cart_quantity = 0;
                                            if (isset($_SESSION['user']['id'])) {
                                                $cart_query = $link->prepare("SELECT kolvo FROM korzina WHERE id_user = ? AND id_zapch = ? AND status = 'Не оформлен'");
                                                $cart_query->bind_param("ii", $_SESSION['user']['id'], $z['id_zapch']);
                                                $cart_query->execute();
                                                $cart_result = $cart_query->get_result();
                                                if ($cart_result->num_rows > 0) {
                                                    $in_cart = true;
                                                    $cart_item = $cart_result->fetch_assoc();
                                                    $cart_quantity = $cart_item['kolvo'];
                                                }
                                            }
                                            ?>
                                            
                                            <?php if ($in_cart): ?>
                                                <div class="d-flex align-items-center justify-content-center">
                                                    <button class="btn btn-sm btn-outline-secondary minus-btn">-</button>
                                                    <span class="quantity mx-2"><?= $cart_quantity ?></span>
                                                    <button class="btn btn-sm btn-outline-secondary plus-btn">+</button>
                                                    <span class="total-price ms-2"><?= $z['tsena'] * $cart_quantity ?> ₽</span>
                                                </div>
                                            <?php else: ?>
                                                <button class="btn btn-primary w-100 add-to-cart-btn">
                                                    <i class="fas fa-cart-plus me-2"></i>В корзину
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <button class="btn btn-outline-secondary w-100" disabled>
                                            <i class="fas fa-bell me-2"></i>Сообщить о поступлении
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="no-results bg-white rounded p-5 text-center">
                        <i class="fas fa-box-open fa-3x text-muted mb-4"></i>
                        <h4 class="mb-3">Запчасти не найдены</h4>
                        <p class="text-muted">Попробуйте изменить параметры фильтрации</p>
                        <a href="zapchasti.php" class="btn btn-primary mt-3">
                            <i class="fas fa-undo me-2"></i>Сбросить фильтры
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
            </div>

    <!-- Подвал -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
        </div>
    </footer>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {
    // Функция для загрузки данных с фильтрами
        function loadFilteredData() {
        const formData = $('#filterForm').serialize();
        $('.loading-overlay').show();
        
        $.ajax({
            url: 'zapchasti_ajax.php',
            type: 'GET',
            data: formData,
            success: function(response) {
                $('#zapchastiContainer').hide().html(response).fadeIn(500);
                updateUrl(formData);
                $('.loading-overlay').hide();
            },
            error: function() {
                alert('Ошибка при загрузке данных');
                $('.loading-overlay').hide();
            }
        });
    }
    // Обновление URL без перезагрузки страницы
    function updateUrl(params) {
        const newUrl = window.location.pathname + '?' + params;
        window.history.pushState({ path: newUrl }, '', newUrl);
    }
    
    // Обработка изменения фильтров
    $('.filter-select, .filter-input').change(function() {
        loadFilteredData();
    });
    
    // Обработка отправки формы (на случай, если пользователь нажмет кнопку)
    $('#filterForm').submit(function(e) {
        e.preventDefault();
        loadFilteredData();
    });
    
    // Обработка кнопки сброса
    $('a[href="zapchasti.php"]').click(function(e) {
        e.preventDefault();
        window.location.href = 'zapchasti.php';
    });
    
    // Обработка клика на кнопку "В корзину"
    $(document).on('click', '.add-to-cart-btn', function() {
        if (!<?= isset($_SESSION['user']) ? 'true' : 'false' ?>) {
            window.location.href = 'login.php';
            return;
        }
        
        const cartControl = $(this).closest('.cart-controls');
        const id = cartControl.data('id');
        const price = cartControl.data('price');
        
        $.ajax({
            url: 'add_to_cart.php',
            method: 'POST',
            data: { 
                id_zapch: id,
                action: 'add'
            },
            success: function(response) {
                cartControl.html(`
                    <div class="d-flex align-items-center justify-content-center">
                        <button class="btn btn-sm btn-outline-secondary minus-btn">-</button>
                        <span class="quantity mx-2">1</span>
                        <button class="btn btn-sm btn-outline-secondary plus-btn">+</button>
                        <span class="total-price ms-2">${price} ₽</span>
                    </div>
                `);
            },
            error: function() {
                alert('Ошибка при добавлении в корзину');
            }
        });
    });
    
    // Обработка кликов на + и - (делегирование событий)
    $(document).on('click', '.plus-btn', function() {
        const cartControl = $(this).closest('.cart-controls');
        const id = cartControl.data('id');
        const price = cartControl.data('price');
        const quantityElement = cartControl.find('.quantity');
        const totalPriceElement = cartControl.find('.total-price');
        let quantity = parseInt(quantityElement.text());
        
        $.ajax({
            url: 'add_to_cart.php',
            method: 'POST',
            data: { 
                id_zapch: id,
                action: 'increase'
            },
            success: function(response) {
                quantity++;
                quantityElement.text(quantity);
                totalPriceElement.text((price * quantity) + ' ₽');
            },
            error: function() {
                alert('Ошибка при обновлении количества');
            }
        });
    });
    
    $(document).on('click', '.minus-btn', function() {
        const cartControl = $(this).closest('.cart-controls');
        const id = cartControl.data('id');
        const price = cartControl.data('price');
        const quantityElement = cartControl.find('.quantity');
        const totalPriceElement = cartControl.find('.total-price');
        let quantity = parseInt(quantityElement.text());
        
        $.ajax({
            url: 'add_to_cart.php',
            method: 'POST',
            data: { 
                id_zapch: id,
                action: quantity > 1 ? 'decrease' : 'remove'
            },
            success: function(response) {
                if (quantity > 1) {
                    quantity--;
                    quantityElement.text(quantity);
                    totalPriceElement.text((price * quantity) + ' ₽');
                } else {
                    cartControl.html(`
                        <button class="btn btn-primary w-100 add-to-cart-btn">
                            <i class="fas fa-cart-plus me-2"></i>В корзину
                        </button>
                    `);
                }
            },
            error: function() {
                alert('Ошибка при обновлении количества');
            }
        });
    });
});
</script>
</body>
</html>