<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход | ЯЗРП</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #253482;
            --secondary-color: #FF6B00;
        }
                .alert-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
            max-width: 400px;
        }
        .alert {
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        }
        .alert.show {
            opacity: 1;
            transform: translateX(0);
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex; 
            flex-direction: column; 
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .top-bar {
            background-color: var(--primary-color);
            height: 20px;
        }
        .header-info {
            background-color: #ffffff;
            padding: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .logo-and-text {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .header-info img {
            height: 60px;
            transition: transform 0.3s;
        }
        .header-info img:hover {
            transform: scale(1.05);
        }
        .header-text .title {
            font-weight: bold;
            font-size: 1.2rem;
            color: #000;
        }
        .header-text .location {
            font-size: 1rem;
            color: #333;
        }
        .divider {
            border-left: 1px solid #ccc;
            height: 50px;
        }
        .navbar-custom { 
            background-color: var(--primary-color) !important; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .navbar-custom .nav-link { 
            color: white !important; 
            padding: 10px 15px;
            transition: all 0.3s;
        }
        .navbar-custom .nav-link:hover {
            color: var(--secondary-color) !important;
        }
        .navbar-nav .nav-link.active {
            color: var(--secondary-color) !important;
            font-weight: bold;
            position: relative;
        }
        .navbar-nav .nav-link.active:after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--secondary-color);
        }

        .login-section {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 15px;
            background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('background-pattern.png');
            background-size: cover;
        }

        .login-card {
            width: 100%;
            max-width: 450px;
            padding: 30px;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            border-top: 5px solid var(--primary-color);
        }

        .login-card h3 {
            margin-bottom: 25px;
            color: var(--primary-color);
            font-weight: 700;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
        }

        .login-card h3:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--secondary-color);
        }

        .form-control {
      border-radius: 8px;
      padding: 12px 15px;
      border: 1px solid #ddd;
      transition: all 0.3s;
      height: 40px
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-size: 1.10rem;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #1a285f;
            border-color: #1a285f;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .login-card a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        .login-card a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }

        .footer {
            background: #222;
            color: #fff;
            padding: 30px 15px;
            text-align: center;
        }

        .input-group-text {
            background-color: var(--primary-color);
            color: white;
            border: none;
        }

        .form-floating label {
            color: #666;
        }

        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #666;
        }

        .password-container {
            position: relative;
        }

        @media (max-width: 768px) {
            .header-info {
                flex-direction: column;
                align-items: flex-start;
            }
            .header-text {
                flex-direction: column;
                align-items: flex-start;
            }
            .divider {
                display: none;
            }
            .login-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
<div class="alert-container" id="alertContainer"></div>
<div class="top-bar w-100"></div>

<div class="container-fluid header-info">
    <!-- Логотип и текст -->
    <div class="d-flex align-items-center">
        <a href="glavnaya.php">
            <img src="logo.png" alt="Логотип" class="me-3">
        </a>
        <div class="d-flex align-items-center">
            <div class="header-text me-3">
                <div class="title">
                    Ярославский завод<br>по ремонту погрузчиков
                </div>
            </div>
            <div class="divider me-3" style="border-left: 1px solid #ccc; height: 50px;"></div>
            <div class="location">
                г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
            </div>
        </div>
    </div>

    <!-- Поисковая строка и кнопка -->
    <div class="d-flex align-items-center ms-auto">
        <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
        <button class="btn btn-outline-primary">Найти</button>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container-fluid d-flex justify-content-between align-items-center">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
                <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
                <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
                <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
                <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
                <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
                <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
                <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
            </ul>
        </div>
    </div>
</nav>

<section class="login-section">
    <div class="login-card">
        <h3>Вход в систему</h3>
        <form action="login_proccess.php" method="POST">
            <div class="mb-3">
                <label for="login" class="form-label">Логин</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" class="form-control" id="login" name="login" placeholder="Введите ваш логин" required>
                </div>
            </div>
            
            <div class="mb-4">
                <label for="password" class="form-label">Пароль</label>
                <div class="password-container">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="parol" name="parol" placeholder="Введите ваш пароль" required>
                    </div>
                    <i class="fas fa-eye password-toggle" id="togglePassword"></i>
                </div>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="remember">
                    <label class="form-check-label" for="remember">Запомнить меня</label>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Войти</button>
            
            <div class="text-center mt-4">
                <p>Ещё нет аккаунта? <a href="registr.php" class="fw-bold">Зарегистрироваться</a></p>
            </div>
        </form>
    </div>
</section>

   <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>ЯЗРП</h5>
                    <p>Ярославский завод по ремонту погрузчиков - профессиональные услуги по аренде, ремонту и обслуживанию складской техники.</p>
                </div>
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>Меню</h5>
                    <ul class="list-unstyled">
                        <li><a href="glavnaya.php" class="text-white">О компании</a></li>
                        <li><a href="arenda.php" class="text-white">Аренда</a></li>
                        <li><a href="remont.php" class="text-white">Ремонт</a></li>
                        <li><a href="TO.php" class="text-white">Техобслуживание</a></li>
                        <li><a href="zapchasti.php" class="text-white">Запчасти</a></li>
                        <li><a href="kontakti.php" class="text-white">Контакты</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Контакты</h5>
                    <address>
                        <p><i class="fas fa-map-marker-alt me-2"></i> 150008, г. Ярославль, пр-т. Машиностроителей, д. 83, стр.14</p>
                    </address>
                    <div class="mt-3">
                        <h6>Отдел продажи зап.частей:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-30, +7 (903) 638-49-22</p>
                        <p><i class="fas fa-envelope me-2"></i> 67yzrp@mail.ru</p>
                    </div>
                    <div class="mt-3">
                        <h6>Отдел аренды:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-32, +7 (903) 692-36-36, +7 (903) 828-57-58</p>
                        <p><i class="fas fa-envelope me-2"></i> arenda3636@bk.ru, yzrp@inbox.ru</p>
                    </div>
                </div>
            </div>
            <hr class="my-4 bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
            </div>
        </div>
    </footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Показать/скрыть пароль
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#parol');
    
    togglePassword.addEventListener('click', function (e) {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.classList.toggle('fa-eye-slash');
    });

    // Функция для показа уведомления
    function showAlert(message, type = 'danger') {
        const alertContainer = document.getElementById('alertContainer');
        const alertId = 'alert-' + Date.now();
        const alertHTML = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        alertContainer.insertAdjacentHTML('beforeend', alertHTML);
        
        // Анимация появления
        setTimeout(() => {
            document.getElementById(alertId).classList.add('show');
        }, 10);
        
        // Автоматическое закрытие через 5 секунд
        setTimeout(() => {
            hideAlert(alertId);
        }, 5000);
    }
    
    // Функция для скрытия уведомления
    function hideAlert(alertId) {
        const alert = document.getElementById(alertId);
        if (alert) {
            alert.classList.remove('show');
            setTimeout(() => {
                alert.remove();
            }, 300);
        }
    }
    
    // Обработка формы через AJAX
    $(document).ready(function() {
        $('form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const submitBtn = form.find('button[type="submit"]');
            const originalBtnText = submitBtn.html();
            
            // Показываем индикатор загрузки
            submitBtn.prop('disabled', true);
            submitBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Вход...');
            
            $.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: form.serialize(),
                success: function(response) {
                    if (response.success) {
                        // Перенаправляем при успешном входе
                        window.location.href = response.redirect || 'glavnaya.php';
                    } else {
                        // Показываем ошибку
                        showAlert(response.message, 'danger');
                    }
                },
                error: function(xhr) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        showAlert(response.message || 'Произошла ошибка', 'danger');
                    } catch (e) {
                        showAlert('Произошла ошибка при обработке запроса', 'danger');
                    }
                },
                complete: function() {
                    // Восстанавливаем кнопку
                    submitBtn.prop('disabled', false);
                    submitBtn.html(originalBtnText);
                }
            });
        });
    });
</script>
</body>
</html>