<?php
session_start();
require_once 'config.php';

// Получаем список погрузчиков
$pogrs = $link->query("SELECT id_pogr, CONCAT(nazv_pogr, ', ', model) AS pogr_name FROM pogryzchik")->fetch_all(MYSQLI_ASSOC);
$selectedId = isset($_GET['id_pogr']) ? (int)$_GET['id_pogr'] : 0;

// Обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Проверка авторизации пользователя
    if (!isset($_SESSION['user'])) {
        $_SESSION['redirect_after_login'] = 'remont.php';
        header("Location: login.php");
        exit;
    }
    
    $user_id = $_SESSION['user']['id'];
    $id_pogr = (int)$_POST['id_pogr'];
    $opisanie = $_POST['opisanie'];
    
    // Вставка заявки в БД (id_tip_zayavki = 2 для ремонта)
    $stmt = $link->prepare("INSERT INTO zayavki (id_user, id_pogr, id_tip_zayavki, data_zayavki, nachalo_arendi, konec_arendi, kolvo_motochasov, opisanie, status) 
                           VALUES (?, ?, 2, NOW(), '-', '-', '-', ?, 'Отправлена')");
    $stmt->bind_param("iis", $user_id, $id_pogr, $opisanie);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Заявка на ремонт успешно отправлена!";
    } else {
        $_SESSION['error'] = "Ошибка при отправке заявки: " . $link->error;
    }
    
    $stmt->close();
    header("Location: remont.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЯЗРП - Ремонт погрузчиков</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #253482;
            --secondary-color: #FF6B00;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
        }
        .top-bar {
            background-color: var(--primary-color);
            height: 20px;
        }
        .header-info {
            background-color: #ffffff;
            padding: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-nav .nav-link {
            position: relative;
        }
        .navbar-nav .nav-link.active {
            color: var(--secondary-color) !important;
            font-weight: bold;
        }
        .navbar-nav .nav-link.active:after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--secondary-color);
        }
        .logo-and-text {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .header-info img {
            height: 60px;
            transition: transform 0.3s;
        }
        .header-info img:hover {
            transform: scale(1.05);
        }
        .header-text .title {
            font-weight: bold;
            font-size: 1.2rem;
            color: #000;
        }
        .header-text .location {
            font-size: 1rem;
            color: #333;
        }
        .divider {
            border-left: 1px solid #ccc;
            height: 50px;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-size: 1.10rem;
            padding: 0.50rem 1.5rem;
            border-radius: 0.5rem;
            transition: all 0.3s;
            font-weight: 500;
        }
        .btn-primary:hover {
            background-color: #1a285f;
            border-color: #1a285f;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .btn-orange {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
            color: white;
        }
        .btn-orange:hover {
            background-color: #e05d00;
            border-color: #e05d00;
        }
        .carousel-caption {
            top: 50%;
            transform: translateY(-50%);
            bottom: auto;
            background-color: rgba(37, 52, 130, 0.85);
            padding: 30px;
            border-radius: 15px;
            width: 80%;
            max-width: 800px;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }
        .carousel-caption h3 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        .carousel-caption p {
            font-size: 1.2rem;
            margin-bottom: 25px;
        }
        .carousel-indicators [data-bs-target] {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin: 0 5px;
            background-color: rgba(255,255,255,0.5);
        }
        .carousel-indicators .active {
            background-color: white;
        }
        .navbar-custom {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .navbar-custom .nav-link {
            color: white !important;
            padding: 10px 15px;
            transition: all 0.3s;
        }
        .navbar-custom .nav-link:hover {
            color: var(--secondary-color) !important;
        }
        .carousel-item {
            height: 600px;
        }
        .carousel-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }
        .section-padding {
            padding: 80px 15px;
        }
        .section-title {
            position: relative;
            margin-bottom: 50px;
        }
        .section-title h2 {
            font-weight: 700;
            color: var(--primary-color);
            position: relative;
            display: inline-block;
            padding-bottom: 15px;
        }
        .section-title h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--secondary-color);
        }
        .feature-box {
            text-align: center;
            padding: 30px 20px;
            margin-bottom: 30px;
            transition: all 0.3s;
            border-radius: 10px;
            background: white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            height: 300px;
        }
        .feature-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        .feature-icon {
            width: 100px;
            height: 100px;
            background: var(--secondary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
            transition: all 0.3s;
        }
        .feature-box:hover .feature-icon {
            background: var(--primary-color);
            transform: rotateY(180deg);
        }
        .feature-box h4 {
            font-weight: 600;
            margin: 15px 0;
            color: var(--primary-color);
        }
        .bg-light {
            background-color: #f9f9f9 !important;
        }
        .footer {
            background: #222;
            color: #fff;
            padding: 40px 15px;
        }
        .footer p {
            margin-bottom: 0;
        }
        .page-title {
            background: linear-gradient(to right, var(--primary-color), #3a4ba8);
            color: white;
            padding: 20px 0;
            margin-bottom: 40px;
        }
        .page-title h3 {
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .table thead {
            background-color: var(--primary-color);
            color: white;
        }
        .table th {
            font-weight: 600;
            padding: 15px;
        }
        .table td {
            padding: 12px 15px;
        }
        .table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        .table tbody tr:hover {
            background-color: #e9ecef;
        }
        .accordion-button:not(.collapsed) {
            background-color: rgba(37, 52, 130, 0.1);
            color: var(--primary-color);
        }
        .accordion-button:focus {
            box-shadow: none;
            border-color: rgba(0,0,0,0.125);
        }
        .card {
            border: none;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 20px;
        }
        .contact-info {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .alert {
            border-radius: 8px;
        }
        .guarantee-block {
            background-color: rgba(255, 107, 0, 0.1);
            border-left: 5px solid var(--secondary-color);
            padding: 30px;
            border-radius: 5px;
            margin: 40px 0;
        }
        .gallery-item {
            overflow: hidden;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .gallery-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .gallery-item img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            transition: transform 0.5s;
        }
        .gallery-item:hover img {
            transform: scale(1.05);
        }
        .gallery-item p {
            padding: 15px;
            background: white;
            margin: 0;
            font-weight: 500;
        }
        .principles-list {
            column-count: 2;
            column-gap: 30px;
        }
        .principles-list li {
            margin-bottom: 15px;
            break-inside: avoid;
        }
        @media (max-width: 768px) {
            .header-info {
                flex-direction: column;
                align-items: flex-start;
            }
            .header-text {
                flex-direction: column;
                align-items: flex-start;
            }
            .divider {
                display: none;
            }
            .search-login {
                width: 100%;
                justify-content: flex-start;
                margin-top: 10px;
            }
            .carousel-item {
                height: 400px;
            }
            .carousel-caption {
                width: 90%;
                padding: 15px;
            }
            .carousel-caption h3 {
                font-size: 1.5rem;
            }
            .carousel-caption p {
                font-size: 1rem;
            }
            .feature-box {
                padding: 20px 15px;
            }
            .feature-icon {
                width: 80px;
                height: 80px;
                font-size: 30px;
            }
            .principles-list {
                column-count: 1;
            }
        }
    </style>
</head>
<body>
    <!-- Верхняя синяя полоса -->
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="d-flex align-items-center">
            <a href="glavnaya.php">
                <img src="logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3" style="border-left: 1px solid #ccc; height: 50px;"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
                    <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
                    <li class="nav-item"><a class="nav-link active" href="remont.php">Ремонт</a></li>
                    <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
                    <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
                    <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
                    <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
                    <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
                </ul>
            </div>

            <div class="d-none d-lg-block">
                <?php if (isset($_SESSION['user'])): ?>
                    <div class="d-flex gap-3 align-items-center">
                        <?php if ($_SESSION['user']['id_role'] == 1): ?>
                            <a class="nav-link" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                        <?php endif; ?>
                        <a class="nav-link" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                        <?php if ($_SESSION['user']['id_role'] != 1): ?>
                            <a class="nav-link" href="cart.php" style="color: white;"><i class="fas fa-shopping-cart"></i></a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <a class="btn btn-outline-light" href="login.php">Войти</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Слайдер -->
    <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="slider1.png" class="d-block w-100" alt="Аренда погрузчиков">
                <div class="carousel-caption">
                    <h3>Профессиональный ремонт погрузчиков</h3>
                    <p>Быстрое восстановление работоспособности любой техники с гарантией качества</p>
                    <a href="remont.php" class="btn btn-orange btn-lg">Подробнее</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder2.png" class="d-block w-100" alt="Ремонт техники">
                <div class="carousel-caption">
                    <h3>Аренда погрузчиков по выгодным ценам</h3>
                    <p>Гибкие условия для вашего бизнеса - от часа до нескольких лет</p>
                    <a href="arenda.php" class="btn btn-orange btn-lg">Выбрать технику</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder3.png" class="d-block w-100" alt="Запчасти">
                <div class="carousel-caption">
                    <h3>Оригинальные запчасти в наличии</h3>
                    <p>Быстрая поставка комплектующих для всех популярных марок погрузчиков</p>
                    <a href="zapchasti.php" class="btn btn-orange btn-lg">Каталог запчастей</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slider4.png" class="d-block w-100" alt="Техобслуживание">
                <div class="carousel-caption">
                    <h3>Регулярное техническое обслуживание</h3>
                    <p>Продлите срок службы вашей техники с нашими сервисными программы</p>
                    <a href="TO.php" class="btn btn-orange btn-lg">Записаться на ТО</a>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    
    <!-- Полоса с названием страницы -->
    <section class="page-title">
        <div class="container text-center">
            <h3 class="mb-0">Ремонт погрузчиков</h3>
        </div>
    </section>

    <!-- Вывод сообщений об успехе/ошибке -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="container mt-4">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $_SESSION['success'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="container mt-4">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $_SESSION['error'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Преимущества ремонта -->
    <section class="section-padding">
        <div class="container">
            <div class="section-title text-center">
                <h2>Преимущества ремонта у нас</h2>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-tools"></i>
                        </div>
                        <h4>Опытные мастера</h4>
                        <p>Наши специалисты имеют более 10 лет опыта работы с различными марками погрузчиков.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-warehouse"></i>
                        </div>
                        <h4>Собственный цех</h4>
                        <p>2500 м² производственных площадей с современным оборудованием.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h4>Быстрый ремонт</h4>
                        <p>Средний срок ремонта - 3 дня. Срочный ремонт за 24 часа.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-medal"></i>
                        </div>
                        <h4>Гарантия</h4>
                        <p>Гарантия до 6 месяцев на все виды ремонтных работ.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Виды ремонта -->
    <section class="section-padding bg-light">
        <div class="container">
            <div class="section-title text-center">
                <h2>Виды ремонта</h2>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered text-center align-middle">
                    <thead>
                        <tr>
                            <th>Тип ремонта</th>
                            <th>Описание</th>
                            <th>Срок выполнения</th>
                            <th>Гарантия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Диагностика</td>
                            <td>Комплексная проверка всех систем погрузчика</td>
                            <td>1-2 часа</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>Текущий ремонт</td>
                            <td>Замена расходных материалов, мелкий ремонт</td>
                            <td>1-2 дня</td>
                            <td>1 месяц</td>
                        </tr>
                        <tr>
                            <td>Капитальный ремонт</td>
                            <td>Полное восстановление двигателя и гидравлики</td>
                            <td>3-7 дней</td>
                            <td>6 месяцев</td>
                        </tr>
                        <tr>
                            <td>Восстановление после аварии</td>
                            <td>Ремонт кузова, замена поврежденных деталей</td>
                            <td>5-14 дней</td>
                            <td>3 месяца</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <!-- Наши принципы -->
    <section class="section-padding">
        <div class="container">
            <div class="section-title text-center">
                <h2>Наши принципы работы</h2>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <ul class="principles-list list-unstyled">
                        <li><i class="fas fa-check-circle text-success me-2"></i> Фиксированная цена после диагностики</li>
                        <li><i class="fas fa-check-circle text-success me-2"></i> Без скрытых работ и дополнительных платежей</li>
                        <li><i class="fas fa-check-circle text-success me-2"></i> Оплата по факту выполнения работ</li>
                        <li><i class="fas fa-check-circle text-success me-2"></i> Выезд специалиста в течение 2 часов</li>
                        <li><i class="fas fa-check-circle text-success me-2"></i> Использование только качественных запчастей</li>
                        <li><i class="fas fa-check-circle text-success me-2"></i> Прозрачная система отчетности</li>
                        <li><i class="fas fa-check-circle text-success me-2"></i> Индивидуальный подход к каждому клиенту</li>
                        <li><i class="fas fa-check-circle text-success me-2"></i> Гарантия на все виды работ</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Галерея выполненных работ -->
    <section class="section-padding bg-light">
        <div class="container">
            <div class="section-title text-center">
                <h2>Примеры выполненных работ</h2>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="gallery-item">
                        <img src="repair1.jpg" alt="Ремонт двигателя">
                        <p class="text-center">Капитальный ремонт двигателя</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="gallery-item">
                        <img src="repair2.jpg" alt="Ремонт гидравлики">
                        <p class="text-center">Ремонт гидравлической системы</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="gallery-item">
                        <img src="repair3.jpg" alt="Восстановление после аварии">
                        <p class="text-center">Восстановление после аварии</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Форма заявки -->
    <section class="section-padding" id="repair-form">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card shadow">
                        <div class="card-header bg-primary text-white text-center py-3">
                            <h4 class="mb-0">Заявка на ремонт погрузчика</h4>
                        </div>
                        <div class="card-body p-4">
                            <form method="POST" action="remont.php">
                                <input type="hidden" name="id_tip_zayavki" value="2">

                                <div class="mb-4">
                                    <label class="form-label fw-bold">Погрузчик</label>
                                    <select name="id_pogr" class="form-select form-select-lg" required>
                                        <option value="">Выберите погрузчик</option>
                                        <?php foreach ($pogrs as $p): ?>
                                            <option value="<?= $p['id_pogr'] ?>" <?= $p['id_pogr'] == $selectedId ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($p['pogr_name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="mb-4">
                                    <label class="form-label fw-bold">Описание проблемы</label>
                                    <textarea name="opisanie" class="form-control" rows="4" placeholder="Опишите симптомы неисправности..." required></textarea>
                                </div>

                                <div class="text-center mt-4">
                                    <?php if (isset($_SESSION['user'])): ?>
                                        <button type="submit" class="btn btn-primary btn-lg px-5 py-3">
                                            Отправить заявку
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-primary btn-lg px-5 py-3" onclick="alert('Для отправки заявки необходимо авторизоваться');">
                                            Отправить заявку
                                        </button>
                                        <p class="mt-3">Для отправки заявки необходимо <a href="login.php">войти</a> или <a href="register.php">зарегистрироваться</a></p>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Гарантии -->
    <section class="section-padding bg-light">
        <div class="container">
            <div class="guarantee-block">
                <div class="row">
                    <div class="col-md-8 mx-auto text-center">
                        <h3 class="mb-4">Наши гарантии</h3>
                        <div class="row">
                            <div class="col-md-4">
                                <h4 class="text-primary">6 месяцев</h4>
                                <p>на капитальный ремонт</p>
                            </div>
                            <div class="col-md-4">
                                <h4 class="text-primary">3 месяца</h4>
                                <p>на текущий ремонт</p>
                            </div>
                            <div class="col-md-4">
                                <h4 class="text-primary">Бесплатный выезд</h4>
                                <p>при гарантийных случаях</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Контакты -->
    <section class="section-padding">
        <div class="container">
            <div class="section-title text-center">
                <h2>Контакты отдела ремонта</h2>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="contact-info">
                        <div class="row">
                            <div class="col-md-6">
                                <h5><i class="fas fa-phone-alt me-2 text-primary"></i> Телефоны:</h5>
                                <ul class="list-unstyled">
                                    <li class="mb-2">(4852) 49-04-30</li>
                                    <li>+7 (903) 638-49-22</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h5><i class="fas fa-envelope me-2 text-primary"></i> Email:</h5>
                                <ul class="list-unstyled">
                                    <li>67yzrp@mail.ru</li>
                                </ul>
                            </div>
                        </div>
                        <div class="mt-4">
                            <h5><i class="fas fa-map-marker-alt me-2 text-primary"></i> Адрес сервисного центра:</h5>
                            <p>г. Ярославль, пр-кт Машиностроителей, д.83</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Подвал -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>ЯЗРП</h5>
                    <p>Ярославский завод по ремонту погрузчиков - профессиональные услуги по аренде, ремонту и обслуживанию складской техники.</p>
                </div>
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>Меню</h5>
                    <ul class="list-unstyled">
                        <li><a href="glavnaya.php" class="text-white">О компании</a></li>
                        <li><a href="arenda.php" class="text-white">Аренда</a></li>
                        <li><a href="remont.php" class="text-white">Ремонт</a></li>
                        <li><a href="TO.php" class="text-white">Техобслуживание</a></li>
                        <li><a href="zapchasti.php" class="text-white">Запчасти</a></li>
                        <li><a href="kontakti.php" class="text-white">Контакты</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Контакты</h5>
                    <address>
                        <p><i class="fas fa-map-marker-alt me-2"></i> 150008, г. Ярославль, пр-т. Машиностроителей, д. 83, стр.14</p>
                    </address>
                    <div class="mt-3">
                        <h6>Отдел продажи зап.частей:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-30, +7 (903) 638-49-22</p>
                        <p><i class="fas fa-envelope me-2"></i> 67yzrp@mail.ru</p>
                    </div>
                    <div class="mt-3">
                        <h6>Отдел аренды:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-32, +7 (903) 692-36-36, +7 (903) 828-57-58</p>
                        <p><i class="fas fa-envelope me-2"></i> arenda3636@bk.ru, yzrp@inbox.ru</p>
                    </div>
                </div>
            </div>
            <hr class="my-4 bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Активация текущей ссылки в меню
            const currentPage = location.pathname.split('/').pop();
            document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
                if (link.getAttribute('href') === currentPage) {
                    link.classList.add('active');
                }
            });

            // Плавная прокрутка
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        window.scrollTo({
                            top: target.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                });
            });

            // Автоматическое закрытие аккордеона при открытии другого
            const accordions = document.querySelectorAll('.accordion-button');
            accordions.forEach(accordion => {
                accordion.addEventListener('click', function() {
                    const currentlyOpen = document.querySelector('.accordion-button:not(.collapsed)');
                    if (currentlyOpen && currentlyOpen !== this) {
                        currentlyOpen.click();
                    }
                });
            });
        });
    </script>
</body>
</html>