<?php
session_start();
require_once 'config.php';

// Обработка отправки нового отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otziv_text']) && isset($_SESSION['user'])) {
    header('Content-Type: application/json');
    
    $otziv_text = trim($_POST['otziv_text']);
    $id_user = $_SESSION['user']['id'];
    
    if (!empty($otziv_text)) {
        $sql = "INSERT INTO otzivi (id_user, otziv, data_otziv) VALUES (?, ?, NOW())";
        $stmt = $link->prepare($sql);
        $stmt->bind_param("is", $id_user, $otziv_text);
        $stmt->execute();
        
        // Возвращаем JSON ответ для AJAX
        if ($stmt->affected_rows > 0) {
            $new_review = [
                'fio' => $_SESSION['user']['fullname'],
                'nazv_ofisa' => $_SESSION['user']['nazv_ofisa'] ?? '',
                'image' => $_SESSION['user']['image'] ?? 'img/default-avatar.jpg',
                'otziv' => $otziv_text,
                'data_otziv' => date('Y-m-d H:i:s')
            ];
            echo json_encode($new_review);
            exit;
        } else {
            echo json_encode(['error' => 'Ошибка при сохранении отзыва']);
            exit;
        }
    } else {
        echo json_encode(['error' => 'Текст отзыва не может быть пустым']);
        exit;
    }
}

// Получаем все отзывы с информацией о пользователях
$sql = "SELECT o.*, 
               CONCAT(u.familia, ' ', u.imya, ' ', u.otchestvo) AS fio, 
               u.nazv_ofisa, 
               u.image 
        FROM otzivi o 
        JOIN users u ON o.id_user = u.id_user 
        ORDER BY o.data_otziv DESC";
$otzivi = $link->query($sql)->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Отзывы | ЯЗРП</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #253482;
            --secondary-color: #FF6B00;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex; 
            flex-direction: column; 
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .top-bar {
            background-color: var(--primary-color);
            height: 20px;
        }
        .header-info {
            background-color: #ffffff;
            padding: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .logo-and-text {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .header-info img {
            height: 60px;
            transition: transform 0.3s;
        }
        .header-info img:hover {
            transform: scale(1.05);
        }
        .header-text .title {
            font-weight: bold;
            font-size: 1.2rem;
            color: #000;
        }
        .header-text .location {
            font-size: 1rem;
            color: #333;
        }
        .divider {
            border-left: 1px solid #ccc;
            height: 50px;
        }
        .navbar-custom { 
            background-color: var(--primary-color) !important; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .navbar-custom .nav-link { 
            color: white !important; 
            padding: 10px 15px;
            transition: all 0.3s;
        }
        .navbar-custom .nav-link:hover {
            color: var(--secondary-color) !important;
        }
        .navbar-nav .nav-link.active {
            color: var(--secondary-color) !important;
            font-weight: bold;
            position: relative;
        }
        .navbar-nav .nav-link.active:after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--secondary-color);
        }
        
        /* Стили для слайдера */
        .carousel-item {
            height: 600px;
        }
        .carousel-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }
        .carousel-caption {
            top: 50%;
            transform: translateY(-50%);
            bottom: auto;
            background-color: rgba(37, 52, 130, 0.85);
            padding: 30px;
            border-radius: 15px;
            width: 80%;
            max-width: 800px;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }
        .carousel-caption h3 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        .carousel-caption p {
            font-size: 1.2rem;
            margin-bottom: 25px;
        }
        .carousel-indicators [data-bs-target] {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin: 0 5px;
            background-color: rgba(255,255,255,0.5);
        }
        .carousel-indicators .active {
            background-color: white;
        }
        .btn-orange {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
            color: white;
        }
        .btn-orange:hover {
            background-color: #e05d00;
            border-color: #e05d00;
        }
        
        .page-title {
            background: linear-gradient(to right, var(--primary-color), #3a4ba8);
            color: white;
            padding: 20px 0;
            margin-bottom: 40px;
        }
        
        .page-title h3 {
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        
        /* Стили для отзывов */
        .review-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            transition: all 0.3s;
        }
        
        .review-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .review-header {
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .review-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
            border: 2px solid var(--primary-color);
        }
        
        .review-user-info {
            flex: 1;
        }
        
        .review-user-name {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        
        .review-user-org {
            font-size: 0.9rem;
            color: #666;
        }
        
        .review-date {
            font-size: 0.8rem;
            color: #999;
        }
        
        .review-body {
            padding: 20px;
            font-size: 1rem;
            line-height: 1.6;
            color: #333;
        }
        
        .no-reviews {
            text-align: center;
            padding: 50px;
            color: #666;
        }
        
        .add-review-btn {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
            margin-bottom: 30px;
        }
        
        .add-review-btn:hover {
            background-color: #e05d00;
            transform: translateY(-2px);
            color: white;
        }
        
        .footer {
            background: #222;
            color: #fff;
            padding: 30px 15px;
            text-align: center;
            margin-top: auto;
        }
        
        @media (max-width: 768px) {
            .header-info {
                flex-direction: column;
                align-items: flex-start;
            }
            .header-text {
                flex-direction: column;
                align-items: flex-start;
            }
            .divider {
                display: none;
            }
            .search-login {
                width: 100%;
                justify-content: flex-start;
                margin-top: 10px;
            }
            .carousel-item {
                height: 400px;
            }
            .carousel-caption {
                width: 90%;
                padding: 15px;
            }
            .carousel-caption h3 {
                font-size: 1.5rem;
            }
            .carousel-caption p {
                font-size: 1rem;
            }
            .review-header {
                flex-direction: column;
                text-align: center;
            }
            .review-avatar {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
                .review-form {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .review-textarea {
            width: 100%;
            min-height: 100px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            resize: vertical;
            margin-bottom: 15px;
            font-family: inherit;
        }
        
        .review-submit-btn {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .review-submit-btn:hover {
            background-color: #e05d00;
            transform: translateY(-2px);
        }
        
        .review-submit-btn:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
<div class="wrapper d-flex flex-column min-vh-100">
    <!-- Верхняя синяя полоса -->
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
<div class="container-fluid header-info">
    <!-- Логотип и текст -->
    <div class="d-flex align-items-center">
        <a href="glavnaya.php">
            <img src="logo.png" alt="Логотип" class="me-3">
        </a>
        <div class="d-flex align-items-center">
            <div class="header-text me-3">
                <div class="title">
                    Ярославский завод<br>по ремонту погрузчиков
                </div>
            </div>
            <div class="divider me-3" style="border-left: 1px solid #ccc; height: 50px;"></div>
            <div class="location">
                г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
            </div>
        </div>
    </div>

    <!-- Поисковая строка и кнопка -->
    <div class="d-flex align-items-center ms-auto">
        <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
        <button class="btn btn-outline-primary">Найти</button>
    </div>
</div>

    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
                    <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
                    <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
                    <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
                    <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
                    <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
                    <li class="nav-item"><a class="nav-link active" href="otzivi.php">Отзывы</a></li>
                    <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
                </ul>
            </div>
            <div class="d-none d-lg-block">
                <?php if (isset($_SESSION['user'])): ?>
                    <div class="d-flex gap-3 align-items-center">
                        <?php if ($_SESSION['user']['id_role'] == 1): ?>
                            <a class="nav-link" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                        <?php endif; ?>
                        <a class="nav-link" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                        <?php if ($_SESSION['user']['id_role'] != 1): ?>
                            <a class="nav-link" href="cart.php" style="color: white;"><i class="fas fa-shopping-cart"></i></a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <a class="btn btn-outline-light" href="login.php">Войти</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Слайдер -->
    <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="slider1.png" class="d-block w-100" alt="Аренда погрузчиков">
                <div class="carousel-caption">
                    <h3>Профессиональный ремонт погрузчиков</h3>
                    <p>Быстрое восстановление работоспособности любой техники с гарантией качества</p>
                    <a href="remont.php" class="btn btn-orange btn-lg">Подробнее</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder2.png" class="d-block w-100" alt="Ремонт техники">
                <div class="carousel-caption">
                    <h3>Аренда погрузчиков по выгодным ценам</h3>
                    <p>Гибкие условия для вашего бизнеса - от часа до нескольких лет</p>
                    <a href="arenda.php" class="btn btn-orange btn-lg">Выбрать технику</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slder3.png" class="d-block w-100" alt="Запчасти">
                <div class="carousel-caption">
                    <h3>Оригинальные запчасти в наличии</h3>
                    <p>Быстрая поставка комплектующих для всех популярных марок погрузчиков</p>
                    <a href="zapchasti.php" class="btn btn-orange btn-lg">Каталог запчастей</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="slider4.png" class="d-block w-100" alt="Техобслуживание">
                <div class="carousel-caption">
                    <h3>Регулярное техническое обслуживание</h3>
                    <p>Продлите срок службы вашей техники с нашими сервисными программы</p>
                    <a href="TO.php" class="btn btn-orange btn-lg">Записаться на ТО</a>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Полоса с названием страницы -->
    <section class="page-title">
        <div class="container text-center">
            <h3 class="mb-0">Отзывы наших клиентов</h3>
        </div>
    </section>

    <div class="container mb-5">
    <?php if (isset($_SESSION['user']) && $_SESSION['user']['id_role'] != 1): ?>
        <div class="review-form">
            <h4 class="mb-3">Оставить отзыв</h4>
            <form id="addReviewForm">
                <textarea class="review-textarea" id="otzivText" 
                          placeholder="Напишите ваш отзыв о нашей работе..." required></textarea>
                <button type="submit" class="review-submit-btn" id="submitReviewBtn">
                    <i class="fas fa-paper-plane me-2"></i>Отправить отзыв
                </button>
            </form>
        </div>
    <?php endif; ?>

    <div class="row" id="reviewsContainer">
        <?php if (!empty($otzivi)): ?>
            <?php foreach ($otzivi as $otziv): ?>
                <div class="col-lg-6">
                    <div class="review-card">
                        <div class="review-header">
                            <img src="<?= htmlspecialchars($otziv['image'] ?? 'img/default-avatar.jpg') ?>" 
                                 alt="Аватар" class="review-avatar">
                            <div class="review-user-info">
                                <div class="review-user-name"><?= htmlspecialchars($otziv['fio']) ?></div>
                                <?php if (!empty($otziv['nazv_ofisa'])): ?>
                                    <div class="review-user-org"><?= htmlspecialchars($otziv['nazv_ofisa']) ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="review-date">
                                <?= date('d.m.Y', strtotime($otziv['data_otziv'])) ?>
                            </div>
                        </div>
                        <div class="review-body">
                            <?= nl2br(htmlspecialchars($otziv['otziv'])) ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="no-reviews bg-white rounded p-5 text-center">
                    <i class="fas fa-comment-slash fa-3x text-muted mb-4"></i>
                    <h4 class="mb-3">Отзывов пока нет</h4>
                    <p class="text-muted">Будьте первым, кто оставит отзыв о нашей работе</p>
                    <?php if (!isset($_SESSION['user'])): ?>
                        <a href="login.php" class="btn btn-primary mt-3">
                            <i class="fas fa-sign-in-alt me-2"></i>Войдите, чтобы оставить отзыв
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

 <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>ЯЗРП</h5>
                    <p>Ярославский завод по ремонту погрузчиков - профессиональные услуги по аренде, ремонту и обслуживанию складской техники.</p>
                </div>
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>Меню</h5>
                    <ul class="list-unstyled">
                        <li><a href="glavnaya.php" class="text-white">О компании</a></li>
                        <li><a href="arenda.php" class="text-white">Аренда</a></li>
                        <li><a href="remont.php" class="text-white">Ремонт</a></li>
                        <li><a href="TO.php" class="text-white">Техобслуживание</a></li>
                        <li><a href="zapchasti.php" class="text-white">Запчасти</a></li>
                        <li><a href="kontakti.php" class="text-white">Контакты</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Контакты</h5>
                    <address>
                        <p><i class="fas fa-map-marker-alt me-2"></i> 150008, г. Ярославль, пр-т. Машиностроителей, д. 83, стр.14</p>
                    </address>
                    <div class="mt-3">
                        <h6>Отдел продажи зап.частей:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-30, +7 (903) 638-49-22</p>
                        <p><i class="fas fa-envelope me-2"></i> 67yzrp@mail.ru</p>
                    </div>
                    <div class="mt-3">
                        <h6>Отдел аренды:</h6>
                        <p><i class="fas fa-phone me-2"></i> (4852) 49-04-32, +7 (903) 692-36-36, +7 (903) 828-57-58</p>
                        <p><i class="fas fa-envelope me-2"></i> arenda3636@bk.ru, yzrp@inbox.ru</p>
                    </div>
                </div>
            </div>
            <hr class="my-4 bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
            </div>
        </div>
    </footer>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {
    // Обработка отправки формы отзыва
    $('#addReviewForm').on('submit', function(e) {
        e.preventDefault();
        
        const reviewText = $('#otzivText').val().trim();
        if (!reviewText) {
            alert('Пожалуйста, введите текст отзыва');
            return;
        }
        
        const submitBtn = $('#submitReviewBtn');
        submitBtn.prop('disabled', true);
        
        $.ajax({
            url: 'otzivi.php',
            method: 'POST',
            data: { otziv_text: reviewText },
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            dataType: 'json',
            success: function(response) {
                if (response.error) {
                    alert(response.error);
                    return;
                }
                
                // Создаем HTML для нового отзыва
                const reviewHtml = `
                    <div class="col-lg-6">
                        <div class="review-card">
                            <div class="review-header">
                                <img src="${response.image}" 
                                     alt="Аватар" class="review-avatar">
                                <div class="review-user-info">
                                    <div class="review-user-name">${response.fio}</div>
                                    ${response.nazv_ofisa ? `<div class="review-user-org">${response.nazv_ofisa}</div>` : ''}
                                </div>
                                <div class="review-date">
                                    ${new Date(response.data_otziv).toLocaleDateString('ru-RU')}
                                </div>
                            </div>
                            <div class="review-body">
                                ${response.otziv.replace(/\n/g, '<br>')}
                            </div>
                        </div>
                    </div>
                `;
                
                // Вставляем новый отзыв в начало списка
                if ($('#reviewsContainer .no-reviews').length) {
                    $('#reviewsContainer').html(reviewHtml);
                } else {
                    $('#reviewsContainer').prepend(reviewHtml);
                }
                
                // Очищаем поле ввода
                $('#otzivText').val('');
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                alert('Произошла ошибка при отправке отзыва: ' + error);
            },
            complete: function() {
                submitBtn.prop('disabled', false);
            }
        });
    });
    
    // Подсветка активной ссылки в меню
    const currentUrl = window.location.pathname.split("/").pop();
    $('.navbar-nav .nav-link').each(function() {
        if ($(this).attr('href') === currentUrl) {
            $(this).addClass('active');
        }
    });
});
</script>
</body>
</html>