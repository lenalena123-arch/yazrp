<?php
require_once 'config.php';

// Получаем параметры фильтрации из GET-запроса
$filterName  = $_GET['nazv_pogr'] ?? '';
$filterModel = $_GET['model'] ?? '';
$filterType  = $_GET['tip_texniki'] ?? '';
$filterTipGryza = $_GET['tip_gryza'] ?? '';

$whereClauses = [];
$params = [];
$types = '';

// Формируем условия для SQL-запроса
if ($filterName !== '') {
    $whereClauses[] = "nazv_pogr = ?";
    $params[] = $filterName;
    $types .= 's';
}
if ($filterModel !== '') {
    $whereClauses[] = "model = ?";
    $params[] = $filterModel;
    $types .= 's';
}
if ($filterType !== '') {
    $whereClauses[] = "tip_texniki = ?";
    $params[] = $filterType;
    $types .= 's';
}
if ($filterTipGryza !== '') {
    $whereClauses[] = "tip_gryza = ?";
    $params[] = $filterTipGryza;
    $types .= 's';
}

$whereSql = !empty($whereClauses) ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

// Получаем список погрузчиков с учетом фильтров
$sql = "SELECT * FROM pogryzchik $whereSql";
$stmt = $link->prepare($sql);
if (!empty($whereClauses)) {
    $stmt->bind_param($types, ...$params);
}
$result = $stmt->execute();
$pogruzchiki = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

if (!empty($pogruzchiki)) {
    foreach ($pogruzchiki as $p): 
        $v_nalichii = $p['v_nalichii'];
        $stockStatus = $v_nalichii === 'Да' ? 'Есть на складе' : 'Нет на складе';
        $badgeVariant = $v_nalichii === 'Да' ? 'bg-success' : 'bg-danger';
        $stockIcon = $v_nalichii === 'Да' ? 'check-circle' : 'clock';
        ?>
        <div class="col-lg-4 col-md-6 mb-4 fade-in">
            <div class="card h-100">
                <div class="position-relative">
                    <img src="<?= htmlspecialchars($p['image'] ?? 'https://via.placeholder.com/400x250') ?>" 
                         class="card-img-top p-3" 
                         alt="<?= htmlspecialchars($p['nazv_pogr'] ?? '') ?>">
                    <span class="badge <?= $badgeVariant ?> position-absolute top-0 end-0 m-2">
                        <?= $stockStatus ?>
                    </span>
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($p['nazv_pogr'] ?? '') ?></h5>
                    
                    <div class="specs mb-3">
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-tag text-muted me-2"></i>
                            <span><strong>Модель:</strong> <?= htmlspecialchars($p['model'] ?? '') ?></span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-truck-monster text-muted me-2"></i>
                            <span><strong>Тип техники:</strong> <?= htmlspecialchars($p['tip_texniki'] ?? '') ?></span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-arrow-up text-muted me-2"></i>
                            <span><strong>Высота подъема:</strong> <?= htmlspecialchars($p['visota_podema_gryza'] ?? '') ?> </span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-weight-hanging text-muted me-2"></i>
                            <span><strong>Грузоподъемность:</strong> <?= htmlspecialchars($p['maks_ves_gryza'] ?? '') ?> </span>
                        </div>
                        <div class="d-flex align-items-center">
                            <i class="fas fa-boxes text-muted me-2"></i>
                            <span><strong>Тип груза:</strong> <?= htmlspecialchars($p['tip_gryza'] ?? '') ?></span>
                        </div>
                    </div>
                    
                    <div class="mt-auto">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="stock">
                                <i class="fas fa-<?= $stockIcon ?> me-1"></i>
                                <span><?= $stockStatus ?></span>
                            </div>
                        </div>
                        
                        <a href="arenda.php?id_pogr=<?= $p['id_pogr'] ?? '' ?>" 
                           class="btn btn-primary w-100">
                            <i class="fas fa-calendar-check me-2"></i>Арендовать
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach;
} else {
    echo '<div class="col-12 fade-in">
        <div class="no-results bg-white rounded p-5 text-center">
            <i class="fas fa-truck fa-3x text-muted mb-4"></i>
            <h4 class="mb-3">Погрузчики не найдены</h4>
            <p class="text-muted">Попробуйте изменить параметры фильтрации</p>
            <a href="pogryzchiki.php" class="btn btn-primary mt-3">
                <i class="fas fa-undo me-2"></i>Сбросить фильтры
            </a>
        </div>
    </div>';
}
?>