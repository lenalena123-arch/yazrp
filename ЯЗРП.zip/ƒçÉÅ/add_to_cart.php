<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user']['id'])) {
    die(json_encode(['error' => 'Необходима авторизация']));
}

$user_id = $_SESSION['user']['id'];
$id_zapch = $_POST['id_zapch'];
$action = $_POST['action'];

switch ($action) {
    case 'add':
        // Проверяем, есть ли уже эта запчасть в корзине
        $check = $link->prepare("SELECT id_korz, kolvo FROM korzina WHERE id_user = ? AND id_zapch = ? AND status = 'Не оформлен'");
        $check->bind_param("ii", $user_id, $id_zapch);
        $check->execute();
        $result = $check->get_result();
        
        if ($result->num_rows > 0) {
            // Увеличиваем количество
            $row = $result->fetch_assoc();
            $new_quantity = $row['kolvo'] + 1;
            $update = $link->prepare("UPDATE korzina SET kolvo = ? WHERE id_korz = ?");
            $update->bind_param("ii", $new_quantity, $row['id_korz']);
            $update->execute();
        } else {
            // Добавляем новую запись
            $insert = $link->prepare("INSERT INTO korzina (id_user, id_zapch, kolvo, status, dostavka) VALUES (?, ?, 1, 'Не оформлен', 'Самовывоз')");
            $insert->bind_param("ii", $user_id, $id_zapch);
            $insert->execute();
        }
        break;
        
    case 'increase':
        $update = $link->prepare("UPDATE korzina SET kolvo = kolvo + 1 WHERE id_user = ? AND id_zapch = ? AND status = 'Не оформлен'");
        $update->bind_param("ii", $user_id, $id_zapch);
        $update->execute();
        break;
        
    case 'decrease':
        $update = $link->prepare("UPDATE korzina SET kolvo = kolvo - 1 WHERE id_user = ? AND id_zapch = ? AND status = 'Не оформлен'");
        $update->bind_param("ii", $user_id, $id_zapch);
        $update->execute();
        break;
        
    case 'remove':
        $delete = $link->prepare("DELETE FROM korzina WHERE id_user = ? AND id_zapch = ? AND status = 'Не оформлен'");
        $delete->bind_param("ii", $user_id, $id_zapch);
        $delete->execute();
        break;
}

echo json_encode(['success' => true]);
?>