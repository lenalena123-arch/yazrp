<?php
require_once 'db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$id_user = $_POST['id_user'];
$id_pogr = $_POST['id_pogr'];
$id_tip_zayavki = $_POST['id_tip_zayavki'];
$data_zayavki = date('Y-m-d');
$opisanie = $_POST['opisanie'] ?? null;
$status = "Отправлена";

$nachalo_arendi = $_POST['nachalo_arendi'] ?? null;
$konec_arendi = $_POST['konec_arendi'] ?? null;
$kolvo_motochasov = $_POST['kolvo_motochasov'] ?? null;

$stmt = $link->prepare("INSERT INTO zayavki (id_user, id_pogr, id_tip_zayavki, data_zayavki, nachalo_arendi, konec_arendi, kolvo_motochasov, opisanie, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("iiisssiss", $id_user, $id_pogr, $id_tip_zayavki, $data_zayavki, $nachalo_arendi, $konec_arendi, $kolvo_motochasov, $opisanie, $status);
$stmt->execute();

header("Location: zayavki.php");
exit();
?>