<?php
session_start();
require_once 'config.php';

// Проверка прав администратора
if (!isset($_SESSION['user']['id']) || $_SESSION['user']['id_role'] != 1) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Админ-панель - ЯЗРП</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #253482;
      --secondary-color: #FF6B00;
    }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex; 
      flex-direction: column; 
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .top-bar {
      background-color: var(--primary-color);
      height: 20px;
    }
    .header-info {
      background-color: #ffffff;
      padding: 15px;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .logo-and-text {
      display: flex;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    .header-info img {
      height: 60px;
      transition: transform 0.3s;
    }
    .header-info img:hover {
      transform: scale(1.05);
    }
    .header-text .title {
      font-weight: bold;
      font-size: 1.2rem;
      color: #000;
    }
    .header-text .location {
      font-size: 1rem;
      color: #333;
    }
    .divider {
      border-left: 1px solid #ccc;
      height: 50px;
    }
    .navbar-custom { 
      background-color: var(--primary-color) !important; 
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    }
    .navbar-custom .nav-link { 
      color: white !important; 
      padding: 10px 15px;
      transition: all 0.3s;
    }
    .navbar-custom .nav-link:hover {
      color: var(--secondary-color) !important;
    }
    .navbar-nav .nav-link.active {
      color: var(--secondary-color) !important;
      font-weight: bold;
      position: relative;
    }
    .navbar-nav .nav-link.active:after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 100%;
      height: 3px;
      background: var(--secondary-color);
    }

    .admin-section {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      padding: 40px 15px;
      background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('background-pattern.png');
      background-size: cover;
    }

    .admin-card {
      width: 100%;
      max-width: 800px;
      padding: 30px;
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      border-top: 5px solid var(--primary-color);
    }

    .admin-card h2 {
      margin-bottom: 25px;
      color: var(--primary-color);
      font-weight: 700;
      text-align: center;
      position: relative;
      padding-bottom: 15px;
    }

    .admin-card h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: var(--secondary-color);
    }

    .admin-menu {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 30px;
    }

    .admin-menu-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 25px;
      background: #f9f9f9;
      border-radius: 10px;
      border: 1px solid #ddd;
      transition: all 0.3s;
      text-decoration: none;
      color: var(--primary-color);
    }

    .admin-menu-item:hover {
      transform: translateY(-5px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      border-color: var(--primary-color);
    }

    .admin-menu-icon {
      font-size: 2.5rem;
      margin-bottom: 15px;
      color: var(--primary-color);
    }

    .admin-menu-title {
      font-weight: 600;
      font-size: 1.2rem;
      text-align: center;
      margin-bottom: 10px;
    }

    .admin-menu-desc {
      font-size: 0.9rem;
      color: #666;
      text-align: center;
    }

    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      font-size: 1rem;
      padding: 0.6rem 1.2rem;
      border-radius: 8px;
      transition: all 0.3s;
      font-weight: 500;
    }

    .btn-primary:hover {
      background-color: #1a285f;
      border-color: #1a285f;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .footer {
      background: #222;
      color: #fff;
      padding: 30px 15px;
      text-align: center;
    }

    @media (max-width: 768px) {
      .header-info {
        flex-direction: column;
        align-items: flex-start;
      }
      .header-text {
        flex-direction: column;
        align-items: flex-start;
      }
      .divider {
        display: none;
      }
      .admin-card {
        padding: 20px;
      }
      .admin-menu {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="d-flex align-items-center">
            <a href="glavnaya.php">
                <img src="logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
      <div class="container-fluid d-flex justify-content-between align-items-center">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
            <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
            <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
            <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
            <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
            <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
            <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
            <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
          </ul>
        </div>
        <div class="d-none d-lg-block">
            <?php if (isset($_SESSION['user'])): ?>
                <div class="d-flex gap-3 align-items-center">
                    <a class="nav-link active" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                    <a class="nav-link" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                </div>
            <?php else: ?>
                <a class="btn btn-outline-light" href="login.php">Войти</a>
            <?php endif; ?>
        </div>
      </div>
    </nav>

    <section class="admin-section">
      <div class="admin-card">
        <h2>Панель администратора</h2>
        
        <div class="admin-menu">
          <!-- 1. Управление запчастями -->
          <a href="AdminPages/admin_zapchasti.php" class="admin-menu-item">
            <i class="fas fa-cogs admin-menu-icon"></i>
            <div class="admin-menu-title">Управление запчастями</div>
            <div class="admin-menu-desc">Добавление, редактирование и удаление запчастей</div>
          </a>
          
          <!-- 2. Управление погрузчиками -->
          <a href="AdminPages/admin_pogryzchiki.php" class="admin-menu-item">
            <i class="fas fa-truck-monster admin-menu-icon"></i>
            <div class="admin-menu-title">Управление погрузчиками</div>
            <div class="admin-menu-desc">Редактирование каталога погрузчиков</div>
          </a>
          
          <!-- 3. Управление заявками -->
          <a href="AdminPages/admin_applications.php" class="admin-menu-item">
            <i class="fas fa-clipboard-list admin-menu-icon"></i>
            <div class="admin-menu-title">Управление заявками</div>
            <div class="admin-menu-desc">Просмотр и обработка заявок на ремонт и аренду</div>
          </a>
          
          <!-- 4. Управление пользователями -->
          <a href="AdminPages/admin_users.php" class="admin-menu-item">
            <i class="fas fa-users admin-menu-icon"></i>
            <div class="admin-menu-title">Управление пользователями</div>
            <div class="admin-menu-desc">Просмотр и редактирование пользователей</div>
          </a>
          
          <!-- 5. Управление заказами -->
          <a href="AdminPages/admin_orders.php" class="admin-menu-item">
            <i class="fas fa-shopping-cart admin-menu-icon"></i>
            <div class="admin-menu-title">Управление заказами</div>
            <div class="admin-menu-desc">Просмотр и обработка заказов запчастей</div>
          </a>
          
          <!-- 6. Управление отзывами -->
          <a href="AdminPages/admin_reviews.php" class="admin-menu-item">
            <i class="fas fa-comments admin-menu-icon"></i>
            <div class="admin-menu-title">Управление отзывами</div>
            <div class="admin-menu-desc">Модерация отзывов о компании</div>
          </a>
        </div>
      </div>
    </section>

    <footer class="footer">
      <div class="container">
        <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>