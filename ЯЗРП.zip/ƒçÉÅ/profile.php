<?php
session_start();
require_once 'config.php';

// Настройки для загрузки аватара
$upload_dir = 'uploads/avatars/';
$allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
$max_size = 2 * 1024 * 1024; // 2MB

// Создаем директорию, если ее нет
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

if (!isset($_SESSION['user']['id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];

// Запрос к базе данных для получения информации о пользователе
$stmt = $link->prepare("SELECT u.*, r.nazv_role FROM users u JOIN role r ON u.id_role = r.id_role WHERE u.id_user = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "Ошибка: пользователь не найден.";
    exit();
}

$user = $result->fetch_assoc();

// Обработка обновления данных
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // Проверяем обязательные поля
    $required_fields = ['familia', 'imya', 'email', 'login'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['success' => false, 'message' => 'Заполните все обязательные поля']);
            exit();
        }
    }

    // Получаем данные из формы
    $familia = trim($_POST['familia']);
    $imya = trim($_POST['imya']);
    $otchestvo = trim($_POST['otchestvo'] ?? '');
    $nazv_ofisa = trim($_POST['nazv_ofisa'] ?? '');
    $adres_ofisa = trim($_POST['adres_ofisa'] ?? '');
    $email = trim($_POST['email']);
    $telefon = trim($_POST['telefon'] ?? '');
    $login = trim($_POST['login']);
    
    // Проверка уникальности email
    $check_stmt = $link->prepare("SELECT id_user FROM users WHERE email = ? AND id_user != ?");
    $check_stmt->bind_param("si", $email, $user_id);
    $check_stmt->execute();
    if ($check_stmt->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Этот email уже используется другим пользователем']);
        exit();
    }

    // Проверка уникальности логина
    $check_stmt = $link->prepare("SELECT id_user FROM users WHERE login = ? AND id_user != ?");
    $check_stmt->bind_param("si", $login, $user_id);
    $check_stmt->execute();
    if ($check_stmt->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Этот логин уже занят']);
        exit();
    }

    // Валидация телефона
    if (!empty($telefon) && !preg_match('/^\+?\d{10,15}$/', $telefon)) {
        echo json_encode(['success' => false, 'message' => 'Некорректный формат телефона']);
        exit();
    }
    
    // Проверка пароля, если введен новый
    $password_updated = false;
    if (!empty($_POST['new_password'])) {
        // Проверяем старый пароль
        $old_password = $_POST['old_password'];
        if (!password_verify($old_password, $user['parol'])) {
            echo json_encode(['success' => false, 'message' => 'Неверный старый пароль']);
            exit();
        }
        
        // Хешируем новый пароль
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $password_updated = true;
    }
    
    // Обработка аватара
    $avatar_path = $user['image'] ?? 'defaultAva.png';
    if (!empty($_FILES['avatar']['name'])) {
        $file = $_FILES['avatar'];
        
        // Проверка типа файла
        if (!in_array($file['type'], $allowed_types)) {
            echo json_encode(['success' => false, 'message' => 'Недопустимый тип файла']);
            exit();
        }
        
        // Проверка размера файла
        if ($file['size'] > $max_size) {
            echo json_encode(['success' => false, 'message' => 'Файл слишком большой']);
            exit();
        }
        
        // Генерируем уникальное имя файла
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'avatar_' . $user_id . '_' . time() . '.' . $ext;
        $destination = $upload_dir . $filename;
        
        // Пытаемся загрузить файл
        if (move_uploaded_file($file['tmp_name'], $destination)) {
            // Удаляем старый аватар, если он не дефолтный
            if ($avatar_path !== 'defaultAva.png' && file_exists($avatar_path)) {
                unlink($avatar_path);
            }
            $avatar_path = $destination;
        } else {
            echo json_encode(['success' => false, 'message' => 'Ошибка загрузки файла']);
            exit();
        }
    }
    
    try {
        // Обновление данных в базе
        if ($password_updated) {
            $update_stmt = $link->prepare("UPDATE users SET familia=?, imya=?, otchestvo=?, nazv_ofisa=?, adres_ofisa=?, email=?, telefon=?, login=?, parol=?, image=? WHERE id_user=?");
            $update_stmt->bind_param("ssssssssssi", $familia, $imya, $otchestvo, $nazv_ofisa, $adres_ofisa, $email, $telefon, $login, $new_password, $avatar_path, $user_id);
        } else {
            $update_stmt = $link->prepare("UPDATE users SET familia=?, imya=?, otchestvo=?, nazv_ofisa=?, adres_ofisa=?, email=?, telefon=?, login=?, image=? WHERE id_user=?");
            $update_stmt->bind_param("sssssssssi", $familia, $imya, $otchestvo, $nazv_ofisa, $adres_ofisa, $email, $telefon, $login, $avatar_path, $user_id);
        }
        
        if ($update_stmt->execute()) {
            // Обновляем данные в сессии
            $_SESSION['user']['familia'] = $familia;
            $_SESSION['user']['imya'] = $imya;
            $_SESSION['user']['otchestvo'] = $otchestvo;
            $_SESSION['user']['login'] = $login;
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['image'] = $avatar_path;
            
            echo json_encode([
                'success' => true, 
                'message' => 'Данные успешно обновлены',
                'avatar' => $avatar_path
            ]);
            exit();
        } else {
            throw new Exception('Ошибка выполнения запроса: ' . $update_stmt->error);
        }
    } catch (Exception $e) {
        error_log($e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Ошибка при обновлении данных: ' . $e->getMessage()]);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Профиль - ЯЗРП</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #253482;
      --secondary-color: #FF6B00;
    }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex; 
      flex-direction: column; 
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .top-bar {
      background-color: var(--primary-color);
      height: 20px;
    }
    .header-info {
      background-color: #ffffff;
      padding: 15px;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .logo-and-text {
      display: flex;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    .header-info img {
      height: 60px;
      transition: transform 0.3s;
    }
    .header-info img:hover {
      transform: scale(1.05);
    }
    .header-text .title {
      font-weight: bold;
      font-size: 1.2rem;
      color: #000;
    }
    .header-text .location {
      font-size: 1rem;
      color: #333;
    }
    .divider {
      border-left: 1px solid #ccc;
      height: 50px;
    }
    .navbar-custom { 
      background-color: var(--primary-color) !important; 
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    }
    .navbar-custom .nav-link { 
      color: white !important; 
      padding: 10px 15px;
      transition: all 0.3s;
    }
    .navbar-custom .nav-link:hover {
      color: var(--secondary-color) !important;
    }
    .navbar-nav .nav-link.active {
      color: var(--secondary-color) !important;
      font-weight: bold;
      position: relative;
    }
    .navbar-nav .nav-link.active:after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 100%;
      height: 3px;
      background: var(--secondary-color);
    }

    .profile-section {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      padding: 40px 15px;
      background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('background-pattern.png');
      background-size: cover;
    }

    .profile-card {
      width: 100%;
      max-width: 800px;
      padding: 30px;
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      border-top: 5px solid var(--primary-color);
    }

    .profile-card h2 {
      margin-bottom: 25px;
      color: var(--primary-color);
      font-weight: 700;
      text-align: center;
      position: relative;
      padding-bottom: 15px;
    }

    .profile-card h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: var(--secondary-color);
    }

    .profile-info {
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
    }

    .profile-avatar {
      flex: 1;
      min-width: 250px;
      text-align: center;
    }

    .profile-details {
      flex: 2;
      min-width: 300px;
    }

    .avatar-preview {
      width: 200px;
      height: 200px;
      border-radius: 50%;
      border: 3px solid var(--primary-color);
      object-fit: cover;
      margin-bottom: 15px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .avatar-preview:hover {
      transform: scale(1.05);
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }

    .info-item {
      margin-bottom: 15px;
      padding-bottom: 15px;
      border-bottom: 1px solid #eee;
    }

    .info-label {
      font-weight: 600;
      color: var(--primary-color);
      margin-bottom: 5px;
    }

    .info-value {
      font-size: 1.1rem;
    }

    .edit-form {
      display: none;
      margin-top: 20px;
      padding: 20px;
      background: #f9f9f9;
      border-radius: 10px;
      border: 1px solid #ddd;
    }

    .form-control {
      border-radius: 8px;
      padding: 12px 15px;
      border: 1px solid #ddd;
      transition: all 0.3s;
      margin-bottom: 15px; /* Уменьшил отступ */
    }

    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      font-size: 1rem;
      padding: 0.6rem 1.2rem;
      border-radius: 8px;
      transition: all 0.3s;
      font-weight: 500;
    }

    .btn-primary:hover {
      background-color: #1a285f;
      border-color: #1a285f;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .btn-secondary {
      background-color: #6c757d;
      border-color: #6c757d;
      font-size: 1rem;
      padding: 0.6rem 1.2rem;
    }

    .btn-secondary:hover {
      background-color: #5a6268;
      border-color: #5a6268;
    }

    .btn-danger {
      background-color: #dc3545;
      border-color: #dc3545;
      font-size: 1rem;
      padding: 0.6rem 1.2rem;
    }

    .btn-danger:hover {
      background-color: #c82333;
      border-color: #bd2130;
    }

    .btn-group-profile {
      display: flex;
      flex-direction: column; /* Изменил на колонку */
      gap: 10px;
      justify-content: center;
      margin-top: 15px;
    }

    .btn-group-profile .btn {
      width: 100%; /* Занимают всю ширину */
      max-width: none; /* Убрал ограничение */
    }

    .applications-toggle {
      color: var(--primary-color);
      cursor: pointer;
      margin-top: 20px;
      font-weight: 600;
      display: inline-block;
      padding: 10px 15px; /* Добавил отступы для увеличения кнопки */
      border: 1px solid var(--primary-color); /* Добавил рамку */
      border-radius: 8px; /* Скруглил углы */
      transition: all 0.3s;
      width: 100%; /* Занимают всю ширину */
      text-align: left; /* Текст слева */
    }

    .applications-toggle:hover {
      color: white;
      background-color: var(--primary-color);
      text-decoration: none; /* Убрал подчеркивание */
    }

    .applications-container {
      display: none;
      margin-top: 20px;
      padding: 20px;
      background: #f9f9f9;
      border-radius: 10px;
      border: 1px solid #ddd;
    }

    .application-item {
      padding: 15px;
      margin-bottom: 10px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .application-item strong {
      display: inline-block;
      min-width: 150px; /* Увеличил минимальную ширину для меток */
      margin-right: 5px;
      font-weight: 700; /* Сделал жирнее */
    }
    
    .footer {
      background: #222;
      color: #fff;
      padding: 30px 15px;
      text-align: center;
    }

    @media (max-width: 768px) {
      .header-info {
        flex-direction: column;
        align-items: flex-start;
      }
      .header-text {
        flex-direction: column;
        align-items: flex-start;
      }
      .divider {
        display: none;
      }
      .profile-card {
        padding: 20px;
      }
      .profile-info {
        flex-direction: column;
      }
      .profile-avatar, .profile-details {
        min-width: 100%;
      }
      .btn-group-profile {
        flex-direction: column;
      }
      .btn-group-profile .btn {
        max-width: 100%;
      }
    }
  </style>
</head>
<body>
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="d-flex align-items-center">
            <a href="glavnaya.php">
                <img src="logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
      <div class="container-fluid d-flex justify-content-between align-items-center">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
            <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
            <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
            <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
            <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
            <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
            <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
            <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
          </ul>
        </div>
        <div class="d-none d-lg-block">
            <?php if (isset($_SESSION['user'])): ?>
                <div class="d-flex gap-3 align-items-center">
                    <?php if ($_SESSION['user']['id_role'] == 1): ?>
                        <a class="nav-link" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                    <?php endif; ?>
                    <a class="nav-link active" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                    <?php if ($_SESSION['user']['id_role'] != 1): ?>
                        <a class="nav-link" href="cart.php" style="color: white;"><i class="fas fa-shopping-cart"></i></a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <a class="btn btn-outline-light" href="login.php">Войти</a>
            <?php endif; ?>
        </div>
      </div>
    </nav>

    <section class="profile-section">
      <div class="profile-card">
        <h2>Профиль пользователя</h2>
        
        <div class="profile-info">
          <div class="profile-avatar">
            <img src="<?= htmlspecialchars($user['image'] ?? 'defaultAva.png') ?>" alt="Аватар" class="avatar-preview">
            <div class="btn-group-profile">
              <button id="editBtn" class="btn btn-primary">Изменить данные</button>
              <a href="logout.php" class="btn btn-danger">Выйти</a>
            </div>
          </div>
          
          <div class="profile-details">
            <div class="info-item">
              <div class="info-label">ФИО</div>
              <div class="info-value" id="display-name"><?= htmlspecialchars($user['familia'] . ' ' . $user['imya'] . ' ' . $user['otchestvo']) ?></div>
            </div>
            
            <div class="info-item">
              <div class="info-label">Роль</div>
              <div class="info-value"><?= htmlspecialchars($user['nazv_role']) ?></div>
            </div>
            
            <div class="info-item">
              <div class="info-label">Логин</div>
              <div class="info-value" id="display-login"><?= htmlspecialchars($user['login']) ?></div>
            </div>
            
            <div class="info-item">
              <div class="info-label">Email</div>
              <div class="info-value" id="display-email"><?= htmlspecialchars($user['email']) ?></div>
            </div>
            
            <div class="info-item">
              <div class="info-label">Телефон</div>
              <div class="info-value" id="display-phone"><?= htmlspecialchars($user['telefon']) ?></div>
            </div>
            
            <div class="info-item">
              <div class="info-label">Организация</div>
              <div class="info-value" id="display-org"><?= htmlspecialchars($user['nazv_ofisa']) ?></div>
            </div>
            
            <div class="info-item">
              <div class="info-label">Адрес офиса</div>
              <div class="info-value" id="display-address"><?= htmlspecialchars($user['adres_ofisa']) ?></div>
            </div>
          </div>
        </div>
        
        <!-- Форма редактирования -->
        <form id="editForm" class="edit-form" method="POST" enctype="multipart/form-data">
          <input type="hidden" name="update_profile" value="1">
          <h4>Изменение данных</h4>
          <div class="row">
            <div class="col-md-4">
              <label class="form-label">Фамилия</label>
              <input type="text" class="form-control" name="familia" value="<?= htmlspecialchars($user['familia']) ?>" required>
            </div>
            <div class="col-md-4">
              <label class="form-label">Имя</label>
              <input type="text" class="form-control" name="imya" value="<?= htmlspecialchars($user['imya']) ?>" required>
            </div>
            <div class="col-md-4">
              <label class="form-label">Отчество</label>
              <input type="text" class="form-control" name="otchestvo" value="<?= htmlspecialchars($user['otchestvo']) ?>">
            </div>
          </div>
          
          <div class="row">
            <div class="col-md-6">
              <label class="form-label">Название организации</label>
              <input type="text" class="form-control" name="nazv_ofisa" value="<?= htmlspecialchars($user['nazv_ofisa']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Адрес офиса</label>
              <input type="text" class="form-control" name="adres_ofisa" value="<?= htmlspecialchars($user['adres_ofisa']) ?>">
            </div>
          </div>
          
          <div class="row">
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Телефон</label>
              <input type="text" class="form-control" name="telefon" value="<?= htmlspecialchars($user['telefon']) ?>">
            </div>
          </div>
          
          <div class="row">
            <div class="col-md-12">
              <label class="form-label">Логин</label>
              <input type="text" class="form-control" name="login" value="<?= htmlspecialchars($user['login']) ?>" required>
            </div>
          </div>
          
          <div class="row">
            <div class="col-md-6">
              <label class="form-label">Старый пароль</label>
              <input type="password" class="form-control" name="old_password" placeholder="Введите старый пароль для смены">
            </div>
            <div class="col-md-6">
              <label class="form-label">Новый пароль</label>
              <input type="password" class="form-control" name="new_password" placeholder="Введите новый пароль">
            </div>
          </div>
          
          <div class="row mt-3">
            <div class="col-md-12">
              <label class="form-label">Аватар</label>
              <input type="file" class="form-control" name="avatar" id="avatarInput" accept="image/*">
              <small class="text-muted">Максимальный размер файла: 2MB. Допустимые форматы: JPG, PNG, GIF.</small>
            </div>
          </div>
          
          <div class="mt-3 d-flex justify-content-end gap-2">
            <button type="button" id="cancelEdit" class="btn btn-secondary">Отмена</button>
            <button type="submit" class="btn btn-primary">Сохранить изменения</button>
          </div>
        </form>
        
        <!-- Блок с заявками (только для пользователей) -->
        <?php if ($user['id_role'] != 1): ?>
          <button class="applications-toggle" id="toggleApplications">
            <i class="fas fa-chevron-down me-2"></i>Мои заявки
          </button>
          
          <div class="applications-container" id="applicationsContainer">
            <h5>История заявок</h5>
            <?php
            // Запрос для получения заявок пользователя
            $stmt = $link->prepare("SELECT zayavki.*, tip_zayavki.nazv_tip_zayavki AS nazv_tip_zayavki, pogryzchik.nazv_pogr, pogryzchik.model 
                                  FROM zayavki 
                                  JOIN tip_zayavki ON zayavki.id_tip_zayavki = tip_zayavki.id_tip_zayavki 
                                  LEFT JOIN pogryzchik ON zayavki.id_pogr = pogryzchik.id_pogr 
                                  WHERE zayavki.id_user = ? 
                                  ORDER BY zayavki.data_zayavki DESC");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $applications = $stmt->get_result();
            
            if ($applications->num_rows > 0) {
                while ($app = $applications->fetch_assoc()) {
                    echo '<div class="application-item">';
                    echo '<div><strong>Тип заявки:</strong> ' . htmlspecialchars($app['nazv_tip_zayavki']) . '</div>';
                    echo '<div><strong>Погрузчик:</strong> ' . htmlspecialchars($app['nazv_pogr'] ? $app['nazv_pogr'] . ' (' . $app['model'] . ')' : 'Не указан') . '</div>';
                    echo '<div><strong>Дата заявки:</strong> ' . htmlspecialchars($app['data_zayavki']) . '</div>';
                    echo '<div><strong>Начало аренды:</strong> ' . htmlspecialchars($app['nachalo_arendi'] ?? '—') . '</div>';
                    echo '<div><strong>Конец аренды:</strong> ' . htmlspecialchars($app['konec_arendi'] ?? '—') . '</div>';
                    echo '<div><strong>Кол-во моточасов:</strong> ' . htmlspecialchars($app['kolvo_motochasov'] ?? '—') . '</div>';
                    echo '<div><strong>Описание:</strong> ' . htmlspecialchars($app['opisanie']) . '</div>';
                    echo '<div><strong>Статус:</strong> ' . htmlspecialchars($app['status']) . '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>У вас пока нет оформленных заявок.</p>';
            }
            ?>
          </div>
        <?php endif; ?>
      </div>
    </section>

    <footer class="footer">
      <div class="container">
        <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // Переключение формы редактирования
        $('#editBtn').click(function() {
          $('.edit-form').slideDown();
          $(this).hide();
        });
        
        $('#cancelEdit').click(function() {
          $('.edit-form').slideUp();
          $('#editBtn').show();
        });
        
        // Переключение блока заявок
        $('#toggleApplications').click(function() {
          $('#applicationsContainer').slideToggle();
          $(this).find('i').toggleClass('fa-chevron-down fa-chevron-up');
        });
        
        // AJAX отправка формы
        $('#editForm').submit(function(e) {
          e.preventDefault();
          
          var formData = new FormData(this);
          
          $.ajax({
            url: '',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
              if (response.success) {
                alert(response.message);
                
                // Обновляем отображаемые данные
                $('#display-name').text($('input[name="familia"]').val() + ' ' + $('input[name="imya"]').val() + ' ' + $('input[name="otchestvo"]').val());
                $('#display-login').text($('input[name="login"]').val());
                $('#display-email').text($('input[name="email"]').val());
                $('#display-phone').text($('input[name="telefon"]').val());
                $('#display-org').text($('input[name="nazv_ofisa"]').val());
                $('#display-address').text($('input[name="adres_ofisa"]').val());
                
                // Обновляем аватар, если он был изменен
                if (response.avatar) {
                  $('.avatar-preview').attr('src', response.avatar + '?' + new Date().getTime());
                }
                
                // Скрываем форму и показываем кнопку "Изменить данные"
                $('.edit-form').slideUp();
                $('#editBtn').show();
              } else {
                alert(response.message);
              }
            },
            error: function(jqXHR, textStatus, errorThrown) {
              console.log(jqXHR.responseText);
              alert('Произошла ошибка при обновлении данных. Проверьте консоль для подробностей.');
            }
          });
        });
      });
    </script>
</body>
</html>