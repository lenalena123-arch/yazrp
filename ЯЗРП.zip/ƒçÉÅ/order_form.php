<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user']['id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];
$id_zapch = isset($_GET['id_zapch']) ? intval($_GET['id_zapch']) : 0;
$id_korz = isset($_GET['id_korz']) ? intval($_GET['id_korz']) : 0;

// Получаем информацию о товаре
$sql = "SELECT k.*, z.nazv_zapch, z.tsena, z.image, t.nazv_tip_zapch 
        FROM korzina k 
        JOIN zapchasti z ON k.id_zapch = z.id_zapch 
        JOIN tip_zapchasti t ON z.id_tip_zapch = t.id_tip_zapch 
        WHERE k.id_korz = ? AND k.id_user = ?";
$stmt = $link->prepare($sql);
$stmt->bind_param("ii", $id_korz, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$item = $result->fetch_assoc();

if (!$item) {
    header("Location: cart.php");
    exit();
}

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dostavka = $_POST['dostavka'];
    
    // Устанавливаем дату приезда (текущая дата + 2 недели)
    $delivery_date = new DateTime();
    $delivery_date->add(new DateInterval('P14D'));
    $data_priezda = $delivery_date->format('Y-m-d H:i:s');
    
    $update = $link->prepare("UPDATE korzina SET status = 'Оформлен', dostavka = ?, data_priezda = ? WHERE id_korz = ?");
    $update->bind_param("ssi", $dostavka, $data_priezda, $id_korz);
    $update->execute();
    
    header("Location: cart.php");
    exit();
}

// Рассчитываем дату приезда (текущая дата + 2 недели)
$delivery_date = new DateTime();
$delivery_date->add(new DateInterval('P14D'));
$formatted_delivery_date = $delivery_date->format('d.m.Y');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Оформление заказа | ЯЗРП</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #253482;
      --secondary-color: #FF6B00;
    }
    
    .order-card {
      width: 100%;
      max-width: 1000px;
      padding: 30px;
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      border-top: 5px solid var(--primary-color);
      margin: 40px auto;
    }
    
    .order-card h2 {
      margin-bottom: 25px;
      color: var(--primary-color);
      font-weight: 700;
      text-align: center;
      position: relative;
      padding-bottom: 15px;
    }
    
    .order-card h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: var(--secondary-color);
    }
    
    .order-item {
      display: flex;
      align-items: center;
      padding: 15px;
      margin-bottom: 20px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    .order-item-image {
      width: 100px;
      height: 100px;
      object-fit: contain;
      border-radius: 5px;
      margin-right: 20px;
      border: 1px solid #eee;
      padding: 5px;
      background: white;
    }
    
    .delivery-options {
      margin-top: 30px;
      padding: 20px;
      background: #f9f9f9;
      border-radius: 10px;
      border: 1px solid #ddd;
    }
    
    .delivery-option {
      display: flex;
      align-items: center;
      padding: 15px;
      border: 1px solid #ddd;
      border-radius: 8px;
      margin-bottom: 15px;
      cursor: pointer;
      transition: all 0.3s;
    }
    
    .delivery-option:hover {
      border-color: var(--secondary-color);
    }
    
    .delivery-option.active {
      border-color: var(--secondary-color);
      background-color: rgba(255, 107, 0, 0.05);
    }
    
    .delivery-option input[type="radio"] {
      margin-right: 15px;
    }
    
    .btn-checkout {
      background-color: var(--secondary-color);
      color: white;
      padding: 12px;
      font-size: 1.1rem;
      width: 100%;
      margin-top: 20px;
      border: none;
      border-radius: 8px;
      transition: all 0.3s;
    }
    
    .btn-checkout:hover {
      background-color: #e05d00;
    }
    
    /* Общие стили из примера */
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex; 
      flex-direction: column; 
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .top-bar {
      background-color: var(--primary-color);
      height: 20px;
    }
    .header-info {
      background-color: #ffffff;
      padding: 15px;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .logo-and-text {
      display: flex;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    .header-info img {
      height: 60px;
      transition: transform 0.3s;
    }
    .header-info img:hover {
      transform: scale(1.05);
    }
    .header-text .title {
      font-weight: bold;
      font-size: 1.2rem;
      color: #000;
    }
    .header-text .location {
      font-size: 1rem;
      color: #333;
    }
    .divider {
      border-left: 1px solid #ccc;
      height: 50px;
    }
    .navbar-custom { 
      background-color: var(--primary-color) !important; 
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    }
    .navbar-custom .nav-link { 
      color: white !important; 
      padding: 10px 15px;
      transition: all 0.3s;
    }
    .navbar-custom .nav-link:hover {
      color: var(--secondary-color) !important;
    }
    .navbar-nav .nav-link.active {
      color: var(--secondary-color) !important;
      font-weight: bold;
      position: relative;
    }
    .navbar-nav .nav-link.active:after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 100%;
      height: 3px;
      background: var(--secondary-color);
    }
    .footer {
      background: #222;
      color: #fff;
      padding: 30px 15px;
      text-align: center;
      margin-top: auto;
    }
    @media (max-width: 768px) {
      .header-info {
        flex-direction: column;
        align-items: flex-start;
      }
      .header-text {
        flex-direction: column;
        align-items: flex-start;
      }
      .divider {
        display: none;
      }
      .order-item {
        flex-direction: column;
        text-align: center;
      }
      .order-item-image {
        margin-right: 0;
        margin-bottom: 15px;
      }
    }
  </style>
</head>
<body>
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <div class="d-flex align-items-center">
            <a href="glavnaya.php">
                <img src="logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
      <div class="container-fluid d-flex justify-content-between align-items-center">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
            <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
            <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
            <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
            <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
            <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
            <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
            <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
          </ul>
        </div>
        <div class="d-none d-lg-block">
            <?php if (isset($_SESSION['user'])): ?>
                <div class="d-flex gap-3 align-items-center">
                    <?php if ($_SESSION['user']['id_role'] == 1): ?>
                        <a class="nav-link" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                    <?php endif; ?>
                    <a class="nav-link" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                    <?php if ($_SESSION['user']['id_role'] != 1): ?>
                        <a class="nav-link active" href="cart.php" style="color: white;"><i class="fas fa-shopping-cart"></i></a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <a class="btn btn-outline-light" href="login.php">Войти</a>
            <?php endif; ?>
        </div>
      </div>
    </nav>

    <div class="container mb-5">
        <div class="order-card">
            <h2>Оформление заказа</h2>
            
            <div class="order-item">
                <img src="<?= htmlspecialchars($item['image']) ?>" class="order-item-image" alt="<?= htmlspecialchars($item['nazv_zapch']) ?>">
                <div>
                    <h4><?= htmlspecialchars($item['nazv_zapch']) ?></h4>
                    <p class="text-muted mb-2"><?= htmlspecialchars($item['nazv_tip_zapch']) ?></p>
                    <p class="mb-0"><strong><?= htmlspecialchars($item['tsena']) ?> руб. × <?= htmlspecialchars($item['kolvo']) ?> = <?= htmlspecialchars($item['tsena'] * $item['kolvo']) ?> руб.</strong></p>
                </div>
            </div>
            
            <form method="POST">
                <div class="delivery-options">
                    <h5 class="mb-4">Способ получения</h5>
                    
                    <div class="delivery-option active">
                        <input class="form-check-input" type="radio" name="dostavka" id="selfPickup" value="Самовывоз" checked>
                        <label class="form-check-label" for="selfPickup">
                            <strong>Самовывоз</strong><br>
                            <small class="text-muted">Забрать товар самостоятельно с нашего склада до <?= $formatted_delivery_date ?></small>
                        </label>
                    </div>
                    
                    <div class="delivery-option">
                        <input class="form-check-input" type="radio" name="dostavka" id="delivery" value="Доставка на адрес организации">
                        <label class="form-check-label" for="delivery">
                            <strong>Доставка на адрес организации</strong><br>
                            <small class="text-muted">Примерная дата приезда: <?= $formatted_delivery_date ?></small>
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-checkout">Подтвердить заказ</button>
            </form>
        </div>
    </div>

    <footer class="footer">
      <div class="container">
        <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.delivery-option').click(function() {
                $('.delivery-option').removeClass('active');
                $(this).addClass('active');
                $(this).find('input[type="radio"]').prop('checked', true);
            });
        });
    </script>
</body>
</html>