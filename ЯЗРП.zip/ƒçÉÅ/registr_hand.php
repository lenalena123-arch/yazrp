<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получение данных из формы
    $familia = trim($_POST['familia']);
    $imya = trim($_POST['imya']);
    $otchestvo = trim($_POST['otchestvo']);
    $nazv_ofisa = trim($_POST['nazv_ofisa']);
    $adres_ofisa = trim($_POST['adres_ofisa']);
    $telefon = trim($_POST['telefon']);
    $email = trim($_POST['email']);
    $login = trim($_POST['login']);
    $parol = $_POST['parol'];
    $confirm_password = $_POST['confirm_password'];
    $id_role = 2; // Автоматически устанавливаем роль "Пользователь"

    // Проверка паролей
    if ($parol !== $confirm_password) {
        die("Пароли не совпадают.");
    }

    // Хеширование пароля
    $hashed_password = password_hash($parol, PASSWORD_DEFAULT);

    // Обработка аватара
    $image = 'uploads/default.png'; // аватар по умолчанию
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $avatar_name = uniqid() . '_' . basename($_FILES['avatar']['name']);
        $target_dir = "uploads/";
        $target_file = $target_dir . $avatar_name;

        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
            $image = $target_file;
        }
    }

    // Запись в базу данных
    $stmt = $link->prepare("INSERT INTO users (familia, imya, otchestvo, nazv_ofisa, adres_ofisa, telefon, email, login, parol, image, id_role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssssi", $familia, $imya, $otchestvo, $nazv_ofisa, $adres_ofisa, $telefon, $email, $login, $hashed_password, $image, $id_role);

    if ($stmt->execute()) {
        header("Location: login.php");
        exit;
    } else {
        echo "Ошибка при регистрации: " . $stmt->error;
    }

    $stmt->close();
}
?>