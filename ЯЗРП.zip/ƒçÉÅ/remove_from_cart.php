<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user']['id'])) {
    die(json_encode(['error' => 'Необходима авторизация']));
}

$id_korz = $_POST['id_korz'];
$user_id = $_SESSION['user']['id'];

// Удаляем товар из корзины
$delete = $link->prepare("DELETE FROM korzina WHERE id_korz = ? AND id_user = ?");
$delete->bind_param("ii", $id_korz, $user_id);
$delete->execute();

echo json_encode(['success' => true]);
?>