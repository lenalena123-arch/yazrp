<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user']['id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];

// Получаем данные корзины с информацией о запчастях
$sql = "SELECT k.*, z.nazv_zapch, z.tsena, z.image, t.nazv_tip_zapch 
        FROM korzina k 
        JOIN zapchasti z ON k.id_zapch = z.id_zapch 
        JOIN tip_zapchasti t ON z.id_tip_zapch = t.id_tip_zapch 
        WHERE k.id_user = ?";
$stmt = $link->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$cart_items = $result->fetch_all(MYSQLI_ASSOC);

// Разделяем товары по статусу
$ordered_items = array_filter($cart_items, function($item) {
    return $item['status'] == 'Оформлен';
});
$not_ordered_items = array_filter($cart_items, function($item) {
    return $item['status'] == 'Не оформлен';
});

// Считаем общую сумму для неоформленных товаров
$total_sum = 0;
foreach ($not_ordered_items as $item) {
    $total_sum += $item['tsena'] * $item['kolvo'];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Корзина - ЯЗРП</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #253482;
      --secondary-color: #FF6B00;
    }
      .cart-summary {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 10px;
        margin-top: 20px;
        border: 1px solid #ddd;
    }
    
    .summary-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #eee;
    }
    
    .summary-total {
        font-weight: bold;
        font-size: 1.2rem;
        color: var(--secondary-color);
    }
    
    .checkout-btn {
        width: 100%;
        padding: 12px;
        font-size: 1.1rem;
        margin-top: 15px;
        background-color: var(--secondary-color);
        border-color: var(--secondary-color);
    }
    
    .checkout-btn:hover {
        background-color: #e05d00;
        border-color: #e05d00;
    }
    
    .item-image {
        width: 80px;
        height: 80px;
        object-fit: contain;
        border-radius: 5px;
        border: 1px solid #eee;
        padding: 5px;
        background: white;
    }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex; 
      flex-direction: column; 
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .top-bar {
      background-color: var(--primary-color);
      height: 20px;
    }
    .header-info {
      background-color: #ffffff;
      padding: 15px;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .logo-and-text {
      display: flex;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    .header-info img {
      height: 60px;
      transition: transform 0.3s;
    }
    .header-info img:hover {
      transform: scale(1.05);
    }
    .header-text .title {
      font-weight: bold;
      font-size: 1.2rem;
      color: #000;
    }
    .header-text .location {
      font-size: 1rem;
      color: #333;
    }
    .divider {
      border-left: 1px solid #ccc;
      height: 50px;
    }
    .navbar-custom { 
      background-color: var(--primary-color) !important; 
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    }
    .navbar-custom .nav-link { 
      color: white !important; 
      padding: 10px 15px;
      transition: all 0.3s;
    }
    .navbar-custom .nav-link:hover {
      color: var(--secondary-color) !important;
    }
    .navbar-nav .nav-link.active {
      color: var(--secondary-color) !important;
      font-weight: bold;
      position: relative;
    }
    .navbar-nav .nav-link.active:after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 100%;
      height: 3px;
      background: var(--secondary-color);
    }

    .cart-section {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      padding: 40px 15px;
      background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('background-pattern.png');
      background-size: cover;
    }

    .cart-card {
      width: 100%;
      max-width: 1000px;
      padding: 30px;
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      border-top: 5px solid var(--primary-color);
    }

    .cart-card h2 {
      margin-bottom: 25px;
      color: var(--primary-color);
      font-weight: 700;
      text-align: center;
      position: relative;
      padding-bottom: 15px;
    }

    .cart-card h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: var(--secondary-color);
    }

    .order-section {
      margin-bottom: 30px;
      padding: 20px;
      background: #f9f9f9;
      border-radius: 10px;
      border: 1px solid #ddd;
    }

    .order-section h3 {
      color: var(--primary-color);
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #ddd;
    }

    .cart-item {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      padding: 15px;
      margin-bottom: 15px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .cart-item-image {
      flex: 0 0 100px;
      height: 100px;
      border-radius: 8px;
      overflow: hidden;
    }

    .cart-item-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .cart-item-details {
      flex: 1;
      min-width: 200px;
    }

    .cart-item-title {
      font-weight: 600;
      color: var(--primary-color);
      margin-bottom: 5px;
    }

    .cart-item-info {
      margin-bottom: 5px;
      font-size: 0.9rem;
      color: #555;
    }

    .cart-item-price {
      font-weight: 600;
      color: var(--secondary-color);
    }

    .cart-item-quantity {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .cart-item-delivery {
      flex: 1;
      min-width: 200px;
    }

    .cart-item-actions {
      flex: 0 0 150px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      font-size: 1rem;
      padding: 0.6rem 1.2rem;
      border-radius: 8px;
      transition: all 0.3s;
      font-weight: 500;
    }

    .btn-primary:hover {
      background-color: #1a285f;
      border-color: #1a285f;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .btn-outline-primary {
      color: var(--primary-color);
      border-color: var(--primary-color);
    }

    .btn-outline-primary:hover {
      background-color: var(--primary-color);
      color: white;
    }

    .footer {
      background: #222;
      color: #fff;
      padding: 30px 15px;
      text-align: center;
    }

    .empty-cart {
      text-align: center;
      padding: 30px;
      color: #666;
    }

    @media (max-width: 768px) {
      .header-info {
        flex-direction: column;
        align-items: flex-start;
      }
      .header-text {
        flex-direction: column;
        align-items: flex-start;
      }
      .divider {
        display: none;
      }
      .cart-card {
        padding: 20px;
      }
      .cart-item {
        flex-direction: column;
      }
      .cart-item-actions {
        flex: 1;
        width: 100%;
      }
    }
  </style>
</head>
<body>
    <div class="top-bar w-100"></div>

    <!-- Логотип и информация -->
    <div class="container-fluid header-info">
        <!-- Логотип и текст -->
        <div class="d-flex align-items-center">
            <a href="glavnaya.php">
                <img src="logo.png" alt="Логотип" class="me-3">
            </a>
            <div class="d-flex align-items-center">
                <div class="header-text me-3">
                    <div class="title">
                        Ярославский завод<br>по ремонту погрузчиков
                    </div>
                </div>
                <div class="divider me-3"></div>
                <div class="location">
                    г. Ярославль<br>пр-кт Машиностроителей, д.83, офис 1
                </div>
            </div>
        </div>

        <!-- Поисковая строка и кнопка -->
        <div class="d-flex align-items-center ms-auto">
            <input type="text" class="form-control me-2" placeholder="Поиск запчастей...">
            <button class="btn btn-outline-primary">Найти</button>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
      <div class="container-fluid d-flex justify-content-between align-items-center">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="glavnaya.php">О компании</a></li>
            <li class="nav-item"><a class="nav-link" href="arenda.php">Аренда</a></li>
            <li class="nav-item"><a class="nav-link" href="remont.php">Ремонт</a></li>
            <li class="nav-item"><a class="nav-link" href="TO.php">Техобслуживание</a></li>
            <li class="nav-item"><a class="nav-link" href="zapchasti.php">Запчасти</a></li>
            <li class="nav-item"><a class="nav-link" href="pogryzchiki.php">Погрузчики</a></li>
            <li class="nav-item"><a class="nav-link" href="otzivi.php">Отзывы</a></li>
            <li class="nav-item"><a class="nav-link" href="kontakti.php">Контакты</a></li>
          </ul>
        </div>
        <div class="d-none d-lg-block">
            <?php if (isset($_SESSION['user'])): ?>
                <div class="d-flex gap-3 align-items-center">
                    <?php if ($_SESSION['user']['id_role'] == 1): ?>
                        <a class="nav-link" href="admin.php" style="color: white;"><i class="fas fa-cog"></i></a>
                    <?php endif; ?>
                    <a class="nav-link" href="profile.php" style="color: white;"><i class="fas fa-user"></i></a>
                    <?php if ($_SESSION['user']['id_role'] != 1): ?>
                        <a class="nav-link active" href="cart.php" style="color: white;"><i class="fas fa-shopping-cart"></i></a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <a class="btn btn-outline-light" href="login.php">Войти</a>
            <?php endif; ?>
        </div>
      </div>
    </nav>

       <section class="cart-section">
      <div class="cart-card">
        <h2>Моя корзина</h2>
        
        <!-- Оформленные заказы -->
        <div class="order-section">
          <h3>Оформленные заказы</h3>
          
          <?php if (count($ordered_items) > 0): ?>
            <?php foreach ($ordered_items as $item): ?>
              <div class="cart-item">
                <div class="cart-item-image">
                  <img src="<?= htmlspecialchars($item['image']) ?>" class="item-image" alt="<?= htmlspecialchars($item['nazv_zapch']) ?>">
                </div>
                
                <div class="cart-item-details">
                  <div class="cart-item-title"><?= htmlspecialchars($item['nazv_zapch']) ?></div>
                  <div class="cart-item-info">Тип: <?= htmlspecialchars($item['nazv_tip_zapch']) ?></div>
                  <div class="cart-item-price"><?= htmlspecialchars($item['tsena']) ?> руб. × <?= htmlspecialchars($item['kolvo']) ?> = <?= htmlspecialchars($item['tsena'] * $item['kolvo']) ?> руб.</div>
                </div>
                
                <div class="cart-item-delivery">
                <?php 
                $delivery_date = new DateTime($item['data_priezda']);
                $formatted_delivery_date = $delivery_date->format('d.m.Y');
                
                if ($item['dostavka'] == 'Доставка на адрес организации'): ?>
                    <div><strong>Доставка:</strong> <?= htmlspecialchars($item['dostavka']) ?></div>
                    <div><strong>Дата приезда:</strong> <?= $formatted_delivery_date ?></div>
                <?php else: ?>
                    <div><strong>Способ получения:</strong> <?= htmlspecialchars($item['dostavka']) ?></div>
                    <div><strong>Последний день для самовывоза:</strong> <?= $formatted_delivery_date ?></div>
                <?php endif; ?>
            </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="empty-cart">У вас нет оформленных заказов</div>
          <?php endif; ?>
        </div>
        
        <!-- Неоформленные заказы -->
        <div class="order-section">
          <h3>Товары к оформлению</h3>
          
          <?php if (count($not_ordered_items) > 0): ?>
            <?php foreach ($not_ordered_items as $item): ?>
              <div class="cart-item">
                <div class="cart-item-image">
                  <img src="<?= htmlspecialchars($item['image']) ?>" class="item-image" alt="<?= htmlspecialchars($item['nazv_zapch']) ?>">
                </div>
                
                <div class="cart-item-details">
                  <div class="cart-item-title"><?= htmlspecialchars($item['nazv_zapch']) ?></div>
                  <div class="cart-item-info">Тип: <?= htmlspecialchars($item['nazv_tip_zapch']) ?></div>
                  <div class="cart-item-price"><?= htmlspecialchars($item['tsena']) ?> руб. × <?= htmlspecialchars($item['kolvo']) ?> = <?= htmlspecialchars($item['tsena'] * $item['kolvo']) ?> руб.</div>
                </div>
                
                <div class="cart-item-actions">
                  <a href="order_form.php?id_zapch=<?= $item['id_zapch'] ?>&id_korz=<?= $item['id_korz'] ?>" class="btn btn-primary">Оформить</a>
                  <button class="btn btn-outline-danger remove-item" data-id="<?= $item['id_korz'] ?>">Удалить</button>
                </div>
              </div>
            <?php endforeach; ?>
            
            <div class="cart-summary">
              <div class="summary-row">
                <span>Товаров:</span>
                <span><?= count($not_ordered_items) ?></span>
              </div>
              <div class="summary-row">
                <span>Общая сумма:</span>
                <span class="summary-total"><?= $total_sum ?> руб.</span>
              </div>
              <a href="order_all.php" class="btn btn-primary checkout-btn">Оформить все товары</a>
            </div>
          <?php else: ?>
            <div class="empty-cart">Ваша корзина пуста</div>
          <?php endif; ?>
        </div>
      </div>
    </section>

    <footer class="footer">
      <div class="container">
        <p>&copy; 2025 Ярославский завод по ремонту погрузчиков. Все права защищены.</p>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
    $(document).ready(function() {
        // Удаление товара из корзины
        $('.remove-item').click(function() {
            const id_korz = $(this).data('id');
            const itemElement = $(this).closest('.cart-item');
            
            $.ajax({
                url: 'remove_from_cart.php',
                method: 'POST',
                data: { id_korz: id_korz },
                success: function() {
                    itemElement.fadeOut(300, function() {
                        $(this).remove();
                        // Обновляем страницу, чтобы пересчитать итоги
                        location.reload();
                    });
                },
                error: function() {
                    alert('Ошибка при удалении товара');
                }
            });
        });
    });
    </script>
</body>
</html>