<?php
session_start();
require_once 'config.php';

// Получаем данные фильтра
$selected_tip = $_GET['tip'] ?? '';
$selected_modeli = $_GET['modeli'] ?? '';
$selected_pogr = $_GET['pogr'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';

// Формируем условие запроса
$conditions = [];
$params = [];
$types = '';

if ($selected_tip !== '') {
    $conditions[] = "z.id_tip_zapch = ?";
    $params[] = $selected_tip;
    $types .= 'i';
}

if ($selected_modeli !== '') {
    $conditions[] = "p.model = ?";
    $params[] = $selected_modeli;
    $types .= 's';
}

if ($selected_pogr !== '') {
    $conditions[] = "z.id_pogr = ?";
    $params[] = $selected_pogr;
    $types .= 'i';
}

if ($price_min !== '' && $price_max !== '') {
    $conditions[] = "z.tsena BETWEEN ? AND ?";
    $params[] = $price_min;
    $params[] = $price_max;
    $types .= 'dd';
}

$where_sql = $conditions ? "WHERE " . implode(" AND ", $conditions) : "";

// Запрос
$sql = "SELECT z.*, t.nazv_tip_zapch, p.model, p.nazv_pogr 
        FROM zapchasti z 
        JOIN tip_zapchasti t ON z.id_tip_zapch = t.id_tip_zapch 
        JOIN pogryzchik p ON z.id_pogr = p.id_pogr 
        $where_sql";
$stmt = $link->prepare($sql);
if ($types) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$zapchasti = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

if (!empty($zapchasti)) {
    foreach ($zapchasti as $z): ?>
        <div class="col-lg-4 col-md-6 mb-4 fade-in">
            <div class="card h-100">
                <div class="position-relative">
                    <img src="<?= htmlspecialchars($z['image']) ?>" class="card-img-top p-3" alt="<?= htmlspecialchars($z['nazv_zapch']) ?>">
                    <?php if ($z['kolvo_sklad'] > 0): ?>
                        <span class="badge bg-success position-absolute top-0 end-0 m-2">В наличии</span>
                    <?php else: ?>
                        <span class="badge bg-danger position-absolute top-0 end-0 m-2">Нет в наличии</span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($z['nazv_zapch']) ?></h5>
                    
                    <div class="specs mb-3">
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-tag text-muted me-2"></i>
                            <span><strong>Тип:</strong> <?= htmlspecialchars($z['nazv_tip_zapch']) ?></span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-truck-monster text-muted me-2"></i>
                            <span><strong>Модель:</strong> <?= htmlspecialchars($z['model']) ?></span>
                        </div>
                        <div class="d-flex align-items-center">
                            <i class="fas fa-cogs text-muted me-2"></i>
                            <span><strong>Для:</strong> <?= htmlspecialchars($z['nazv_pogr']) ?></span>
                        </div>
                    </div>
                    
                    <div class="mt-auto">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="price"><?= htmlspecialchars($z['tsena']) ?> ₽</div>
                            <div class="stock">
                                <i class="fas fa-box-open me-1"></i>
                                <?= htmlspecialchars($z['kolvo_sklad']) ?> шт.
                            </div>
                        </div>
                        
                        <?php if ($z['kolvo_sklad'] > 0): ?>
                            <div class="cart-controls" data-id="<?= $z['id_zapch'] ?>" data-price="<?= $z['tsena'] ?>">
                                <?php 
                                $in_cart = false;
                                $cart_quantity = 0;
                                if (isset($_SESSION['user']['id'])) {
                                    $cart_query = $link->prepare("SELECT kolvo FROM korzina WHERE id_user = ? AND id_zapch = ? AND status = 'Не оформлен'");
                                    $cart_query->bind_param("ii", $_SESSION['user']['id'], $z['id_zapch']);
                                    $cart_query->execute();
                                    $cart_result = $cart_query->get_result();
                                    if ($cart_result->num_rows > 0) {
                                        $in_cart = true;
                                        $cart_item = $cart_result->fetch_assoc();
                                        $cart_quantity = $cart_item['kolvo'];
                                    }
                                }
                                ?>
                                
                                <?php if ($in_cart): ?>
                                    <div class="d-flex align-items-center justify-content-center">
                                        <button class="btn btn-sm btn-outline-secondary minus-btn">-</button>
                                        <span class="quantity mx-2"><?= $cart_quantity ?></span>
                                        <button class="btn btn-sm btn-outline-secondary plus-btn">+</button>
                                        <span class="total-price ms-2"><?= $z['tsena'] * $cart_quantity ?> ₽</span>
                                    </div>
                                <?php else: ?>
                                    <button class="btn btn-primary w-100 add-to-cart-btn">
                                        <i class="fas fa-cart-plus me-2"></i>В корзину
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <button class="btn btn-outline-secondary w-100" disabled>
                                <i class="fas fa-bell me-2"></i>Сообщить о поступлении
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach;
} else {
    echo '<div class="col-12 fade-in">
        <div class="no-results bg-white rounded p-5 text-center">
            <i class="fas fa-box-open fa-3x text-muted mb-4"></i>
            <h4 class="mb-3">Запчасти не найдены</h4>
            <p class="text-muted">Попробуйте изменить параметры фильтрации</p>
            <a href="zapchasti.php" class="btn btn-primary mt-3">
                <i class="fas fa-undo me-2"></i>Сбросить фильтры
            </a>
        </div>
    </div>';
}
?>