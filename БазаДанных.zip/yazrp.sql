-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Май 31 2025 г., 19:39
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `yazrp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `korzina`
--

CREATE TABLE `korzina` (
  `id_korz` int(11) NOT NULL,
  `id_zapch` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `status` enum('Не оформлен','Оформлен') NOT NULL,
  `dostavka` enum('Не выбрано','Самовывоз','Доставка на адрес организации') NOT NULL,
  `kolvo` int(11) NOT NULL,
  `data_priezda` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `korzina`
--

INSERT INTO `korzina` (`id_korz`, `id_zapch`, `id_user`, `status`, `dostavka`, `kolvo`, `data_priezda`) VALUES
(1, 1, 9, 'Не оформлен', 'Доставка на адрес организации', 1, '-'),
(2, 2, 9, 'Оформлен', 'Самовывоз', 1, '2025-06-20');

-- --------------------------------------------------------

--
-- Структура таблицы `otzivi`
--

CREATE TABLE `otzivi` (
  `id_otziv` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `otziv` text NOT NULL,
  `data_otziv` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `otzivi`
--

INSERT INTO `otzivi` (`id_otziv`, `id_user`, `otziv`, `data_otziv`) VALUES
(1, 8, 'Прекрасная компания, опытные специалисты, отремонтировали двигатель погрузчика за несколько часов!', '2025-05-01'),
(6, 9, 'Прекрасная компания, опытные специалисты, отремонтировали двигатель погрузчика за несколько часов!', '2025-05-31');

-- --------------------------------------------------------

--
-- Структура таблицы `pogryzchik`
--

CREATE TABLE `pogryzchik` (
  `id_pogr` int(11) NOT NULL,
  `nazv_pogr` varchar(200) NOT NULL,
  `model` enum('Yale','Still','Toyota','Komatsu','Heli','Combilift','Hyster') NOT NULL,
  `tip_texniki` enum('Дизельный','Бензиновый','Электрический') NOT NULL,
  `visota_podema_gryza` varchar(100) NOT NULL,
  `maks_ves_gryza` varchar(50) NOT NULL,
  `tip_gryza` enum('Паллеты','Поддоны','Бочки','Длинномерные грузы') NOT NULL,
  `sposob_obrabotki_gryza` varchar(200) NOT NULL,
  `chastota_ispolzovaniya` varchar(100) NOT NULL,
  `v_nalichii` enum('Да','Нет','У заказчика') NOT NULL,
  `image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `pogryzchik`
--

INSERT INTO `pogryzchik` (`id_pogr`, `nazv_pogr`, `model`, `tip_texniki`, `visota_podema_gryza`, `maks_ves_gryza`, `tip_gryza`, `sposob_obrabotki_gryza`, `chastota_ispolzovaniya`, `v_nalichii`, `image`) VALUES
(1, 'GDP25VX', 'Yale', 'Дизельный', '4,5 м', '2,5 т', 'Паллеты', 'Боковое и верхнее смещение вил', '8 часов/день', 'Да', 'https://smartmsk.ru/upload/iblock/f6f/5455wg33wz2o4b7ieyainsngy1nda3wu.jpg'),
(2, 'ERP30VL', 'Yale', 'Электрический', '6 м', '3,5 т', 'Паллеты', 'Регулировка ширины вил', '8 часов/день', 'Да', 'https://kaluga.forklift-rus.ru/assets/cache_image/products/15465/yale-erp25vl_600x550_5b1.png'),
(3, '8FBE15U', 'Toyota', 'Электрический', '4,5 м', '3 т', 'Паллеты', 'Боковое и верхнее смещение вил', '8 часов/день', 'Да', 'https://avatars.mds.yandex.net/get-ydo/3913661/2a000001783b00c010fdd311ceaf6713b773/diploma');

-- --------------------------------------------------------

--
-- Структура таблицы `role`
--

CREATE TABLE `role` (
  `id_role` int(11) NOT NULL,
  `nazv_role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `role`
--

INSERT INTO `role` (`id_role`, `nazv_role`) VALUES
(1, 'Администратор'),
(2, 'Пользователь');

-- --------------------------------------------------------

--
-- Структура таблицы `tip_zapchasti`
--

CREATE TABLE `tip_zapchasti` (
  `id_tip_zapch` int(11) NOT NULL,
  `nazv_tip_zapch` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `tip_zapchasti`
--

INSERT INTO `tip_zapchasti` (`id_tip_zapch`, `nazv_tip_zapch`) VALUES
(1, 'Двигатель'),
(2, 'Фильтр'),
(3, 'Генератор'),
(4, 'Свечи зажигания'),
(5, 'Поршни'),
(6, 'Гидротрансформатор'),
(7, 'Коробка передач'),
(8, 'Колеса'),
(9, 'Диски'),
(10, 'Радиатор');

-- --------------------------------------------------------

--
-- Структура таблицы `tip_zayavki`
--

CREATE TABLE `tip_zayavki` (
  `id_tip_zayavki` int(11) NOT NULL,
  `nazv_tip_zayavki` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `tip_zayavki`
--

INSERT INTO `tip_zayavki` (`id_tip_zayavki`, `nazv_tip_zayavki`) VALUES
(1, 'Аренда'),
(2, 'Ремонт'),
(3, 'Техобслуживание');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `familia` varchar(100) NOT NULL,
  `imya` varchar(100) NOT NULL,
  `otchestvo` varchar(100) NOT NULL,
  `nazv_ofisa` varchar(200) NOT NULL,
  `adres_ofisa` varchar(150) NOT NULL,
  `telefon` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `login` varchar(50) NOT NULL,
  `parol` varchar(300) NOT NULL,
  `image` varchar(200) NOT NULL,
  `id_role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `familia`, `imya`, `otchestvo`, `nazv_ofisa`, `adres_ofisa`, `telefon`, `email`, `login`, `parol`, `image`, `id_role`) VALUES
(6, 'Фролова', 'Марина', 'Дмитриевна', 'ООО \"Организация\"', 'ул. Урицкого, д. 32', '9043855465', 'marina@mail.ru', 'marina', '$2y$10$UTxTh0JsiErdykjRoL.9NuPBfI3TLX/mZhuPtWzyju8pBKAB2Aio.', 'uploads/6818c7ace19ea_slider2.png', 1),
(7, 'Орлов', 'Никита', 'Андреевич', 'ООО \"Организация\"', 'ул. Урицкого, д. 32', '90438554333', 'nikita@mail.ru', 'nikita', '$2y$10$u8jxwzLkswF1oQoYnWV4t.pVCfMiM2.7DcfYQlVuX3/H9Up4ZwhRa', 'uploads/6818ca4fa4916_slider1.png', 1),
(8, 'Афанасьева', 'Анна', 'Максимовна', 'ООО \"Склад\"', 'ул. Невского, д. 82', '90438554343', 'annaaf@mail.ru', 'anna', '$2y$10$CXVFVDkmrrE0lLj0zIx8MuADNQaUPA0/iB4EDmCo6cjL/Y.pP57l6', 'uploads/6818ce77b6648_кот.jpg', 2),
(9, 'Галкина', 'Елена', 'Дмитриевна', 'ИП \"Стрела\"', 'ул. Невского, д. 23', '9043855476', 'lenalena@mail.ru', 'lena', '$2y$10$uiLO22sFOmGIQA2S5W/AvOwt6gN0LJtrA5UL7ZvQIB3MvgZyKXLpa', 'uploads/default.png', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `zapchasti`
--

CREATE TABLE `zapchasti` (
  `id_zapch` int(11) NOT NULL,
  `nazv_zapch` varchar(200) NOT NULL,
  `id_tip_zapch` int(11) NOT NULL,
  `tsena` decimal(10,2) NOT NULL,
  `kolvo_sklad` varchar(10) NOT NULL,
  `id_pogr` int(11) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `zapchasti`
--

INSERT INTO `zapchasti` (`id_zapch`, `nazv_zapch`, `id_tip_zapch`, `tsena`, `kolvo_sklad`, `id_pogr`, `image`) VALUES
(1, '4TNE92', 1, 10500.00, '30', 1, 'uploads/4TNE92.png'),
(2, 'Шина для GDP25VX', 8, 2500.00, '35', 1, 'uploads/Шина_для_GDP25VX.png');

-- --------------------------------------------------------

--
-- Структура таблицы `zayavki`
--

CREATE TABLE `zayavki` (
  `id_zayavki` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_pogr` int(11) NOT NULL,
  `id_tip_zayavki` int(11) NOT NULL,
  `data_zayavki` date NOT NULL,
  `nachalo_arendi` varchar(50) NOT NULL,
  `konec_arendi` varchar(50) NOT NULL,
  `kolvo_motochasov` varchar(20) NOT NULL,
  `opisanie` text NOT NULL,
  `status` enum('Отправлена','Рассмотрена','Отклонена','Принята') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `zayavki`
--

INSERT INTO `zayavki` (`id_zayavki`, `id_user`, `id_pogr`, `id_tip_zayavki`, `data_zayavki`, `nachalo_arendi`, `konec_arendi`, `kolvo_motochasov`, `opisanie`, `status`) VALUES
(1, 9, 3, 1, '2025-05-08', '2025-05-08', '2026-05-08', '-', 'Аренда погрузчика для компании', 'Отправлена'),
(2, 9, 2, 3, '2025-05-08', '-', '-', '10', 'Заявка на Техническое обслуживание погрузчика', 'Отправлена');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `korzina`
--
ALTER TABLE `korzina`
  ADD PRIMARY KEY (`id_korz`),
  ADD UNIQUE KEY `id_korz` (`id_korz`),
  ADD KEY `id_zapch` (`id_zapch`,`id_user`),
  ADD KEY `id_user` (`id_user`);

--
-- Индексы таблицы `otzivi`
--
ALTER TABLE `otzivi`
  ADD PRIMARY KEY (`id_otziv`),
  ADD KEY `id_user` (`id_user`);

--
-- Индексы таблицы `pogryzchik`
--
ALTER TABLE `pogryzchik`
  ADD PRIMARY KEY (`id_pogr`),
  ADD KEY `id_pogr` (`id_pogr`);

--
-- Индексы таблицы `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id_role`),
  ADD KEY `id_role` (`id_role`);

--
-- Индексы таблицы `tip_zapchasti`
--
ALTER TABLE `tip_zapchasti`
  ADD PRIMARY KEY (`id_tip_zapch`),
  ADD KEY `id_tip_zapch` (`id_tip_zapch`);

--
-- Индексы таблицы `tip_zayavki`
--
ALTER TABLE `tip_zayavki`
  ADD PRIMARY KEY (`id_tip_zayavki`),
  ADD KEY `id_tip_zayavki` (`id_tip_zayavki`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `telefon` (`telefon`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_role` (`id_role`);

--
-- Индексы таблицы `zapchasti`
--
ALTER TABLE `zapchasti`
  ADD PRIMARY KEY (`id_zapch`),
  ADD KEY `id_zapch` (`id_zapch`),
  ADD KEY `id_tip_zapch` (`id_tip_zapch`,`id_pogr`),
  ADD KEY `id_pogr` (`id_pogr`);

--
-- Индексы таблицы `zayavki`
--
ALTER TABLE `zayavki`
  ADD PRIMARY KEY (`id_zayavki`),
  ADD KEY `id_zayavki` (`id_zayavki`),
  ADD KEY `id_user` (`id_user`,`id_pogr`,`id_tip_zayavki`),
  ADD KEY `id_pogr` (`id_pogr`),
  ADD KEY `id_tip_zayavki` (`id_tip_zayavki`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `korzina`
--
ALTER TABLE `korzina`
  MODIFY `id_korz` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `otzivi`
--
ALTER TABLE `otzivi`
  MODIFY `id_otziv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `pogryzchik`
--
ALTER TABLE `pogryzchik`
  MODIFY `id_pogr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `role`
--
ALTER TABLE `role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `tip_zapchasti`
--
ALTER TABLE `tip_zapchasti`
  MODIFY `id_tip_zapch` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `tip_zayavki`
--
ALTER TABLE `tip_zayavki`
  MODIFY `id_tip_zayavki` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `zapchasti`
--
ALTER TABLE `zapchasti`
  MODIFY `id_zapch` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `zayavki`
--
ALTER TABLE `zayavki`
  MODIFY `id_zayavki` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `korzina`
--
ALTER TABLE `korzina`
  ADD CONSTRAINT `korzina_ibfk_1` FOREIGN KEY (`id_zapch`) REFERENCES `zapchasti` (`id_zapch`),
  ADD CONSTRAINT `korzina_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`);

--
-- Ограничения внешнего ключа таблицы `otzivi`
--
ALTER TABLE `otzivi`
  ADD CONSTRAINT `otzivi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`);

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_role`) REFERENCES `role` (`id_role`);

--
-- Ограничения внешнего ключа таблицы `zapchasti`
--
ALTER TABLE `zapchasti`
  ADD CONSTRAINT `zapchasti_ibfk_1` FOREIGN KEY (`id_tip_zapch`) REFERENCES `tip_zapchasti` (`id_tip_zapch`),
  ADD CONSTRAINT `zapchasti_ibfk_2` FOREIGN KEY (`id_pogr`) REFERENCES `pogryzchik` (`id_pogr`);

--
-- Ограничения внешнего ключа таблицы `zayavki`
--
ALTER TABLE `zayavki`
  ADD CONSTRAINT `zayavki_ibfk_1` FOREIGN KEY (`id_pogr`) REFERENCES `pogryzchik` (`id_pogr`),
  ADD CONSTRAINT `zayavki_ibfk_2` FOREIGN KEY (`id_tip_zayavki`) REFERENCES `tip_zayavki` (`id_tip_zayavki`),
  ADD CONSTRAINT `zayavki_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
